<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Admin extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        is_logged_in();
        $this->load->library('Excel');
        $this->load->model('Model_data');
    }


    public function index()
    {


        $data['user'] = $this->db->get_where('user', ['username' =>
        $this->session->userdata('username')])->row_array();
        $data['tombol']     = $this->db->get_where('status_pengumuman', "id ='1'")->row();
        $data['sekolah'] = $this->db->get_where('identitas_sekolah', "id = 1")->row_array();
        $data['title'] = 'Dashboard';


        $this->form_validation->set_rules('nama_sekolah', 'tahun_pelajaran', 'required|trim');
        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('admin/index', $data);
            $this->load->view('templates/footer');
        } else {
        }
    }

    public function data_user()
    {
        $this->form_validation->set_rules('subusername', 'subusername', 'required|trim|is_unique[user.username]', [
            'is_unique' => 'Username sudah terdaftar'
        ]);
        $this->form_validation->set_rules('subpassword', 'subpassword', 'required|trim');
        if ($this->form_validation->run() == false) {
            $data['user'] = $this->db->get_where('user', ['username' =>
            $this->session->userdata('username')])->row_array();

            $this->db->order_by('name', 'ASC');
            $data['title'] = 'Data Wali Kelas';

            $data['siswa'] = $this->db->get_where('user', array('role_id' => 2))->result_array();
            $data['sekolah'] = $this->db->get_where('identitas_sekolah', "id = 1")->row_array();
            $data['kelas'] = $this->db->get('kelas')->result();


            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('admin/data_user', $data);
            $this->load->view('templates/footer');
        } else {


            $data = [
                'name' => htmlspecialchars($this->input->post('subname', true)),
                'username' => htmlspecialchars($this->input->post('subusername', true)),
                'password' => password_hash($this->input->post('subpassword'), PASSWORD_DEFAULT),
                'role_id' => '2',
                'is_active' => htmlspecialchars($this->input->post('is_active', true)),
                'manage' => htmlspecialchars($this->input->post('manage', true)),
                'date_created' => time()


            ];

            $this->db->insert('user', $data);
            $this->session->set_flashdata('message', '<div class="alert alert-success text-center" role="alert">Data berhasil disimpan</div>');
            redirect('admin/data_user');
        }
    }


    public function addsuperuser()
    {
        $this->form_validation->set_rules('subusername', 'subusername', 'required|trim|is_unique[user.username]', [
            'is_unique' => 'Username sudah terdaftar'
        ]);
        $this->form_validation->set_rules('subpassword', 'subpassword', 'required|trim');
        if ($this->form_validation->run() == false) {
            $data['user'] = $this->db->get_where('user', ['username' =>
            $this->session->userdata('username')])->row_array();

            $this->db->order_by('name', 'ASC');
            $data['title'] = 'Add Superuser';

            $data['siswa'] = $this->db->get_where('user', array('role_id !=' => 2))->result_array();

            $data['sekolah'] = $this->db->get_where('identitas_sekolah', "id = 1")->row_array();
            $data['kelas'] = $this->db->get('kelas')->result();


            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('admin/add_superuser', $data);
            $this->load->view('templates/footer');
        } else {


            $data = [
                'name' => htmlspecialchars($this->input->post('subname', true)),
                'username' => htmlspecialchars($this->input->post('subusername', true)),
                'password' => password_hash($this->input->post('subpassword'), PASSWORD_DEFAULT),
                'role_id' => htmlspecialchars($this->input->post('role_id', true)),
                'is_active' => htmlspecialchars($this->input->post('is_active', true)),
                'manage' => 'Kepala Sekolah',
                'date_created' => time()


            ];

            $this->db->insert('user', $data);
            $this->session->set_flashdata('message', '<div class="alert alert-success text-center" role="alert">Data berhasil disimpan</div>');
            redirect('admin/addsuperuser');
        }
    }

    public function tahun_pelajaran()
    {

        $this->form_validation->set_rules('thn_pelajaran', 'thn_pelajaran', 'required|trim');
        if ($this->form_validation->run() == false) {
            $data['user'] = $this->db->get_where('user', ['username' =>
            $this->session->userdata('username')])->row_array();

            $this->db->order_by('date_created', 'DESC');
            $data['title'] = 'Daftar Tahun Pelajaran';

            $data['tahun'] = $this->db->get('thn_pelajaran')->result_array();
            $data['sekolah'] = $this->db->get_where('identitas_sekolah', "id = 1")->row_array();


            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('admin/tahun_ajar', $data);
            $this->load->view('templates/footer');
        } else {


            $data = [
                'thn_pelajaran' => htmlspecialchars($this->input->post('thn_pelajaran', true)),
                'date_created' => time()

            ];

            $this->db->insert('thn_pelajaran', $data);
            $this->session->set_flashdata('message', '<div class="alert alert-success text-center" role="alert">Data berhasil disimpan</div>');
            redirect('admin/tahun_pelajaran');
        }
    }

    public function editdata($sw)
    {
        $data = [
            'name' => $this->input->post('editname'),
            'is_active' => $this->input->post('is_active'),
            'manage' => $this->input->post('manage'),

        ];
        $this->db->update('user', $data, array('id' => $sw));
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Update data berhasil!</div>');
        redirect('admin/data_user');
    }

    public function editsuperuser($sw)
    {
        $data = [
            'name' => $this->input->post('editname'),
            'role_id' => $this->input->post('role_id'),
            'is_active' => $this->input->post('is_active'),


        ];
        $this->db->update('user', $data, array('id' => $sw));
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Update data berhasil!</div>');
        redirect('admin/addsuperuser');
    }


    public function delete($sw)
    {

        $this->db->where('username', $sw);
        $this->db->delete('user');
        $this->db->affected_rows();
        $this->session->set_flashdata('message', '<div class="alert alert-success text-center" role="alert">Data telah dihapus</div>');
        redirect('admin/data_user');
    }


    public function deleteall()
    {

        $this->db->delete('user', array('role_id' => 2));
        $this->db->affected_rows();
        $this->session->set_flashdata('message', '<div class="alert alert-success text-center" role="alert">Data telah dihapus</div>');
        redirect('admin/data_siswa');
    }

    public function nilai_ekstrakurikuler()
    {

        $data['user'] = $this->db->get_where('user', ['username' =>
        $this->session->userdata('username')])->row_array();
        $data['title'] = 'Data Nilai Ekstrakurikuler';

        $data['sekolah'] = $this->db->get_where('identitas_sekolah', "id = 1")->row_array();

        $data['kelas'] = $this->db->get('kelas')->result();

        $this->db->order_by('date_created', 'DESC');
        $data['tahun'] = $this->db->get('thn_pelajaran')->result();
        $data['kelas'] = $this->db->get('kelas')->result();


        $thn_pelajaran = $this->input->get('thn_pelajaran');
        $nama_kelas = $this->input->get('nama_kelas');
        $data['tampildata'] = $this->Model_data->nilai_ekskul($thn_pelajaran, $nama_kelas)->result_array();


        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('admin/nilai_ekskul', $data);
        $this->load->view('templates/footer');
    }

    public function rekap_absensi()
    {

        $data['user'] = $this->db->get_where('user', ['username' =>
        $this->session->userdata('username')])->row_array();
        $data['title'] = 'Data Rekap Kehadiran Peserta Didik';

        $data['sekolah'] = $this->db->get_where('identitas_sekolah', "id = 1")->row_array();

        $data['kelas'] = $this->db->get('kelas')->result();

        $this->db->order_by('date_created', 'DESC');
        $data['tahun'] = $this->db->get('thn_pelajaran')->result();
        $data['kelas'] = $this->db->get('kelas')->result();


        $thn_pelajaran = $this->input->get('thn_pelajaran');
        $nama_kelas = $this->input->get('nama_kelas');
        $data['tampildata'] = $this->Model_data->rekapabsen($thn_pelajaran, $nama_kelas)->result_array();





        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('admin/rekap_absensi', $data);
        $this->load->view('templates/footer');
    }

    public function erapor()
    {

        $data['user'] = $this->db->get_where('user', ['username' =>
        $this->session->userdata('username')])->row_array();
        $data['title'] = 'Cetak Rapor Kelas';

        $data['sekolah'] = $this->db->get_where('identitas_sekolah', "id = 1")->row_array();

        $data['kelas'] = $this->db->get('kelas')->result();

        $this->db->order_by('date_created', 'DESC');
        $data['tahun'] = $this->db->get('thn_pelajaran')->result();
        $data['kelas'] = $this->db->get('kelas')->result();


        $thn_pelajaran = $this->input->get('thn_pelajaran');
        $nama_kelas = $this->input->get('nama_kelas');
        $data['tampildata'] = $this->Model_data->pencariannilai($thn_pelajaran, $nama_kelas)->result_array();






        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('admin/erapor', $data);
        $this->load->view('templates/footer');
    }




    public function data_sekolah()
    {
        $data['title'] = 'Data Sekolah';
        $data['user'] = $this->db->get_where('user', ['username' =>
        $this->session->userdata('username')])->row_array();
        $data['sekolah'] = $this->db->get_where('identitas_sekolah', "id = 1")->row_array();

        $this->form_validation->set_rules('nama_sekolah', 'npsn', 'required|trim');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('admin/data_sekolah', $data);
            $this->load->view('templates/footer');
        } else {

            $data = [

                'nama_sekolah' => htmlspecialchars($this->input->post('nama_sekolah', true)),
                'npsn' => htmlspecialchars($this->input->post('npsn', true)),
                'alamat_sekolah' => htmlspecialchars($this->input->post('alamat_sekolah', true)),
                'kecamatan' => htmlspecialchars($this->input->post('kecamatan', true)),
                'kabupaten' => htmlspecialchars($this->input->post('kabupaten', true)),
                'provinsi' => htmlspecialchars($this->input->post('provinsi', true)),
                'kode_pos' => htmlspecialchars($this->input->post('kode_pos', true)),
                'telepon' => htmlspecialchars($this->input->post('telepon', true)),
                'email_sekolah' => htmlspecialchars($this->input->post('email_sekolah', true)),



            ];

            //cek jika ada gambar yang akan diupload
            $upload_image = $_FILES['image']['name'];

            if ($upload_image) {
                $config['allowed_types'] = 'gif|jpg|png';
                $config['max_size'] = '2048';
                $config['upload_path'] = './assets/img/profile/';

                $this->load->library('upload', $config);

                if ($this->upload->do_upload('image')) {
                    $old_image = $data['sekolah']['logo'];
                    if ($old_image != 'default.png') {
                        unlink(FCPATH . 'assets/img/profile/' . $old_image);
                    }

                    $new_image = $this->upload->data('file_name');
                    $this->db->set('logo', $new_image);
                } else {
                    echo $this->upload->display_errors();
                }
            }



            $this->db->where('id', 1);
            $this->db->update('identitas_sekolah', $data);

            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">
			Your profile has been update!
		  </div>');
            redirect('admin/data_sekolah');
        }
    }
}
