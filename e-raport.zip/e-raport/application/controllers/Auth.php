<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Auth extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');
    }


    public function index()
    {

        $this->form_validation->set_rules('username', 'username', 'trim|required');
        $this->form_validation->set_rules('password', 'password', 'trim|required');

        if ($this->form_validation->run() == false) {
            $data['title'] = 'Sistem Informasi Hasil Belajar';
            $data['sekolah'] = $this->db->get_where('identitas_sekolah', "id='1'")->row();

            $this->load->view('auth/newlogin.php', $data);
        } else {
            $this->_login();
        }
    }

    private function _login()
    {
        $username = $this->input->post('username');
        $password = $this->input->post('password');


        $user = $this->db->get_where('user', ['username' => $username])->row_array();

        if ($user) {
            //Jika dicek sudah ada user

            if ($user['is_active'] == 1) {
                //Jika user sudah aktif
                if (password_verify($password, $user['password'])) {
                    //Cek Password

                    $data = [
                        'username' => $user['username'],
                        'manage' => $user['manage'],
                        'role_id' => $user['role_id']
                    ];
                    $this->session->set_userdata($data);
                    if ($user['role_id'] == 1) {
                        redirect('admin');
                    } else {
                        redirect('user');
                    }
                } else {
                    $this->session->set_flashdata('message', '<div class="alert alert-danger text-center" role="alert">
			Password incorect!
		  </div>');
                    redirect('auth');
                }
            } else {
                $this->session->set_flashdata('message', '<div class="alert alert-danger text-center" role="alert">
			Username has not been activated!
		  </div>');
                redirect('auth');
            }
        } else {
            $this->session->set_flashdata('message', '<div class="alert alert-danger text-center" role="alert">
			Username is not registered!
		  </div>');
            redirect('auth');
        }
    }





    public function registration()
    {

        $this->form_validation->set_rules('username', 'username', 'required|trim|is_unique[user.username]', [
            'is_unique' => 'Nomor Ujian telah terdaftar'
        ]);
        $this->form_validation->set_rules('password', 'password', 'required|trim');
        if ($this->form_validation->run() == false) {
            $data['title'] = 'Registration';
            $this->load->view('templates/auth_header.php', $data);
            $this->load->view('auth/registration.php');
            $this->load->view('templates/auth_footer.php');
        } else {
            $data = [
                'name' => htmlspecialchars($this->input->post('name', true)),
                'username' => htmlspecialchars($this->input->post('username', true)),
                'password' => password_hash($this->input->post('password'), PASSWORD_DEFAULT),
                'keterangan' => 'lulus',
                'role_id' => '2',
                'is_active' => '1',
                'date_created' => time()


            ];

            $this->db->insert('user', $data);
            $this->session->set_flashdata('message', '<div class="alert alert-success text-center" role="alert">Data telah tersimpan</div>');
            redirect('auth/registration');
        }
    }





    public function logout()
    {
        $this->session->unset_userdata('username');
        $this->session->unset_userdata('role_id');


        redirect('auth');
    }


    public function blocked()
    {
        $data['title'] = 'Access Blocked';
        $this->load->view('templates/auth_header.php', $data);
        $this->load->view('auth/blocked');
    }
}
