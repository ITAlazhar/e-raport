<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Masterdata extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        is_logged_in();
        $this->load->library('Excel');
    }


    public function index()
    {
    }

    public function data_pesertadidik()
    {
        $this->form_validation->set_rules('nisn', 'nisn', 'required|trim|is_unique[user.username]', [
            'is_unique' => 'NISN sudah terdaftar'
        ]);
        $this->form_validation->set_rules('password', 'password', 'required|trim');
        if ($this->form_validation->run() == false) {
            $data['user'] = $this->db->get_where('user', ['username' =>
            $this->session->userdata('username')])->row_array();

            $this->db->order_by('nama_lengkap', 'ASC');
            $data['title'] = 'Data Peserta Didik';

            $data['siswa'] = $this->db->get_where('peserta_didik', array('status_pd' => 'aktif'))->result_array();
            $data['sekolah'] = $this->db->get_where('identitas_sekolah', "id = 1")->row_array();


            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('masterdata/data_pesertadidik', $data);
            $this->load->view('templates/footer');
        } else {


            $data = [
                'nisn' => htmlspecialchars($this->input->post('nisn', true)),
                'password' => password_hash($this->input->post('password'), PASSWORD_DEFAULT),
                'nama_lengkap' => htmlspecialchars($this->input->post('nama_lengkap', true)),
                'tempat_lahir' => htmlspecialchars($this->input->post('tempat_lahir', true)),
                'tanggal_lahir' => htmlspecialchars($this->input->post('tgl_lahir', true)),
                'agama' => htmlspecialchars($this->input->post('agama', true)),
                'alamat' => htmlspecialchars($this->input->post('alamat', true)),
                'no_hp' => htmlspecialchars($this->input->post('no_hp', true)),

                'status_pd' => htmlspecialchars($this->input->post('status_pd', true)),
                'date_created' => time()


            ];

            $this->db->insert('peserta_didik', $data);
            $this->session->set_flashdata('message', '<div class="alert alert-success text-center" role="alert">Data berhasil disimpan</div>');
            redirect('masterdata/data_pesertadidik');
        }
    }

    public function data_kelas()
    {
        $this->form_validation->set_rules('nama_kelas', 'nama_kelas', 'required|trim|is_unique[user.username]', [
            'is_unique' => 'Nama kelas sudah ada'
        ]);

        if ($this->form_validation->run() == false) {
            $data['user'] = $this->db->get_where('user', ['username' =>
            $this->session->userdata('username')])->row_array();
            $data['title'] = 'Data Kelas';

            $data['kelas'] = $this->db->get('data_kelas')->result_array();
            $data['sekolah'] = $this->db->get_where('identitas_sekolah', "id = 1")->row_array();

            $data['data_siswa'] = $this->db->get('peserta_didik')->result_array();
            $data['data_semester'] = $this->db->get('thn_pelajaran')->result_array();
            $data['data_kelas'] = $this->db->get('kelas')->result_array();

            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('masterdata/data_kelas', $data);
            $this->load->view('templates/footer');
        } else {

            $nama_kelas = $this->input->post('nama_kelas');
            $this->db->set('nama_kelas', $nama_kelas);
            $this->db->insert('kelas');
            $this->session->set_flashdata('message', '<div class="alert alert-success text-center" role="alert">Data berhasil disimpan</div>');
            redirect('masterdata/data_kelas');
        }
    }


    public function kelas()
    {
        
            $semester_id = $this->input->post('semester_id');
            $kelas_id = $this->input->post('kelas_id');
            $siswa_id = $this->input->post('siswa_id');

            $data=[
                'semester_id' => $semester_id,
                'kelas_id' => $kelas_id,
                'siswa_id' => $siswa_id

            ];
            $this->db->insert('data_kelas',$data);
            $this->session->set_flashdata('message', '<div class="alert alert-success text-center" role="alert">Data berhasil disimpan</div>');
            redirect('masterdata/data_kelas');
    }

    public function data_mapel()
    {
        $this->form_validation->set_rules('nama_mapel', 'nama_mapel', 'required|trim|is_unique[user.username]', [
            'is_unique' => 'Nama Mata Pelajaran sudah ada'
        ]);

        if ($this->form_validation->run() == false) {
            $data['user'] = $this->db->get_where('user', ['username' =>
            $this->session->userdata('username')])->row_array();
            $data['title'] = 'Data Mata Pelajaran';

            $data['mapel'] = $this->db->get('mata_pelajaran')->result_array();
            $data['sekolah'] = $this->db->get_where('identitas_sekolah', "id = 1")->row_array();


            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('masterdata/data_mapel', $data);
            $this->load->view('templates/footer');
        } else {


            $nama_mapel = $this->input->post('nama_mapel');
            $this->db->set('nama_mapel', $nama_mapel);
            $this->db->insert('mata_pelajaran');
            $this->session->set_flashdata('message', '<div class="alert alert-success text-center" role="alert">Data berhasil disimpan</div>');
            redirect('masterdata/data_mapel');
        }
    }

    public function kode_mapel()
    {
        $this->form_validation->set_rules('kode_mapel', 'Kode_mapel', 'required|trim|is_unique[user.username]', [
            'is_unique' => 'Kode mapel sudah ada'
        ]);

        if ($this->form_validation->run() == false) {
            $data['user'] = $this->db->get_where('user', ['username' =>
            $this->session->userdata('username')])->row_array();
            $data['title'] = 'Daftar Kode Mata Pelajaran';
            $this->db->order_by('nama_kelas', 'ASC');
            $data['kodemapel'] = $this->db->get('kode_mapel')->result_array();
            $data['sekolah'] = $this->db->get_where('identitas_sekolah', "id = 1")->row_array();
            $data['kelas'] = $this->db->get('kelas')->result();
            $data['mapel'] = $this->db->get('mata_pelajaran')->result();


            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('masterdata/kode_mapel', $data);
            $this->load->view('templates/footer');
        } else {


            $nama_kelas = $this->input->post('nama_kelas');
            $nama_mapel = $this->input->post('nama_mapel');
            $kode_mapel = $this->input->post('kode_mapel');
            $this->db->set('nama_kelas', $nama_kelas);
            $this->db->set('nama_mapel', $nama_mapel);
            $this->db->set('kode_mapel', $kode_mapel);
            $this->db->insert('kode_mapel');
            $this->session->set_flashdata('message', '<div class="alert alert-success text-center" role="alert">Data berhasil disimpan</div>');
            redirect('masterdata/kode_mapel');
        }
    }

    public function kelola_kelas()
    {

        $data['user'] = $this->db->get_where('user', ['username' =>
        $this->session->userdata('username')])->row_array();
        $data['title'] = 'Kelola Kelas';

        $data['kelola'] = $this->db->get('kelas')->result_array();

        $data['sekolah'] = $this->db->get_where('identitas_sekolah', "id = 1")->row_array();


        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('masterdata/kelola_kelas', $data);
        $this->load->view('templates/footer');
    }

    public function enroll_kelas($list)
    {

        $data['user'] = $this->db->get_where('user', ['username' =>
        $this->session->userdata('username')])->row_array();
        $data['title'] = 'Enrol Peserta Didik';

        $data['kelola'] = $this->db->get('kelas')->result_array();

        $data['sekolah'] = $this->db->get_where('identitas_sekolah', "id = 1")->row_array();


        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('masterdata/kelola_kelas', $data);
        $this->load->view('templates/footer');
    }

    public function ekstrakurikuler()
    {
        $this->form_validation->set_rules('nama_ekskul', 'nama_ekskul', 'required|trim|is_unique[user.username]', [
            'is_unique' => 'Nama ekskul sudah ada'
        ]);

        if ($this->form_validation->run() == false) {
            $data['user'] = $this->db->get_where('user', ['username' =>
            $this->session->userdata('username')])->row_array();
            $data['title'] = 'Data Esktrakurikuler';

            $data['ekskul'] = $this->db->get('ekstrakurikuler')->result_array();
            $data['sekolah'] = $this->db->get_where('identitas_sekolah', "id = 1")->row_array();


            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('masterdata/ekstrakurikuler', $data);
            $this->load->view('templates/footer');
        } else {


            $nama_ekskul = $this->input->post('nama_ekskul');
            $keterangan = $this->input->post('keterangan');
            $this->db->set('nama_ekskul', $nama_ekskul);
            $this->db->set('keterangan', $keterangan);
            $this->db->insert('ekstrakurikuler');
            $this->session->set_flashdata('message', '<div class="alert alert-success text-center" role="alert">Data berhasil disimpan</div>');
            redirect('masterdata/ekstrakurikuler');
        }
    }




    public function editdata($sw)
    {
        $data = [
            'name' => $this->input->post('editname'),
            'is_active' => $this->input->post('is_active'),

        ];
        $this->db->update('user', $data, array('id' => $sw));
        $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">Update data berhasil!</div>');
        redirect('admin/data_user');
    }


    public function delete($sw)
    {

        $this->db->where('username', $sw);
        $this->db->delete('user');
        $this->db->affected_rows();
        $this->session->set_flashdata('message', '<div class="alert alert-success text-center" role="alert">Data telah dihapus</div>');
        redirect('admin/data_siswa');
    }


    public function deleteall()
    {

        $this->db->delete('user', array('role_id' => 2));
        $this->db->affected_rows();
        $this->session->set_flashdata('message', '<div class="alert alert-success text-center" role="alert">Data telah dihapus</div>');
        redirect('admin/data_siswa');
    }


    public function importExcel()
    {

        $fileName = $_FILES['file']['name'];

        $config['upload_path'] = './import/pesertadidik/'; //path upload
        $config['file_name'] = $fileName;  // nama file
        $config['allowed_types'] = 'xls|xlsx|csv'; //tipe file yang diperbolehkan
        $config['max_size'] = 10000; // maksimal size

        $this->load->library('upload'); //meload librari upload
        $this->upload->initialize($config);

        if (!$this->upload->do_upload('file')) {
            echo $this->upload->display_errors();
            exit();
        }

        $inputFileName = './import/pesertadidik/' . $fileName;

        try {
            $inputFileType = PHPExcel_IOFactory::identify($inputFileName);
            $objReader = PHPExcel_IOFactory::createReader($inputFileType);
            $objPHPExcel = $objReader->load($inputFileName);
        } catch (Exception $e) {
            die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME) . '": ' . $e->getMessage());
        }

        $sheet = $objPHPExcel->getSheet(0);
        $highestRow = $sheet->getHighestRow();
        $highestColumn = $sheet->getHighestColumn();

        for ($row = 2; $row <= $highestRow; $row++) {                  //  Read a row of data into an array                 
            $rowData = $sheet->rangeToArray(
                'A' . $row . ':' . $highestColumn . $row,
                NULL,
                TRUE,
                FALSE
            );

            // Sesuaikan key array dengan nama kolom di database                                                         
            $data = array(
                // "email"=> $rowData[0][0],
                "nisn" => $rowData[0][0],

                "password" => password_hash($rowData[0][1], PASSWORD_DEFAULT),
                "nama_lengkap" => $rowData[0][2],
                "jenis_kelamin" => $rowData[0][3],
                "tempat_lahir" => $rowData[0][4],
                "tanggal_lahir" => $rowData[0][5],
                "agama" => $rowData[0][6],
                "alamat" => $rowData[0][7],
                "no_hp" => $rowData[0][8],
                "status_pd" => $rowData[0][9],
                "date_created" => time($rowData[0][1][0])


            );

            $insert = $this->db->insert("peserta_didik", $data);
            $this->session->set_flashdata('message', '<div class="alert alert-success text-center" role="alert">Import Data Berhasil </div>');
        }
        redirect('masterdata/data_pesertadidik');
    }


    public function data_sekolah()
    {
        $data['title'] = 'Data Sekolah';
        $data['user'] = $this->db->get_where('user', ['username' =>
        $this->session->userdata('username')])->row_array();
        $data['sekolah'] = $this->db->get_where('identitas_sekolah', "id = 1")->row_array();

        $this->form_validation->set_rules('nama_sekolah', 'npsn', 'required|trim');

        if ($this->form_validation->run() == false) {
            $this->load->view('templates/header', $data);
            $this->load->view('templates/sidebar', $data);
            $this->load->view('templates/topbar', $data);
            $this->load->view('admin/data_sekolah', $data);
            $this->load->view('templates/footer');
        } else {

            $data = [

                'nama_sekolah' => htmlspecialchars($this->input->post('nama_sekolah', true)),
                'npsn' => htmlspecialchars($this->input->post('npsn', true)),
                'alamat_sekolah' => htmlspecialchars($this->input->post('alamat_sekolah', true)),
                'kecamatan' => htmlspecialchars($this->input->post('kecamatan', true)),
                'kabupaten' => htmlspecialchars($this->input->post('kabupaten', true)),
                'provinsi' => htmlspecialchars($this->input->post('provinsi', true)),
                'kode_pos' => htmlspecialchars($this->input->post('kode_pos', true)),
                'telepon' => htmlspecialchars($this->input->post('telepon', true)),
                'email_sekolah' => htmlspecialchars($this->input->post('email_sekolah', true)),



            ];

            //cek jika ada gambar yang akan diupload
            $upload_image = $_FILES['image']['name'];

            if ($upload_image) {
                $config['allowed_types'] = 'gif|jpg|png';
                $config['max_size'] = '2048';
                $config['upload_path'] = './assets/img/profile/';

                $this->load->library('upload', $config);

                if ($this->upload->do_upload('image')) {
                    $old_image = $data['sekolah']['logo'];
                    if ($old_image != 'default.png') {
                        unlink(FCPATH . 'assets/img/profile/' . $old_image);
                    }

                    $new_image = $this->upload->data('file_name');
                    $this->db->set('logo', $new_image);
                } else {
                    echo $this->upload->display_errors();
                }
            }



            $this->db->where('id', 1);
            $this->db->update('identitas_sekolah', $data);

            $this->session->set_flashdata('message', '<div class="alert alert-success" role="alert">
			Your profile has been update!
		  </div>');
            redirect('admin/data_sekolah');
        }
    }
}
