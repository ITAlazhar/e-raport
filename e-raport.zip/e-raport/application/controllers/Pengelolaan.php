<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Pengelolaan extends CI_Controller
{
    public function __construct()
    {
        parent::__construct();
        is_logged_in();
        $this->load->library('Excel');
        $this->load->model('Model_data');
    }


    public function index()
    {
        $data['user'] = $this->db->get_where('user', ['username' =>
        $this->session->userdata('username')])->row_array();


        $data['title'] = 'Import nilai pengetahuan dan nilai keterampilan';

        $data['legernilaik3'] = $this->db->get_where('peserta_didik', array('status_pd' => 'aktif'))->result_array();
        $data['sekolah'] = $this->db->get_where('identitas_sekolah', "id = 1")->row_array();


        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('pengelolaan/index', $data);
        $this->load->view('templates/footer');
    }

    public function nilai_absensi()
    {

        $data['user'] = $this->db->get_where('user', ['username' =>
        $this->session->userdata('username')])->row_array();
        $data['title'] = 'Data Nilai Absensi';

        $data['sekolah'] = $this->db->get_where('identitas_sekolah', "id = 1")->row_array();

        $data['kode'] = $this->db->select('kode_mapel')
            ->from('user')
            ->join('kode_mapel', 'user.manage = kode_mapel.nama_kelas')
            ->get()
            ->result();

        // $this->db->where('kelas_id', $this->session->userdata('manage'));
        $data['data_siswa'] = $this->db->from('na')
            ->join('data_kelas', 'na.siswa_id = data_kelas.id_dk')
            ->get()
            ->result_array();


        $data['data_semester'] = $this->db->get('thn_pelajaran')->result_array();
        $data['data_kelas'] = $this->db->get('kelas')->result_array();

        $this->db->order_by('date_created', 'DESC');
        $data['tahun'] = $this->db->get('thn_pelajaran')->result();


        $data['datasiswa'] = $this->db->get_where('data_kelas', ['kelas_id' =>
        $this->session->userdata('manage')])->result_array();


        $thn_pelajaran = $this->input->get('thn_pelajaran');
        $kode_mapel = $this->input->get('kode_mapel');
        $data['tampildata'] = $this->Model_data->pencarian($thn_pelajaran, $kode_mapel)->result_array();


        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('pengelolaan/nilai_absensi', $data);
        $this->load->view('templates/footer');
    }

    public function inputNilai()
    {
        
            $siswa_id = $this->input->post('siswa_id');
            $kelas_id = $this->input->post('kelas_id');
            $semester_id = $this->input->post('semester_id');
            $nilai_absen = $this->input->post('nilai_absen');

            $data=[
                'siswa_id' => $siswa_id,
                'kelas_id' => $kelas_id,
                'semester_id' => $semester_id,
                'nilai_absen' => $nilai_absen

            ];
            $this->db->insert('na',$data);
            $this->session->set_flashdata('message', '<div class="alert alert-success text-center" role="alert">Data berhasil disimpan</div>');
            redirect('pengelolaan/nilai_absensi');
    }

    public function nilai_pengetahuan()
    {

        $data['user'] = $this->db->get_where('user', ['username' =>
        $this->session->userdata('username')])->row_array();
        $data['title'] = 'Data Nilai Pengetahuan';

        $data['sekolah'] = $this->db->get_where('identitas_sekolah', "id = 1")->row_array();

        $data['kode'] = $this->db->select('kode_mapel')
            ->from('user')
            ->join('kode_mapel', 'user.manage = kode_mapel.nama_kelas')
            ->get()
            ->result();

        $this->db->order_by('date_created', 'DESC');
        $data['tahun'] = $this->db->get('thn_pelajaran')->result();


        $thn_pelajaran = $this->input->get('thn_pelajaran');
        $kode_mapel = $this->input->get('kode_mapel');
        $data['tampildata'] = $this->Model_data->pencarian($thn_pelajaran, $kode_mapel)->result_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('pengelolaan/nilai_pengetahuan', $data);
        $this->load->view('templates/footer');
    }

    public function nilai_keterampilan()
    {

        $data['user'] = $this->db->get_where('user', ['username' =>
        $this->session->userdata('username')])->row_array();
        $data['title'] = 'Data Nilai Keterampilan';

        $data['sekolah'] = $this->db->get_where('identitas_sekolah', "id = 1")->row_array();

        $data['kode'] = $this->db->select('kode_mapel')
            ->from('user')
            ->join('kode_mapel', 'user.manage = kode_mapel.nama_kelas')
            ->get()
            ->result();

        $this->db->order_by('date_created', 'DESC');
        $data['tahun'] = $this->db->get('thn_pelajaran')->result();


        $thn_pelajaran = $this->input->get('thn_pelajaran');
        $kode_mapel = $this->input->get('kode_mapel');
        $data['tampildata'] = $this->Model_data->pencarian($thn_pelajaran, $kode_mapel)->result_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('pengelolaan/nilai_keterampilan', $data);
        $this->load->view('templates/footer');
    }

    public function rekap_absensi()
    {

        $data['user'] = $this->db->get_where('user', ['username' =>
        $this->session->userdata('username')])->row_array();
        $data['title'] = 'Data Rekap Kehadiran Peserta Didik';

        $data['sekolah'] = $this->db->get_where('identitas_sekolah', "id = 1")->row_array();

        $data['kelas'] = $this->db->get('kelas')->result();
            $data['data_siswa'] = $this->db->get('peserta_didik')->result_array();
            $data['data_semester'] = $this->db->get('thn_pelajaran')->result_array();
            $data['data_kelas'] = $this->db->get('kelas')->result_array();

        $this->db->order_by('date_created', 'DESC');
        $data['tahun'] = $this->db->get('thn_pelajaran')->result();

        $thn_pelajaran = $this->input->get('thn_pelajaran');
        $nama_kelas = $this->input->get('nama_kelas');
        $data['tampildata'] = $this->Model_data->rekapabsen($thn_pelajaran, $nama_kelas)->result_array();


        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('pengelolaan/rekap_absensi', $data);
        $this->load->view('templates/footer');
    }

    public function nilai_ekstrakurikuler()
    {

        $data['user'] = $this->db->get_where('user', ['username' =>
        $this->session->userdata('username')])->row_array();
        $data['title'] = 'Data Nilai Ekstrakurikuler';

        $data['sekolah'] = $this->db->get_where('identitas_sekolah', "id = 1")->row_array();

        $data['kelas'] = $this->db->get('kelas')->result();

        $this->db->order_by('date_created', 'DESC');
        $data['tahun'] = $this->db->get('thn_pelajaran')->result();


        $thn_pelajaran = $this->input->get('thn_pelajaran');
        $nama_kelas = $this->input->get('nama_kelas');
        $data['tampildata'] = $this->Model_data->nilai_ekskul($thn_pelajaran, $nama_kelas)->result_array();


        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('pengelolaan/nilai_ekskul', $data);
        $this->load->view('templates/footer');
    }


    public function erapor()
    {

        $data['user'] = $this->db->get_where('user', ['username' =>
        $this->session->userdata('username')])->row_array();
        $data['title'] = 'Cetak Rapor Kelas';

        $data['sekolah'] = $this->db->get_where('identitas_sekolah', "id = 1")->row_array();

        $data['kelas'] = $this->db->get('kelas')->result();

        $this->db->order_by('date_created', 'DESC');
        $data['tahun'] = $this->db->get('thn_pelajaran')->result();


        $thn_pelajaran = $this->input->get('thn_pelajaran');
        $nama_kelas = $this->input->get('nama_kelas');
        $data['tampildata'] = $this->Model_data->pencariannilai($thn_pelajaran, $nama_kelas)->result_array();

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('pengelolaan/erapor', $data);
        $this->load->view('templates/footer');
    }

    public function peringkat($nisn)
    {

        $data['user'] = $this->db->get_where('user', ['username' =>
        $this->session->userdata('username')])->row_array();
        $data['title'] = 'Cetak Rapor Kelas';

        $data['sekolah'] = $this->db->get_where('identitas_sekolah', "id = 1")->row_array();

        $data['kelas'] = $this->db->get('kelas')->result();

        $this->db->order_by('date_created', 'DESC');
        $data['tahun'] = $this->db->get('thn_pelajaran')->result();


        $thn_pelajaran = $this->input->get('thn_pelajaran');
        $nama_kelas = $this->input->get('nama_kelas');
        $data['tampildata'] = $this->Model_data->pencariannilai($thn_pelajaran, $nama_kelas)->result_array();


        // $data['tampilnilai'] = $this->db->get_where('leger_nilai', "thn_pelajaran = '$thn_pelajaran'")->result_array();

        // $datanilai = "select * from leger_nilai";

        // $nilai = $datanilai['nisn'];
        // $this->db->where('thn_pelajaran', $thn_pelajaran);
        $this->db->where('nisn', $nisn);
        $datanilai = "select *,count(thn_pelajaran) as coutmapel, sum(nilai_akhir) as sum_nilai from leger_nilai where nisn='$nisn'";
        $data['tampilnilai'] = $this->db->query($datanilai)->result_array();




        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('pengelolaan/peringkat', $data);
        $this->load->view('templates/footer');
    }


    public function format_import()
    {

        $data['user'] = $this->db->get_where('user', ['username' =>
        $this->session->userdata('username')])->row_array();
        $data['title'] = 'Format Import';

        $data['sekolah'] = $this->db->get_where('identitas_sekolah', "id = 1")->row_array();







        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('pengelolaan/format_import', $data);
        $this->load->view('templates/footer');
    }

    public function importNP()
    {

        $fileName = $_FILES['file']['name'];

        $config['upload_path'] = './import/datanilai/'; //path upload
        $config['file_name'] = $fileName;  // nama file
        $config['allowed_types'] = 'xls|xlsx|csv'; //tipe file yang diperbolehkan
        $config['max_size'] = 10000; // maksimal size

        $this->load->library('upload'); //meload librari upload
        $this->upload->initialize($config);

        if (!$this->upload->do_upload('file')) {
            echo $this->upload->display_errors();
            exit();
        }

        $inputFileName = './import/datanilai/' . $fileName;

        try {
            $inputFileType = PHPExcel_IOFactory::identify($inputFileName);
            $objReader = PHPExcel_IOFactory::createReader($inputFileType);
            $objPHPExcel = $objReader->load($inputFileName);
        } catch (Exception $e) {
            die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME) . '": ' . $e->getMessage());
        }

        $sheet = $objPHPExcel->getSheet(0);
        $highestRow = $sheet->getHighestRow();
        $highestColumn = $sheet->getHighestColumn();

        for ($row = 2; $row <= $highestRow; $row++) {                  //  Read a row of data into an array                 
            $rowData = $sheet->rangeToArray(
                'A' . $row . ':' . $highestColumn . $row,
                NULL,
                TRUE,
                FALSE
            );

            // Sesuaikan key array dengan nama kolom di database                                                         
            $data = array(
                // "email"=> $rowData[0][0],
                "kode_mapel" => $rowData[0][0],

                "thn_pelajaran" => $rowData[0][1],
                "nisn" => $rowData[0][2],
                "nama_pesertadidik" => $rowData[0][3],
                "nilai_nh" => $rowData[0][4],
                "nilai_pts" => $rowData[0][5],
                "nilai_pas" => $rowData[0][6],
                "nilai_akhir" => $rowData[0][7],
                "deskripsi_np" => $rowData[0][8],
                "nilai_keterampilan" => $rowData[0][9],
                "deskripsi_keterampilan" => $rowData[0][10]



            );

            $insert = $this->db->insert("leger_nilai", $data);
            $this->session->set_flashdata('message', '<div class="alert alert-success text-center" role="alert">Import Data Berhasil </div>');
        }
        redirect('pengelolaan/nilai_pengetahuan');
    }


    public function importabsensi()
    {

        $fileName = $_FILES['file']['name'];

        $config['upload_path'] = './import/absensi/'; //path upload
        $config['file_name'] = $fileName;  // nama file
        $config['allowed_types'] = 'xls|xlsx|csv'; //tipe file yang diperbolehkan
        $config['max_size'] = 10000; // maksimal size

        $this->load->library('upload'); //meload librari upload
        $this->upload->initialize($config);

        if (!$this->upload->do_upload('file')) {
            echo $this->upload->display_errors();
            exit();
        }

        $inputFileName = './import/absensi/' . $fileName;

        try {
            $inputFileType = PHPExcel_IOFactory::identify($inputFileName);
            $objReader = PHPExcel_IOFactory::createReader($inputFileType);
            $objPHPExcel = $objReader->load($inputFileName);
        } catch (Exception $e) {
            die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME) . '": ' . $e->getMessage());
        }

        $sheet = $objPHPExcel->getSheet(0);
        $highestRow = $sheet->getHighestRow();
        $highestColumn = $sheet->getHighestColumn();

        for ($row = 2; $row <= $highestRow; $row++) {                  //  Read a row of data into an array                 
            $rowData = $sheet->rangeToArray(
                'A' . $row . ':' . $highestColumn . $row,
                NULL,
                TRUE,
                FALSE
            );

            // Sesuaikan key array dengan nama kolom di database                                                         
            $data = array(
                // "email"=> $rowData[0][0],
                "nama_kelas" => $rowData[0][0],

                "thn_pelajaran" => $rowData[0][1],
                "nisn" => $rowData[0][2],
                "nama_pesertadidik" => $rowData[0][3],
                "jumlah_alpa" => $rowData[0][4],
                "jumlah_izin" => $rowData[0][5],
                "jumlah_sakit" => $rowData[0][6],



            );

            $insert = $this->db->insert("rekap_absensi", $data);
            $this->session->set_flashdata('message', '<div class="alert alert-success text-center" role="alert">Import Data Berhasil </div>');
        }
        redirect('pengelolaan/rekap_absensi');
    }

    public function importnilaiekskul()
    {

        $fileName = $_FILES['file']['name'];

        $config['upload_path'] = './import/ekskul/'; //path upload
        $config['file_name'] = $fileName;  // nama file
        $config['allowed_types'] = 'xls|xlsx|csv'; //tipe file yang diperbolehkan
        $config['max_size'] = 10000; // maksimal size

        $this->load->library('upload'); //meload librari upload
        $this->upload->initialize($config);

        if (!$this->upload->do_upload('file')) {
            echo $this->upload->display_errors();
            exit();
        }

        $inputFileName = './import/ekskul/' . $fileName;

        try {
            $inputFileType = PHPExcel_IOFactory::identify($inputFileName);
            $objReader = PHPExcel_IOFactory::createReader($inputFileType);
            $objPHPExcel = $objReader->load($inputFileName);
        } catch (Exception $e) {
            die('Error loading file "' . pathinfo($inputFileName, PATHINFO_BASENAME) . '": ' . $e->getMessage());
        }

        $sheet = $objPHPExcel->getSheet(0);
        $highestRow = $sheet->getHighestRow();
        $highestColumn = $sheet->getHighestColumn();

        for ($row = 2; $row <= $highestRow; $row++) {                  //  Read a row of data into an array                 
            $rowData = $sheet->rangeToArray(
                'A' . $row . ':' . $highestColumn . $row,
                NULL,
                TRUE,
                FALSE
            );

            // Sesuaikan key array dengan nama kolom di database                                                         
            $data = array(
                // "email"=> $rowData[0][0],
                "nama_kelas" => $rowData[0][0],

                "thn_pelajaran" => $rowData[0][1],
                "nisn" => $rowData[0][2],
                "nama_pesertadidik" => $rowData[0][3],
                "nama_ekskul" => $rowData[0][4],
                "nilai_ekskul" => $rowData[0][5],




            );

            $insert = $this->db->insert("leger_ekskul", $data);
            $this->session->set_flashdata('message', '<div class="alert alert-success text-center" role="alert">Import Data Berhasil </div>');
        }
        redirect('pengelolaan/nilai_ekstrakurikuler');
    }
}
