<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Student extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        $this->load->library('form_validation');
        $this->load->model('Model_data');
    }


    public function index()
    {

        $this->form_validation->set_rules('nisn', 'nisn', 'trim|required');
        $this->form_validation->set_rules('password', 'password', 'trim|required');

        if ($this->form_validation->run() == false) {
            $data['title'] = 'Sistem Informasi Hasil Belajar';
            $data['sekolah'] = $this->db->get_where('identitas_sekolah', "id='1'")->row();

            $this->load->view('student/login', $data);
        } else {
            $this->_login();
        }
    }

    private function _login()
    {
        $nisn = $this->input->post('nisn');
        $password = $this->input->post('password');


        $user = $this->db->get_where('peserta_didik', ['nisn' => $nisn])->row_array();

        if ($user) {
            //Jika dicek sudah ada user

            if ($user['status_pd'] == 'Aktif') {
                //Jika user sudah aktif
                if (password_verify($password, $user['password'])) {
                    //Cek Password

                    $data = [
                        'nisn' => $user['nisn'],

                    ];
                    $this->session->set_userdata($data);

                    redirect('student/dashboard');
                } else {
                    $this->session->set_flashdata('message', '<div class="alert alert-danger text-center" role="alert">
			Password incorect!
		  </div>');
                    redirect('student');
                }
            } else {
                $this->session->set_flashdata('message', '<div class="alert alert-danger text-center" role="alert">
			Username has not been activated!
		  </div>');
                redirect('student');
            }
        } else {
            $this->session->set_flashdata('message', '<div class="alert alert-danger text-center" role="alert">
			Username is not registered!
		  </div>');
            redirect('student');
        }
    }





    public function dashboard()
    {

        $data['user'] = $this->db->get_where('peserta_didik', ['nisn' =>
        $this->session->userdata('nisn')])->row_array();

        $data['sekolah'] = $this->db->get_where('identitas_sekolah', "id = 1")->row_array();
        $data['title'] = 'Dashboard';

        $this->load->view('student/header', $data);
        $this->load->view('student/sidebar', $data);
        $this->load->view('student/topbar', $data);
        $this->load->view('student/dashboard', $data);
        $this->load->view('student/footer');
    }

    public function hasil_belajar()
    {

        $data['user'] = $this->db->get_where('peserta_didik', ['nisn' =>
        $this->session->userdata('nisn')])->row_array();

        $data['sekolah'] = $this->db->get_where('identitas_sekolah', "id = 1")->row_array();
        $data['title'] = 'Hasil Belajar';

        $this->db->order_by('date_created', 'DESC');
        $data['tahun'] = $this->db->get('thn_pelajaran')->result();


        $this->load->view('student/header', $data);
        $this->load->view('student/sidebar', $data);
        $this->load->view('student/topbar', $data);
        $this->load->view('student/hasil_belajar', $data);
        $this->load->view('student/footer');
    }

    public function data_akademik()
    {

        $data['user'] = $this->db->get_where('peserta_didik', ['nisn' =>
        $this->session->userdata('nisn')])->row_array();



        $data['sekolah'] = $this->db->get_where('identitas_sekolah', "id = 1")->row_array();
        $data['title'] = 'Hasil Belajar';

        $thn_pelajaran = $this->input->get('thn_pelajaran');
        $nisn_id = $this->input->get('studentID');
        // $data['tampildata'] = $this->Model_data->dataNilai($thn_pelajaran, $nisn_pd)->result_array();

        $this->db->join('kode_mapel', 'leger_nilai.kode_mapel = kode_mapel.kode_mapel');
        $data['tampildata'] = $this->db->get_where('leger_nilai', "nisn = '$nisn_id' AND thn_pelajaran = '$thn_pelajaran'")->row_array();

        $this->db->select_sum('nilai_akhir');
        $data['sum'] = $this->db->get_where('leger_nilai', "nisn = '$nisn_id' AND thn_pelajaran = '$thn_pelajaran'")->row_array();

        $this->db->select_avg('nilai_akhir');
        $data['average'] = $this->db->get_where('leger_nilai', "nisn = '$nisn_id' AND thn_pelajaran = '$thn_pelajaran'")->row_array();

        $this->db->join('kode_mapel', 'leger_nilai.kode_mapel = kode_mapel.kode_mapel');
        $data['tampilnilai'] = $this->db->get_where('leger_nilai', "nisn = '$nisn_id' AND thn_pelajaran = '$thn_pelajaran'")->result_array();


        $data['ekskul'] = $this->db->get_where('leger_ekskul', "nisn = '$nisn_id' AND thn_pelajaran = '$thn_pelajaran'")->result_array();

        $data['absen'] = $this->db->get_where('rekap_absensi', "nisn = '$nisn_id' AND thn_pelajaran = '$thn_pelajaran'")->result_array();




        $this->load->view('student/header', $data);
        $this->load->view('student/sidebar', $data);
        $this->load->view('student/topbar', $data);
        $this->load->view('student/data_akademik', $data);
        $this->load->view('student/footer');
    }







    public function logout()
    {
        $this->session->unset_userdata('username');
        $this->session->unset_userdata('role_id');


        redirect('student');
    }


    public function blocked()
    {
        $data['title'] = 'Access Blocked';
        $this->load->view('templates/auth_header.php', $data);
        $this->load->view('auth/blocked');
    }
}
