<?php
defined('BASEPATH') or exit('No direct script access allowed');

class User extends CI_Controller
{

    public function __construct()
    {
        parent::__construct();
        is_logged_in();
    }



    public function index()
    {
        $data['user'] = $this->db->get_where('user', ['username' =>
        $this->session->userdata('username')])->row_array();

        $data['sekolah'] = $this->db->get_where('identitas_sekolah', "id = 1")->row_array();
        $data['title'] = 'Dashboard';

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('user/index', $data);
        $this->load->view('templates/footer');
    }

    public function hasil_belajar()
    {
        $data['cekstatus']     = $this->db->get_where('status_pengumuman', "id ='1'")->row();
        $data['user'] = $this->db->get_where('user', ['username' =>
        $this->session->userdata('username')])->row_array();
        $data['sekolah'] = $this->db->get_where('identitas_sekolah', "id = 1")->row_array();
        $data['title'] = 'Hasil Belajar';

        $this->load->view('templates/header', $data);
        $this->load->view('templates/sidebar', $data);
        $this->load->view('templates/topbar', $data);
        $this->load->view('user/pengumuman', $data);
        $this->load->view('templates/footer');
    }

    public function cetak()
    {
        $data['cekstatus']     = $this->db->get_where('status_pengumuman', "id ='1'")->row();
        $data['user'] = $this->db->get_where('user', ['username' =>
        $this->session->userdata('username')])->row_array();
        $data['title'] = "Cetak Surat Keterangan Kelulusan ";



        $this->load->view('user/cetak', $data);
    }
}
