<?php
defined('BASEPATH') or exit('No direct script access allowed');

class Model_data extends CI_Model
{



	public function date($aksi)
	{
		date_default_timezone_set('Asia/Jakarta');
		if ($aksi == 'waktu') {
			$date	 = date('d-m-Y H:i:s');
		} elseif ($aksi == 'waktu_default') {
			$date	 = date('Y-m-d H:i:s');
		} elseif ($aksi == 'thn') {
			$date	 = date('Y');
		} elseif ($aksi == 'bln') {
			$date	 = date('m');
		} elseif ($aksi == 'tgl_default') {
			$date	 = date('Y-m-d');
		} elseif ($aksi == 'tgl') {
			$date	 = date('d-m-Y');
		} elseif ($aksi == 'jam') {
			$date	 = date('H:i:s');
		} else {
			$date  = 'Null';
		}

		return $date;
	}

	public static function tgl_id($date)
	{
		$str = explode('-', $date);
		$bulan = array(
			'01' => 'Januari',
			'02' => 'Februari',
			'03' => 'Maret',
			'04' => 'April',
			'05' => 'Mei',
			'06' => 'Juni',
			'07' => 'Juli',
			'08' => 'Agustus',
			'09' => 'September',
			'10' => 'Oktober',
			'11' => 'November',
			'12' => 'Desember',
		);
		return $str['0'] . " " . $bulan[$str[1]] . " " . $str[2];
	}

	public static function bln_id($date)
	{
		$str = explode('-', $date);
		$bulan = array(
			'01' => 'Januari',
			'02' => 'Februari',
			'03' => 'Maret',
			'04' => 'April',
			'05' => 'Mei',
			'06' => 'Juni',
			'07' => 'Juli',
			'08' => 'Agustus',
			'09' => 'September',
			'10' => 'Oktober',
			'11' => 'November',
			'12' => 'Desember',
		);
		return $bulan[$str[0]];
	}

	public function pencarian($thn_pelajaran, $kode_mapel)
	{
		$this->db->where("thn_pelajaran", $thn_pelajaran);
		$this->db->where("kode_mapel", $kode_mapel);
		return $this->db->get("leger_nilai");
	}

	public function pencariannilai($thn_pelajaran, $nama_kelas)
	{
		$this->db->select('*, count(thn_pelajaran) as coutmapel, sum(nilai_akhir) as sum_nilai');
		$this->db->from('leger_nilai');
		$this->db->join('kode_mapel', 'leger_nilai.kode_mapel = kode_mapel.kode_mapel');
		$this->db->where("thn_pelajaran", $thn_pelajaran);
		$this->db->where("nama_kelas", $nama_kelas);
		$this->db->group_by("nisn");
		$this->db->order_by("sum_nilai", "DESC");
		$query 		= $this->db->get();

		return $query;
	}


	public function rekapabsen($thn_pelajaran, $nama_kelas)
	{
		$this->db->where("thn_pelajaran", $thn_pelajaran);
		$this->db->where("nama_kelas", $nama_kelas);
		return $this->db->get("rekap_absensi");
	}

	public function nilai_ekskul($thn_pelajaran, $nama_kelas)
	{
		$this->db->where("thn_pelajaran", $thn_pelajaran);
		$this->db->where("nama_kelas", $nama_kelas);
		return $this->db->get("leger_ekskul");
	}

	public function countMapel($thn_pelajaran, $nisn)
	{
		$this->db->select('*');
		$this->db->from('leger_nilai');

		$this->db->where('thn_pelajaran', $thn_pelajaran);
		$this->db->where('nisn', $nisn);
		$query = $this->db->get();
		$execute = $query->num_rows();
		return $execute;
	}

	public function pencariannilaibackup($thn_pelajaran, $nama_kelas)
	{
		$this->db->select('*');
		$this->db->from('leger_nilai');
		$this->db->join('kode_mapel', 'leger_nilai.kode_mapel = kode_mapel.kode_mapel');
		$this->db->where("thn_pelajaran", $thn_pelajaran);
		$this->db->where("nama_kelas", $nama_kelas);
		$query 		= $this->db->get();

		return $query;
	}
}
