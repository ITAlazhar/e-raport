<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->

    <div class="col-lg-4">
        <?= $this->session->flashdata('message'); ?>

    </div>

    <div class="card mb-12 f-w">
        <div class="row no-gutters">
            <div class="col-md-12">
                <div class="card-body ">
                    <?= form_open_multipart('admin/data_sekolah'); ?>
                    <div class="form-group row">
                        <label for="nama_sekolah" class="col-sm-2 col-form-label">Nama Sekolah</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="nama_sekolah" name="nama_sekolah" value="<?= $sekolah['nama_sekolah']; ?>">
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="tp" class="col-sm-2 col-form-label">NPSN</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="tahun_pelajaran" name="npsn" value="<?= $sekolah['npsn']; ?>">
                            <?= form_error('npsn', '<small class="text-danger pl-3">', '</small>'); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="tp" class="col-sm-2 col-form-label">Alamat Sekolah</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="alamat_sekolah" name="alamat_sekolah" value="<?= $sekolah['alamat_sekolah']; ?>">
                            <?= form_error('alamat_sekolah', '<small class="text-danger pl-3">', '</small>'); ?>
                        </div>
                    </div>
                    <div class="form-group row">
                        <label for="tp" class="col-sm-2 col-form-label">Kecamatan</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="kecamatan" name="kecamatan" value="<?= $sekolah['kecamatan']; ?>">
                            <?= form_error('kecamatan', '<small class="text-danger pl-3">', '</small>'); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="tp" class="col-sm-2 col-form-label">Kabupaten</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="kabupaten" name="kabupaten" value="<?= $sekolah['kabupaten']; ?>">
                            <?= form_error('kabupaten', '<small class="text-danger pl-3">', '</small>'); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="tp" class="col-sm-2 col-form-label">Provinsi</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="provinsi" name="provinsi" value="<?= $sekolah['provinsi']; ?>">
                            <?= form_error('provinsi', '<small class="text-danger pl-3">', '</small>'); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="tp" class="col-sm-2 col-form-label">Telepon</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="telepon" name="telepon" value="<?= $sekolah['telepon']; ?>">
                            <?= form_error('kode_pos', '<small class="text-danger pl-3">', '</small>'); ?>
                        </div>
                    </div>


                    <div class="form-group row">
                        <label for="tp" class="col-sm-2 col-form-label">Kode Pos</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="kode_pos" name="kode_pos" value="<?= $sekolah['kode_pos']; ?>">
                            <?= form_error('kode_pos', '<small class="text-danger pl-3">', '</small>'); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="tp" class="col-sm-2 col-form-label">Email Sekolah</label>
                        <div class="col-sm-10">
                            <input type="text" class="form-control" id="email_sekolah" name="email_sekolah" value="<?= $sekolah['email_sekolah']; ?>">
                            <?= form_error('email_sekolah', '<small class="text-danger pl-3">', '</small>'); ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <div class="col-sm-2">Logo Sekolah</div>
                        <div class="col-sm-10">
                            <div class="row">
                                <div class="col-sm-3">
                                    <img src="<?= base_url('assets/img/profile/') . $sekolah['logo'] ?>" class="img-thumbnail">
                                </div>
                                <div class="col-sm-9">
                                    <div class="custom-file">
                                        <input type="file" class="custom-file-input" id="image" name="image">
                                        <label class="custom-file-label" for="image">Choose file</label>
                                    </div>

                                </div>
                            </div>
                        </div>
                    </div>
                    <div class="form-group row justify-content-end">
                        <div class="col-sm-10">
                            <button type="submit" class="btn btn-info">
                                Update Profile
                            </button>
                        </div>
                    </div>
                </div>

            </div>

        </div>
    </div>

</div>

<!-- /.container-fluid -->

</div>
<!-- End of Main Content -->