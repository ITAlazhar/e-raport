<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->

    <div class="col-lg-4">
        <?= $this->session->flashdata('message'); ?>
        <?= form_error('subusername', '<div class="alert alert-danger" role="alert">', '</div>'); ?>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <a href="" class="btn btn-info mb-3" data-toggle="modal" data-target="#newUsersModal"><i class="fa fa-plus-circle"></i> Tambah Wali Kelas</a>


            <div class="card">
                <div class="card-body">


                    <div class="table-responsive m-t-10">
                        <table id="editable-datatable" class="table table-bordered table-striped">
                            <thead>
                                <tr align="center">
                                    <th scope="col" width="20">#</th>
                                    <th scope="col">Username</th>
                                    <th scope="col">Nama Wali Kelas</th>
                                    <th scope="col">Status</th>
                                    <th scope="col">Role ID</th>
                                    <th scope="col">Manage</th>
                                    <th width="80px;">Action</th>


                                </tr>
                            </thead>
                            <tbody>
                                <?php $i = 1; ?>
                                <?php foreach ($siswa as $sw) : ?>
                                    <tr>
                                        <td align="center"><?= $i; ?></td>
                                        <td align="center"><?= $sw['username']; ?></td>
                                        <td><?= $sw['name']; ?></td>
                                        <td align="center">
                                            <?php

                                            if ($sw['is_active'] == 1) {

                                                echo "active";
                                            } else {

                                                echo "inactive";
                                            }




                                            ?>



                                        </td>
                                        <td align="center">
                                            <?php

                                            if ($sw['role_id'] == 2) {

                                                echo "Wali Kelas";
                                            } else {

                                                echo "Admin";
                                            }




                                            ?>

                                        </td>
                                        <td align="center"><?= $sw['manage']; ?></td>


                                        <td align="center">
                                            <!--   <a href="" class="badge badge-success">edit</a> -->
                                            <a href="" data-toggle="modal" data-target="#editData<?= $sw['id'] ?>" data-toggle="tooltip" data-original-title="Edit" target="_blank"><i class="ti-pencil-alt m-r-10"></i></a>
                                            <a href="<?php echo base_url('admin/delete/' . $sw['username']); ?>" data-toggle="tooltip" data-original-title="Hapus" onclick="return confirm('Data ini dihapus?')"><i class="ti-trash m-r-10"></i></a>

                                        </td>

                                    </tr>
                                    <?php $i++; ?>
                                <?php endforeach; ?>

                            </tbody>
                        </table>

                    </div>

                </div>


            </div>


            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->

        <!-- Modal -->
        <div class="modal fade" id="newUsersModal" tabindex="-1" role="dialog" aria-labelledby="newUsersModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="newUserModalsLabel">Tambah Wali Kelas</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form class="user" method="post" action="<?= base_url('admin/data_user') ?>">
                        <div class="modal-body">
                            <div class="form-group">
                                <input type="text" class="form-control" id="subname" name="subname" placeholder="Nama Lengkap">
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" id="subusername" name="subusername" placeholder="Username">

                            </div>
                            <div class="form-group">
                                <input type="password" class="form-control" id="subpassword" name="subpassword" placeholder="Password">
                            </div>
                            <div class="form-group">
                                <select name="is_active" id="is_active" class="form-control">
                                    <option>Status</option>
                                    <option value="1">Active</option>
                                    <option value="0">Inactive</option>

                                </select>
                            </div>
                            <div class="form-group">
                                <select name="manage" id="manage" class="form-control">
                                    <option value="">Manage</option>
                                    <?php foreach ($kelas as $baris) : ?>
                                        <option value="<?php echo $baris->nama_kelas; ?>"><?php echo $baris->nama_kelas; ?></option>
                                    <?php endforeach; ?>


                                </select>
                            </div>

                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
                            <button type="submit" class="btn btn-info">Tambah Wali Kelas</button>
                        </div>
                    </form>
                </div>
            </div>

        </div>


        <!-- Edit user -->
        <?php foreach ($siswa as $sw) : ?>
            <div class="modal fade" id="editData<?= $sw['id'] ?>" tabindex="-1" role="dialog" aria-labelledby="editData<?= $sw['id'] ?>" aria-hidden="true">
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="editData<?= $sw['id'] ?>">Edit Data</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <form action="<?= base_url('admin/editdata/' . $sw['id']); ?>" method="post">
                            <div class="modal-body">
                                <div class="form-group">
                                    <label>Nama Lengkap</label>
                                    <input type="text" class="form-control" value="<?= $sw['name'] ?>" id="editname" name="editname" placeholder="Nama Siswa">
                                </div>

                                <div class="form-group">
                                    <label>Status</label>
                                    <select name="is_active" id="is_active" class="form-control">
                                        <option>
                                            <?php

                                            if ($sw['is_active'] == 1) {

                                                echo "active";
                                            } else {

                                                echo "inactive";
                                            }




                                            ?>


                                        </option>
                                        <option value="1">Active</option>
                                        <option value="0">Inactive</option>

                                    </select>
                                </div>

                                <div class="form-group">
                                    <select name="manage" id="manage" class="form-control">
                                        <option value="">Manage</option>
                                        <?php foreach ($kelas as $baris) : ?>
                                            <option value="<?php echo $baris->nama_kelas; ?>"><?php echo $baris->nama_kelas; ?></option>
                                        <?php endforeach; ?>


                                    </select>
                                </div>






                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">Batal</button>
                                <button type="submit" class="btn btn-primary">Simpan</button>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        <?php endforeach; ?>
        <!-- End edit Modal -->







    </div>
</div>
</div>
</div>