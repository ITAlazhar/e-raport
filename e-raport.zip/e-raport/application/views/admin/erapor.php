<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->

    <div class="col-lg-4">
        <?= $this->session->flashdata('message'); ?>

    </div>




    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <form method="get" action="<?php echo base_url("admin/erapor") ?>">
                        <div class="form-group m-t-40 row">
                            <label for="example-text-input" class="col-2 col-form-label">Tahun Pelajaran</label>
                            <div class="col-10">
                                <select name="thn_pelajaran" id="thn_pelajaran" class="form-control">

                                    <?php foreach ($tahun as $baris) : ?>
                                        <option value="<?php echo $baris->thn_pelajaran; ?>"><?php echo $baris->thn_pelajaran; ?></option>
                                    <?php endforeach; ?>


                                </select>
                            </div>
                        </div>

                        <div class="form-group m-t-40 row">
                            <label for="example-text-input" class="col-2 col-form-label">Nama Kelas</label>
                            <div class="col-10">
                                <select name="nama_kelas" id="nama_kelas" class="form-control">
                                    <option value="">Pilih Kelas</option>
                                    <?php foreach ($kelas as $baris) : ?>
                                        <option value="<?php echo $baris->nama_kelas; ?>"><?php echo $baris->nama_kelas; ?></option>
                                    <?php endforeach; ?>


                                </select>

                                </select>
                            </div>
                        </div>


                        <div class="card-body text-center">
                            <form action="" method="post">
                                <button type="submit" class="btn btn-info"><i class="icon-search"></i> Tampilkan Data</button>
                            </form>
                        </div>




                    </form>
                </div>
            </div>


            <div class="card">
                <div class="card-body">
                    <div class="row page-titles">

                        <div class="col-md-12 align-self-center text-right">
                            <div class="d-flex justify-content-end align-items-center">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="javascript:void(0)">Dashboard</a></li>
                                    <li class="breadcrumb-item active">Rapor</li>
                                </ol>

                            </div>
                        </div>
                    </div>
                </div>



                <div class="card-body">


                    <h4 align="center">
                        <b> Daftar Nilai Rapor <?= $user['manage']; ?>

                            <br> Tahun Pelajaran <?= $thn_pelajaran = $this->input->get('thn_pelajaran'); ?>
                        </b>
                    </h4>

                    <div class="table-responsive m-t-10">
                        <table id="myTable" class="table table-bordered table-striped">
                            <thead>
                                <tr align="center">
                                    <th scope="col" width="20">#</th>

                                    <th scope="col">Tahun Pelajaran</th>
                                    <th scope="col">NISN</th>
                                    <th scope="col">Nama Peserta Didik</th>
                                    <th scope="col">Jumlah Mapel</th>
                                    <th scope="col">Nilai Pengetahuan</th>
                                    <th scope="col">Peringkat</th>
                                    <th scope="col">Action</th>



                                </tr>
                            </thead>
                            <tbody>




                                <?php $i = 1; ?>
                                <?php foreach ($tampildata as $list) : ?>




                                    <tr data-id=>
                                        <td align="center"><?= $i; ?></td>

                                        <td align="center"><?= $thnpelajaran = $list['thn_pelajaran']; ?></td>
                                        <td align="center"><?= $list['nisn']; ?></td>
                                        <td align="center"><?= $list['nama_pesertadidik']; ?></td>

                                        <td align="center"><?= $list['coutmapel']; ?> </td>



                                        <td align="center"><b><?= $list['sum_nilai']; ?></b></td>
                                        <td align="center"> <?= $i; ?></td>

                                        <td></td>



                                    </tr>
                                    <?php $i++; ?>
                                <?php endforeach; ?>


                            </tbody>
                        </table>

                    </div>

                </div>


            </div>


            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->


    </div>
</div>
</div>
</div>