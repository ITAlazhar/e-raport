<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->

    <div class="col-lg-4">
        <?= $this->session->flashdata('message'); ?>

    </div>
    <div class="row">
        <div class="col-lg-12">
            <a href="" class="btn btn-info mb-3" data-toggle="modal" data-target="#newUsersModal"><i class="fa fa-plus-circle"></i> Tambah Tahun Pelajaran</a>


            <div class="card">
                <div class="card-body">


                    <div class="table-responsive m-t-10">
                        <table id="myTable" class="table table-bordered table-striped">
                            <thead>
                                <tr align="center">
                                    <th scope="col" width="20">#</th>
                                    <th scope="col">Tahun Pelajaran</th>

                                    <th width="80px;">Action</th>


                                </tr>
                            </thead>
                            <tbody>
                                <?php $i = 1; ?>
                                <?php foreach ($tahun as $ta) : ?>
                                    <tr>
                                        <td align="center"><?= $i; ?></td>
                                        <td align="center"><?= $ta['thn_pelajaran']; ?></td>



                                        <td align="center">
                                            <!--   <a href="" class="badge badge-success">edit</a> -->

                                            <a href="" data-toggle="tooltip" data-original-title="Hapus" onclick="return confirm('Data ini dihapus?')"><i class="ti-trash m-r-10"></i></a>

                                        </td>

                                    </tr>
                                    <?php $i++; ?>
                                <?php endforeach; ?>

                            </tbody>
                        </table>

                    </div>

                </div>


            </div>


            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->

        <!-- Modal -->
        <div class="modal fade" id="newUsersModal" tabindex="-1" role="dialog" aria-labelledby="newUsersModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="newUserModalsLabel">Tambah Tahun Pelajaran</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form class="user" method="post" action="<?= base_url('admin/tahun_pelajaran') ?>">
                        <div class="modal-body">
                            <div class="form-group">
                                <label>Nama Tahun Pelajaran</label>
                                <input type="text" class="form-control" id="thn_pelajaran" name="thn_pelajaran" placeholder="Nama Tahun Pelajaran">
                            </div>


                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-info">Tambah Tahun Pelajaran</button>
                        </div>
                    </form>
                </div>
            </div>

        </div>










    </div>
</div>
</div>
</div>