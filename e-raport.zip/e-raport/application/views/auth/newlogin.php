<!DOCTYPE html>
<html lang="en">

<head>
    <title><?= $title . ' ' . $sekolah->nama_sekolah; ?></title>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!--===============================================================================================-->
    <link rel="icon" type="image/png" href="<?= base_url('assets/img/profile/') . $sekolah->logo; ?>" />
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?= base_url('assets/'); ?>login/vendor/bootstrap/css/bootstrap.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?= base_url('assets/'); ?>login/fonts/font-awesome-4.7.0/css/font-awesome.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?= base_url('assets/'); ?>login/fonts/Linearicons-Free-v1.0.0/icon-font.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?= base_url('assets/'); ?>login/vendor/animate/animate.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?= base_url('assets/'); ?>login/vendor/css-hamburgers/hamburgers.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?= base_url('assets/'); ?>login/vendor/select2/select2.min.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" type="text/css" href="<?= base_url('assets/'); ?>login/css/util.css">
    <link rel="stylesheet" type="text/css" href="<?= base_url('assets/'); ?>login/css/main.css">
    <!--===============================================================================================-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.0.0/animate.min.css" />
</head>

<body>

    <div class="limiter">

        <div class="container-login100" style="background-image: url('<?= base_url('assets/'); ?>img/background.jpg');">
            <br><br>
            <div class="login100-form-avatar animate__animated animate__fadeInDown">


                <img src="<?= base_url('assets/img/profile/') . $sekolah->logo; ?>" alt="AVATAR">
            </div>

            <span class="login100-form-title animate__animated animate__fadeInLeft">
                SISTEM MONITORING HASIL BELAJAR<br><?= $sekolah->nama_sekolah; ?>
            </span>


            <div class="wrap-login100 animate__animated animate__fadeIn">
                <?= $this->session->flashdata('message'); ?>
                <form class="login100-form validate-form" method="POST" action="<?= base_url('auth'); ?>">
                    <div class="wrap-input100 validate-input m-b-10" data-validate="Username is required">
                        <input class="input100" type="text" id="username" name="username" placeholder="Username">
                        <span class="focus-input100"></span>
                        <span class="symbol-input100">
                            <i class="fa fa-user"></i>
                        </span>

                    </div>

                    <div class="wrap-input100 validate-input m-b-10" data-validate="Password is required">
                        <input class="input100" type="password" id="password" name="password" placeholder="Password">
                        <span class="focus-input100"></span>
                        <span class="symbol-input100">
                            <i class="fa fa-lock"></i>
                        </span>
                        <?= form_error('password', '<small class="text-danger pl-3">', '</small>'); ?>
                    </div>



                    <div class="container-login100-form-btn p-t-10 p-b-80">
                        <button class="login100-form-btn" type="submit">
                            Login
                        </button>
                    </div>
                    <!--
                    <div class="text-center w-full p-t-25 p-b-230">
                        <a href="#" class="txt1">
                            Forgot Username / Password?
                        </a>
                    </div>

                    <div class="text-center w-full">
                        <a class="txt1" href="#">
                            Create new account
                            <i class="fa fa-long-arrow-right"></i>
                        </a>
                    </div> -->
                </form>
            </div>
        </div>
    </div>




    <!--===============================================================================================
    <script src="<?= base_url('assets/'); ?>login/vendor/jquery/jquery-3.2.1.min.js"></script>
    <!--===============================================================================================-
    <script src="<?= base_url('assets/'); ?>login/vendor/bootstrap/js/popper.js"></script>
    <script src="<?= base_url('assets/'); ?>login/vendor/bootstrap/js/bootstrap.min.js"></script>
    <!--===============================================================================================
    <script src="<?= base_url('assets/'); ?>login/vendor/select2/select2.min.js"></script>
    <!--===============================================================================================
    <script src="<?= base_url('assets/'); ?>login/js/main.js"></script> -->

</body>

</html>