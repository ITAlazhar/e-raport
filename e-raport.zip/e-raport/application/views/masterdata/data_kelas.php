<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->

    <div class="col-lg-4">
        <?= $this->session->flashdata('message'); ?>
        <?= form_error('subusername', '<div class="alert alert-danger" role="alert">', '</div>'); ?>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <a href="" class="btn btn-info mb-3" data-toggle="modal" data-target="#newUsersModal"><i class="fa fa-plus-circle"></i> Tambahkan Kelas Baru</a>
            <a href="" class="btn btn-primary mb-3" data-toggle="modal" data-target="#newUserskelasModal"><i class="fa fa-plus-circle"></i> Tambahkan Siswa Kelas Baru</a>


            <div class="card">
                <div class="card-body">
                    <div class="table-responsive m-t-10">
                        <table id="myTable" class="table table-bordered table-striped">
                            <thead>
                                <tr align="center">
                                    <th scope="col" width="20">#</th>
                                    <th scope="col">Nama Kelas</th>
                                    <th scope="col" width="80px;">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $i = 1; ?>
                                <?php foreach ($data_kelas as $k) : ?>
                                    <tr>
                                        <td align="center"><?= $i; ?></td>
                                        <td align="center"><?= $k['nama_kelas']; ?></td>
                                        <td align="center">
                                            <!--   <a href="" class="badge badge-success">edit</a> -->
                                            <a href="<?php echo base_url('masterdata/delete/' . $k['nama_kelas']); ?>" data-toggle="tooltip" data-original-title="Hapus" onclick="return confirm('Data ini dihapus?')"><i class="ti-trash m-r-10"></i></a>
                                        </td>
                                    </tr>
                                    <?php $i++; ?>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>

            <div class="card">
                <div class="card-body">
                    <div class="table-responsive m-t-10">
                        <table id="myTable1" class="table table-bordered table-striped">
                            <thead>
                                <tr align="center">
                                    <th scope="col" width="20">#</th>
                                    <th scope="col">Semester</th>
                                    <th scope="col">Nama Kelas</th>
                                    <th scope="col">Siswa</th>
                                    <th scope="col">Action</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $i = 1; ?>
                                <?php foreach ($kelas as $k) : ?>
                                    <tr>
                                        <td align="center"><?= $i; ?></td>
                                        <td align="center"><?= $k['semester_id']; ?></td>
                                        <td align="center"><?= $k['kelas_id']; ?></td>
                                        <td align="center"><?= $k['siswa_id']; ?></td>
                                        <td align="center">
                                            <!--   <a href="" class="badge badge-success">edit</a> -->
                                            <a href="<?php echo base_url('masterdata/delete/' . $k['id_dk']); ?>" data-toggle="tooltip" data-original-title="Hapus" onclick="return confirm('Data ini dihapus?')"><i class="ti-trash m-r-10"></i></a>
                                        </td>
                                    </tr>
                                    <?php $i++; ?>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>


            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->

        <!-- Modal -->
        <div class="modal fade" id="newUsersModal" tabindex="-1" role="dialog" aria-labelledby="newUsersModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="newUserModalsLabel">Tambahkan Kelas Baru</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form class="user" method="post" action="<?= base_url('masterdata/data_kelas') ?>">
                        <div class="modal-body">
                            <div class="form-group">
                                <input type="text" class="form-control" id="nama_kelas" name="nama_kelas" placeholder="Nama Kelas">
                            </div>


                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
                            <button type="submit" class="btn btn-info">Tambah Kelas Baru</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <!-- Modal Siswa -->
        <div class="modal fade" id="newUserskelasModal" tabindex="-1" role="dialog" aria-labelledby="newUsersModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="newUserModalsLabel">Tambahkan Siswa Kelas Baru</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form class="user" method="post" action="<?= base_url('masterdata/kelas') ?>">
                        <div class="modal-body">
                            <div class="form-group">
                                <span>Nama Siswa</span>
                                <select class="form-control" name="siswa_id">
                                    <option selected="" disabled="">-- Select Siswa --</option>
                                    <?php foreach ($data_siswa as $siswa):?>
                                    <option value="<?= $siswa['nama_lengkap']; ?>"><?= $siswa['nama_lengkap']; ?></option>
                                    <?php endforeach;?> 
                                </select>
                            </div>
                            <div class="form-group">
                                <span>Kelas</span>
                                <select class="form-control" name="kelas_id">
                                    <option selected="" disabled="">-- Select Kelas --</option>
                                    <?php foreach ($data_kelas as $kelas):?>
                                    <option value="<?= $kelas['nama_kelas']; ?>"><?= $kelas['nama_kelas']; ?></option>
                                    <?php endforeach;?> 
                                </select>
                            </div>
                            <div class="form-group">
                                <span>Semester</span>
                                <select class="form-control" name="semester_id">
                                    <option selected="" disabled="">-- Select Semester</option>
                                    <?php foreach ($data_semester as $semester):?>
                                    <option value="<?= $semester['thn_pelajaran']; ?>"><?= $semester['thn_pelajaran']; ?></option>
                                    <?php endforeach;?> 
                                </select>
                            </div>


                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
                            <button type="submit" class="btn btn-info">Tambah Kelas Siswa Baru</button>
                        </div>
                    </form>
                </div>
            </div>
        </div>

    </div>
</div>
</div>
</div>