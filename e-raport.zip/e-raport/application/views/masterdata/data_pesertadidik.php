<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->

    <div class="col-lg-4">
        <?= $this->session->flashdata('message'); ?>
        <?= form_error('subusername', '<div class="alert alert-danger" role="alert">', '</div>'); ?>
    </div>
    <div class="row">
        <div class="col-lg-12">
            <a href="" class="btn btn-info mb-3" data-toggle="modal" data-target="#newUsersModal"><i class="fa fa-plus-circle"></i> Tambahkan Siswa Baru</a>
            <a href="" class="btn btn-warning mb-3" data-toggle="modal" data-target="#newImportModal"><i class="fa fa-cloud-upload"></i> Import Data</a>

            <div class="card">
                <div class="card-body">


                    <div class="table-responsive m-t-10">
                        <table id="myTable" class="table table-bordered table-striped">
                            <thead>
                                <tr align="center">
                                    <th scope="col" width="20">#</th>
                                    <th scope="col">NISN</th>
                                    <th scope="col">Nama Peserta Didik</th>
                                    <th scope="col">Jenis Kelamin</th>
                                    <th scope="col">Status Peserta Didik</th>
                                    <th width="80px;">Action</th>


                                </tr>
                            </thead>
                            <tbody>
                                <?php $i = 1; ?>
                                <?php foreach ($siswa as $sw) : ?>
                                    <tr>
                                        <td align="center"><?= $i; ?></td>
                                        <td align="center"><?= $sw['nisn']; ?></td>
                                        <td><?= $sw['nama_lengkap']; ?></td>
                                        <td><?= $sw['jenis_kelamin']; ?></td>
                                        <td><?= $sw['status_pd']; ?></td>


                                        <td align="center">
                                            <!--   <a href="" class="badge badge-success">edit</a> -->
                                            <a href="" data-toggle="modal" data-target="#editData<?= $sw['id_pd'] ?>" data-toggle="tooltip" data-original-title="Edit" target="_blank"><i class="ti-pencil-alt m-r-10"></i></a>
                                            <a href="<?php echo base_url('masterdata/delete/' . $sw['nisn']); ?>" data-toggle="tooltip" data-original-title="Hapus" onclick="return confirm('Data ini dihapus?')"><i class="ti-trash m-r-10"></i></a>

                                        </td>

                                    </tr>
                                    <?php $i++; ?>
                                <?php endforeach; ?>

                            </tbody>
                        </table>

                    </div>

                </div>


            </div>


            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->

        <!-- Modal -->
        <div class="modal fade" id="newUsersModal" tabindex="-1" role="dialog" aria-labelledby="newUsersModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="newUserModalsLabel">Tambahkan Siswa Baru</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form class="user" method="post" action="<?= base_url('masterdata/data_pesertadidik') ?>">
                        <div class="modal-body">
                            <div class="form-group">
                                <input type="text" class="form-control" id="nisn" name="nisn" placeholder="NISN">
                            </div>

                            <div class="form-group">
                                <input type="password" class="form-control" id="password" name="password" placeholder="Password">
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" id="nama_lengkap" name="nama_lengkap" placeholder="Nama Lengkap Peserta Didik">

                            </div>
                            <div class="form-group">
                                <select name="jk" id="jk" class="form-control">
                                    <option>Jenis Kelamin</option>
                                    <option value="Laki-laki">Laki-laki</option>
                                    <option value="Perempuan">Perempuan</option>

                                </select>
                            </div>

                            <div class="form-group">
                                <input type="text" class="form-control" id="tempat_lahir" name="tempat_lahir" placeholder="Tempat Lahir">
                            </div>

                            <div class="form-group">
                                <input type="text" class="form-control" id="tgl_lahir" name="tgl_lahir" placeholder="Tanggal Lahir">
                            </div>

                            <div class="form-group">
                                <select name="agama" id="agama" class="form-control">
                                    <option>Agama</option>
                                    <option value="Islam">Islam</option>
                                    <option value="Protestan">Protestan</option>
                                    <option value="Katolik">Katolik</option>
                                    <option value="Hindu">Hindu</option>
                                    <option value="Buddha">Buddha</option>
                                    <option value="Khonghucu">Khonghucu</option>

                                </select>
                            </div>

                            <div class="form-group">
                                <input type="text" class="form-control" id="alamat" name="alamat" placeholder="Alamat">
                            </div>
                            <div class="form-group">
                                <input type="text" class="form-control" id="no_hp" name="no_hp" placeholder="No Handphone">
                            </div>

                            <div class="form-group">
                                <select name="status_pd" id="status_pd" class="form-control">
                                    <option>Status Peserta Didik</option>
                                    <option value="Aktif">Aktif</option>
                                    <option value="Pindah">Pindah</option>
                                    <option value="Alumni">Alumni</option>

                                </select>
                            </div>


                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
                            <button type="submit" class="btn btn-info">Tambah Siswa</button>
                        </div>
                    </form>
                </div>
            </div>

        </div>



        <!-- import user -->
        <div class="modal fade" id="newImportModal" tabindex="-1" role="dialog" aria-labelledby="newImportModal" aria-hidden="true">newImportModal
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="newImportModal">Import Siswa</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form method="post" action="<?php echo base_url('Masterdata/importExcel') ?>" enctype="multipart/form-data">
                            <div class="form-group">

                                <input type="file" name="file">
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
                                <button type="submit" class="btn btn-info">Import</button>
                            </div>
                        </form>
                    </div>

                </div>
            </div>
        </div>









    </div>
</div>
</div>
</div>