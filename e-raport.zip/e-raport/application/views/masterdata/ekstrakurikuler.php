<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->

    <div class="col-lg-4">
        <?= $this->session->flashdata('message'); ?>

    </div>
    <div class="row">
        <div class="col-lg-12">
            <a href="" class="btn btn-info mb-3" data-toggle="modal" data-target="#newUsersModal"><i class="fa fa-plus-circle"></i> Tambahkan Ekstrakurikuler</a>


            <div class="card">
                <div class="card-body">


                    <div class="table-responsive m-t-10">
                        <table id="myTable" class="table table-bordered table-striped">
                            <thead>
                                <tr align="center">
                                    <th scope="col" width="20">#</th>
                                    <th scope="col">Nama Ekstrakurikuler</th>
                                    <th scope="col">Keterangan</th>
                                    <th scope="col" width="80px;">Action</th>



                                </tr>
                            </thead>
                            <tbody>
                                <?php $i = 1; ?>
                                <?php foreach ($ekskul as $k) : ?>
                                    <tr>
                                        <td align="center"><?= $i; ?></td>
                                        <td align="center"><?= $k['nama_ekskul']; ?></td>
                                        <td align="center"><?= $k['keterangan']; ?></td>


                                        <td align="center">
                                            <!--   <a href="" class="badge badge-success">edit</a> -->

                                            <a href="<?php echo base_url('masterdata/delete/' . $k['id_ekskul']); ?>" data-toggle="tooltip" data-original-title="Hapus" onclick="return confirm('Data ini dihapus?')"><i class="ti-trash m-r-10"></i></a>

                                        </td>

                                    </tr>
                                    <?php $i++; ?>
                                <?php endforeach; ?>

                            </tbody>
                        </table>

                    </div>

                </div>


            </div>


            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->

        <!-- Modal -->
        <div class="modal fade" id="newUsersModal" tabindex="-1" role="dialog" aria-labelledby="newUsersModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="newUserModalsLabel">Tambahkan Ekstrakurikuler</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <form class="user" method="post" action="<?= base_url('masterdata/ekstrakurikuler') ?>">
                        <div class="modal-body">
                            <div class="form-group">
                                <input type="text" class="form-control" id="nama_ekskul" name="nama_ekskul" placeholder="Nama Ekstrakurikuler">
                            </div>
                            <div class="form-group">
                                <select name="keterangan" id="keterangan" class="form-control">
                                    <option>keterangan</option>
                                    <option value="Ekskul Wajib">Ekskul Wajib</option>
                                    <option value="Ekskul Pilihan">Ekskul Pilihan</option>

                                </select>
                            </div>


                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-dismiss="modal">Batal</button>
                            <button type="submit" class="btn btn-info">Tambah Ekstrakurikuler</button>
                        </div>
                    </form>
                </div>
            </div>

        </div>











    </div>
</div>
</div>
</div>