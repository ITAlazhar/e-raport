<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->

    <div class="col-lg-4">
        <?= $this->session->flashdata('message'); ?>
        <?= form_error('subusername', '<div class="alert alert-danger" role="alert">', '</div>'); ?>
    </div>

    <!-- .row -->
    <div class="row">
        <!-- .col -->
        <?php foreach ($kelola as $list) : ?>
            <div class="col-md-6 col-lg-6 col-xlg-4">
                <div class="card card-body">
                    <div class="row align-items-center">


                        <div class="col-md-8 col-lg-9">
                            <h3 class="box-title m-b-0"><?php echo $list['nama_kelas']; ?> </small>

                        </div>
                        <div class="col-md-4 col-lg-3 text-center">
                            <a href="<?php echo base_url('masterdata/enroll_siswa/' . $list['nama_kelas']); ?>"><button type="submit" class="btn btn-info"><i class="icon-search"></i> Kelola Kelas</button></i></a>
                        </div>
                    </div>
                </div>
            </div>
            <!-- /.col -->
        <?php endforeach; ?>

    </div>
    <!-- /.row -->
    <!-- ============================================================== -->
    <!-- End PAge Content -->













</div>
</div>
</div>