<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->

    <div class="col-lg-4">
        <?= $this->session->flashdata('message'); ?>

    </div>




    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">


                    <h5 class="card-title">Format Import</h5>
                </div>
                <!-- ============================================================== -->
                <!-- Comment widgets -->
                <!-- ============================================================== -->
                <div class="comment-widgets">
                    <!-- Comment Row -->
                    <div class="d-flex no-block comment-row">
                        <div class="p-2"><span class="round"><img src="../assets/images/users/1.jpg" alt="" width="50"></span></div>
                        <div class="comment-text w-100">
                            <h5 class="font-medium">Format Import Peserta Didik</h5>
                            <p class="m-b-10 text-muted">File format ini digunakan untuk import data peserta didik pada menu Master Data.</p>
                            <div class="comment-footer">
                                <a href="../format/file-import-peserta-didik.xlsx" target="_blank"> <button type="button" class="btn btn-info"><i class="fa fa-download"></i> Download</button> </a>

                            </div>
                        </div>
                    </div>
                    <!-- Comment Row -->
                    <div class="d-flex no-block comment-row">
                        <div class="p-2"><span class="round"><img src="../assets/images/users/1.jpg" alt="" width="50"></span></div>
                        <div class="comment-text w-100">
                            <h5 class="font-medium">Format Import Nilai Pengetahuan dan Keterampilan</h5>
                            <p class="m-b-10 text-muted">File format ini digunakan untuk import data nilai pengetahuan dan nilai keterampilan pada menu Pengelolaan.</p>
                            <div class="comment-footer">
                                <a href="../format/file-import-nilai.xlsx" target="_blank"> <button type="button" class="btn btn-info"><i class="fa fa-download"></i> Download</button> </a>

                            </div>
                        </div>
                    </div>
                    <!-- Comment Row -->
                    <div class="d-flex no-block comment-row">
                        <div class="p-2"><span class="round"><img src="../assets/images/users/1.jpg" alt="" width="50"></span></div>
                        <div class="comment-text w-100">
                            <h5 class="font-medium">Format Import Ekstrakurikuler</h5>
                            <p class="m-b-10 text-muted">File format ini digunakan untuk import data nilai ekstrakurikuler pada menu pengolahan.</p>
                            <div class="comment-footer">
                                <a href="../format/file-import-ekskul.xlsx" target="_blank"> <button type="button" class="btn btn-info"><i class="fa fa-download"></i> Download</button> </a>

                            </div>
                        </div>
                    </div>
                    <!-- Comment Row -->
                    <div class="d-flex no-block comment-row">
                        <div class="p-2"><span class="round"><img src="../assets/images/users/1.jpg" alt="" width="50"></span></div>
                        <div class="comment-text w-100">
                            <h5 class="font-medium">Format Import Rekap Absensi</h5>
                            <p class="m-b-10 text-muted">File format ini digunakan untuk import data rekap absensi pada menu pengolahan.</p>
                            <div class="comment-footer">
                                <a href="../format/file-import-rekapabsensi.xlsx" target="_blank"> <button type="button" class="btn  btn-info"><i class="fa fa-download"></i> Download</button> </a>

                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

    <!-- End of Main Content -->
















</div>
</div>
</div>
</div>