<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->

    <div class="col-lg-4">
        <?= $this->session->flashdata('message'); ?>
        <?= form_error('subusername', '<div class="alert alert-danger" role="alert">', '</div>'); ?>
    </div>
    <!-- ============================================================== -->
    <!-- Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->
    <div class="row">
        <div class="col-lg-12 col-md-12">
            <div class="card">

                <form method="post" action="<?php echo base_url('Pengelolaan/importNP') ?>" enctype="multipart/form-data">

                    <div class="card-body">

                        <label for="input-file-now">Silahkan import nilai dengan menggunakan format yang telah ditentukan </label>
                        <input type="file" id="input-file-now" name="file" class="dropify" />
                    </div>

                    <div class="card-body text-center">
                        <button type="submit" class="btn btn-info">Import Format Nilai</button>
                        <br><br>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <!-- ============================================================== -->
    <!-- End Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- Start Page Content -->
    <!-- ============================================================== -->
</div>
</div>
</div>