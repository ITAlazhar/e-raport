<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->

    <div class="col-lg-4">
        <?= $this->session->flashdata('message'); ?>

    </div>
    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <form method="get" action="<?php echo base_url("pengelolaan/nilai_keterampilan") ?>">
                        <div class="form-group m-t-40 row">
                            <label for="example-text-input" class="col-2 col-form-label">Tahun Pelajaran</label>
                            <div class="col-10">
                                <select name="thn_pelajaran" id="thn_pelajaran" class="form-control">

                                    <?php foreach ($tahun as $baris) : ?>
                                        <option value="<?php echo $baris->thn_pelajaran; ?>"><?php echo $baris->thn_pelajaran; ?></option>
                                    <?php endforeach; ?>


                                </select>
                            </div>
                        </div>

                        <div class="form-group m-t-40 row">
                            <label for="example-text-input" class="col-2 col-form-label">Kode Mata Pelajaran</label>
                            <div class="col-10">
                                <select name="kode_mapel" id="kode_mapel" class="form-control">
                                    <option value="">Pilih Kode Mapel</option>
                                    <?php foreach ($kode as $baris) : ?>
                                        <option value="<?php echo $baris->kode_mapel; ?>"><?php echo $baris->kode_mapel; ?></option>
                                    <?php endforeach; ?>


                                </select>
                            </div>
                        </div>


                        <div class="card-body text-center">
                            <form action="" method="post">
                                <button type="submit" class="btn btn-info"><i class="icon-search"></i> Tampilkan Data</button>
                            </form>
                        </div>




                    </form>
                </div>
            </div>


            <div class="card">
                <div class="card-body">
                    <h4 align="center">
                        <b> Kode Mata Pelajaran <?= $kode_mapel = $this->input->get('kode_mapel'); ?>

                            <br> Tahun Pelajaran <?= $thn_pelajaran = $this->input->get('thn_pelajaran'); ?>
                        </b>
                    </h4>

                    <div class="table-responsive m-t-10">
                        <table id="myTable" class="table table-bordered table-striped">
                            <thead>
                                <tr align="center">
                                    <th scope="col" width="20">#</th>
                                    <th scope="col">Kode Mata Pelajaran</th>
                                    <th scope="col">Tahun Pelajaran</th>
                                    <th scope="col">NISN</th>
                                    <th scope="col">Nama Peserta Didik</th>
                                    <th scope="col">Nilai Keterampilan</th>

                                    <th scope="col">Deskripsi</th>




                                </tr>
                            </thead>
                            <tbody>

                                <?php $i = 1; ?>
                                <?php foreach ($tampildata as $nilai) : ?>
                                    <tr>
                                        <td align="center"><?= $i; ?></td>
                                        <td align="center"><?= $nilai['kode_mapel']; ?></td>
                                        <td align="center"><?= $nilai['thn_pelajaran']; ?></td>
                                        <td align="center"><?= $nilai['nisn']; ?></td>
                                        <td align="center"><?= $nilai['nama_pesertadidik']; ?></td>
                                        <td align="center"><?= $nilai['nilai_keterampilan']; ?></td>
                                        <td align="center"><?= $nilai['deskripsi_keterampilan']; ?></td>




                                    </tr>
                                    <?php $i++; ?>
                                <?php endforeach; ?>


                            </tbody>
                        </table>

                    </div>

                </div>


            </div>


            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->












    </div>
</div>
</div>
</div>