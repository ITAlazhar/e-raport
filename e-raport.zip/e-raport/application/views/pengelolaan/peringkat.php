<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->

    <div class="col-lg-4">
        <?= $this->session->flashdata('message'); ?>

    </div>




    <div class="row">
        <div class="col-lg-12">
            <div class="card">
            </div>


            <div class="card">
                <div class="card-body">
                    <div class="row page-titles">

                        <div class="col-md-12 align-self-center text-right">
                            <div class="d-flex justify-content-end align-items-center">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="javascript:void(0)">Dashboard</a></li>
                                    <li class="breadcrumb-item active">Rapor</li>
                                </ol>

                            </div>
                        </div>
                    </div>
                </div>



                <div class="card-body">


                    <h4 align="center">
                        <b> Daftar Nilai Rapor <?= $user['manage']; ?>

                            <br> Tahun Pelajaran <?= $thn_pelajaran = $this->input->get('thn_pelajaran'); ?>
                        </b>
                    </h4>

                    <div class="table-responsive m-t-10">
                        <table id="myTable" class="table table-bordered table-striped">
                            <thead>
                                <tr align="center">
                                    <th scope="col" width="20">#</th>

                                    <th scope="col">Tahun Pelajaran</th>
                                    <th scope="col">NISN</th>
                                    <th scope="col">Nama Peserta Didik</th>
                                    <th scope="col">Jumlah Mapel</th>
                                    <th scope="col">Total Nilai</th>
                                    <th scope="col">Peringkat</th>



                                </tr>
                            </thead>
                            <tbody>




                                <?php $i = 1; ?>
                                <?php foreach ($tampilnilai as $list) : ?>


                                    <tr>
                                        <td align="center"><?= $i; ?></td>

                                        <td align="center"><?= $thnpelajaran = $list['thn_pelajaran']; ?></td>
                                        <td align="center"><?= $list['nisn']; ?></td>
                                        <td align="center"><?= $list['nama_pesertadidik']; ?></td>
                                        <td align="center"><?= $countmapel = $this->Model_data->countMapel($list['thn_pelajaran'], $list['nisn']); ?> </td>
                                        <td align="center"><?= $list['sum_nilai']; ?></td>
                                        <td></td>

                                    </tr>
                                    <?php $i++; ?>
                                <?php endforeach; ?>


                            </tbody>
                        </table>

                    </div>

                </div>


            </div>


            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->



        <!-- import -->
        <?php foreach ($tampilnilai as $row) : ?>
            <div class="modal fade" id="peringkat<?= $row['nisn'] ?>" tabindex="-1" role="dialog" aria-labelledby="newImportModal" aria-hidden="true">newImportModal
                <div class="modal-dialog" role="document">
                    <div class="modal-content">
                        <div class="modal-header">
                            <h5 class="modal-title" id="newImportModal">Import Nilai Ekstrakurikuler</h5>
                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                <span aria-hidden="true">&times;</span>
                            </button>
                        </div>
                        <div class="modal-body">
                            <div class="form-group">
                                <h4>Total Nilai Akhir : <?= $row['sum_nilai']; ?></h4>

                                <?= $datanilai = "select *,count(thn_pelajaran) as coutmapel, sum(nilai_akhir) as sum_nilai from leger_nilai";

                                ?>
                            </div>
                        </div>
                        <div class="modal-footer">
                            <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
                            <button type="submit" class="btn btn-info">Import</button>
                        </div>
                        </form>
                    </div>

                </div>
            </div>
    </div>
<?php endforeach; ?>
<!--<?= $thnpelajaran = $list['thn_pelajaran']; ?>-->
</div>
</div>
</div>
</div>