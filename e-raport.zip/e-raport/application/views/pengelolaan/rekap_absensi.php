<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->

    <div class="col-lg-4">
        <?= $this->session->flashdata('message'); ?>

    </div>




    <div class="row">
        <div class="col-lg-12">
            <div class="card">
                <div class="card-body">
                    <form method="get" action="<?php echo base_url("pengelolaan/rekap_absensi") ?>">
                        <div class="form-group m-t-40 row">
                            <label for="example-text-input" class="col-2 col-form-label">Tahun Pelajaran</label>
                            <div class="col-10">
                                <select name="thn_pelajaran" id="thn_pelajaran" class="form-control">

                                    <?php foreach ($tahun as $baris) : ?>
                                        <option value="<?php echo $baris->thn_pelajaran; ?>"><?php echo $baris->thn_pelajaran; ?></option>
                                    <?php endforeach; ?>


                                </select>
                            </div>
                        </div>

                        <div class="form-group m-t-40 row">
                            <label for="example-text-input" class="col-2 col-form-label">Nama Kelas</label>
                            <div class="col-10">
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" id="nama_kelas" name="nama_kelas" value="<?= $user['manage']; ?>" readonly>

                                </div>


                                </select>
                            </div>
                        </div>


                        <div class="card-body text-center">
                            <form action="" method="post">
                                <button type="submit" class="btn btn-info"><i class="icon-search"></i> Tampilkan Data</button>
                            </form>
                        </div>




                    </form>
                </div>
            </div>


            <div class="card">
                <div class="card-body">
                    <div class="row page-titles">

                        <div class="col-md-12 align-self-center text-right">
                            <div class="d-flex justify-content-end align-items-center">
                                <ol class="breadcrumb">
                                    <li class="breadcrumb-item"><a href="javascript:void(0)">Dashboard</a></li>
                                    <li class="breadcrumb-item active">Rekap Absensi</li>
                                </ol>
                                <button type="button" class="btn btn-warning d-none d-lg-block m-l-15" data-toggle="modal" data-target="#newImportModal"><i class="fa fa-plus-circle"></i> Import Rekap Absensi</button>
                                <button type="button" class="btn btn-primary d-none d-lg-block m-l-15" data-toggle="modal" data-target="#newInputModal"><i class="fa fa-plus-circle"></i> Input Nilai Absensi</button>
                            </div>
                        </div>
                    </div>
                </div>



                <div class="card-body">


                    <h4 align="center">
                        <b> Rekapitulasi Daftar Kehadiran <?= $user['manage']; ?>

                            <br> Tahun Pelajaran <?= $thn_pelajaran = $this->input->get('thn_pelajaran'); ?>
                        </b>
                    </h4>

                    <div class="table-responsive m-t-10">

                        <table id="myTable" class="table table-bordered table-striped">
                            <thead>
                                <tr align="center">
                                    <th scope="col" width="20">#</th>

                                    <th scope="col">Tahun Pelajaran</th>
                                    <th scope="col">NISN</th>
                                    <th scope="col">Nama Peserta Didik</th>
                                    <th scope="col">Jumlah Alpha</th>
                                    <th scope="col">Jumlah Izin</th>
                                    <th scope="col">Jumlah Sakit</th>
                                </tr>
                            </thead>
                            <tbody>

                                <?php $i = 1; ?>
                                <?php foreach ($tampildata as $nilai) : ?>
                                    <tr>
                                        <td align="center"><?= $i; ?></td>

                                        <td align="center"><?= $nilai['thn_pelajaran']; ?></td>
                                        <td align="center"><?= $nilai['nisn']; ?></td>
                                        <td align="center"><?= $nilai['nama_pesertadidik']; ?></td>
                                        <td align="center"><?= $nilai['jumlah_alpa']; ?></td>
                                        <td align="center"><?= $nilai['jumlah_izin']; ?></td>
                                        <td align="center"><?= $nilai['jumlah_sakit']; ?></td>



                                    </tr>
                                    <?php $i++; ?>
                                <?php endforeach; ?>


                            </tbody>
                        </table>

                    </div>

                </div>


            </div>


            <!-- /.container-fluid -->

        </div>
        <!-- End of Main Content -->



        <!-- import user -->
        <div class="modal fade" id="newImportModal" tabindex="-1" role="dialog" aria-labelledby="newImportModal" aria-hidden="true">newImportModal
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="newImportModal">Import Rekap Absensi</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form method="post" action="<?php echo base_url('pengelolaan/importabsensi') ?>" enctype="multipart/form-data">
                            <div class="form-group">

                                <input type="file" name="file">
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
                                <button type="submit" class="btn btn-info">Import</button>
                            </div>
                        </form>
                    </div>

                </div>
            </div>
        </div>


        <!-- Input Absen -->
        <div class="modal fade" id="newInputModal" tabindex="-1" role="dialog" aria-labelledby="newInputModal" aria-hidden="true">newImportModal
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="newImportModal">Input Rekap Absensi</h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form method="post" action="<?php echo base_url('pengelolaan/inputabsensi') ?>" enctype="multipart/form-data">
                            <div class="form-group">

                            <div class="form-group">
                                <span>Nama Siswa</span>
                                <select class="form-control" name="siswa_id">
                                    <option selected="" disabled="">-- Select Siswa --</option>
                                    <?php foreach ($datasiswa as $s):?>
                                    <option value="<?= $s['siswa_id']; ?>"><?= $s['siswa_id']; ?></option>
                                    <?php endforeach;?> 
                                </select>
                            </div>
                            <div class="form-group">
                                <span>Kelas</span>
                                <select class="form-control" name="kelas_id">
                                    <option selected="" disabled="">-- Select Kelas --</option>
                                    <?php foreach ($data_kelas as $kelas):?>
                                    <option value="<?= $kelas['nama_kelas']; ?>"><?= $kelas['nama_kelas']; ?></option>
                                    <?php endforeach;?> 
                                </select>
                            </div>
                            <div class="form-group">
                                <span>Semester</span>
                                <select class="form-control" name="semester_id">
                                    <option selected="" disabled="">-- Select Semester</option>
                                    <?php foreach ($data_semester as $semester):?>
                                    <option value="<?= $semester['thn_pelajaran']; ?>"><?= $semester['thn_pelajaran']; ?></option>
                                    <?php endforeach;?> 
                                </select>
                            </div>

                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-danger" data-dismiss="modal">Cancel</button>
                                <button type="submit" class="btn btn-info">Import</button>
                            </div>
                        </form>
                    </div>

                </div>
            </div>
        </div>










    </div>
</div>
</div>
</div>