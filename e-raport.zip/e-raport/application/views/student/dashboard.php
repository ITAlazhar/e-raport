<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->



    <!-- Dashboard -->
    <!-- Row -->
    <div class="row">
        <!-- Column -->
        <div class="col-lg-4 col-xlg-3 col-md-5">
            <div class="card">
                <div class="card-body text-center">
                    <div> <img src="<?= base_url('assets/img/student.jpg') ?>" width="200">

                        <br>
                        <h3 class="card-title mt-5" style="text-transform: uppercase;"><?= $user['nama_lengkap']; ?></h3>

                        <p class="text-black"> <?= $sekolah['nama_sekolah']; ?></p>
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-body">
                    DATA SEKOLAH
                    <hr>
                    <small class="text-muted">Email address </small>
                    <h6><?= $sekolah['email_sekolah']; ?></h6> <small class="text-muted p-t-30 db">Phone</small>
                    <h6><?= $sekolah['telepon']; ?></h6> <small class="text-muted p-t-30 db">Address</small>
                    <h6><?= $sekolah['alamat_sekolah']; ?>, <?= $sekolah['kecamatan']; ?>, <?= $sekolah['kabupaten']; ?>, <?= $sekolah['provinsi']; ?> <?= $sekolah['kode_pos']; ?></h6>
                    <div class="map-box">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3984.1760936500527!2d104.78893971475708!3d-3.0474565977807266!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e3b9c5c7a94d91d%3A0x1f25314e1cb6fab4!2sSMA%20Negeri%2019%20Palembang!5e0!3m2!1sid!2sid!4v1626850765697!5m2!1sid!2sid" width="380" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                    </div> <small class="text-muted p-t-30 db">Social Profile</small>
                    <br />
                    <button class="btn btn-circle btn-secondary"><i class="fa fa-facebook"></i></button>
                    <button class="btn btn-circle btn-secondary"><i class="fa fa-twitter"></i></button>
                    <button class="btn btn-circle btn-secondary"><i class="fa fa-youtube"></i></button>
                </div>
            </div>
        </div>
        <!-- Column -->
        <!-- Column -->
        <div class="col-lg-8 col-xlg-9 col-md-7">
            <div class="card">


                <div class="card border-info">
                    <div class="card-header bg-info">
                        <h4 class="m-b-0 text-white"> DATA PESERTA DIDIK</h4>
                    </div>
                    <div class="card-body">
                        <table width="100%" border="0" cellpadding="7">
                            <tr>
                                <td width="200">Nama Peserta didik</td>
                                <td width="1">:</td>
                                <td style="text-transform: uppercase;"><?php echo $user['nama_lengkap']; ?></td>
                            </tr>

                            <tr>
                                <td width="200">NISN</td>
                                <td width="1">:</td>
                                <td><?php echo $user['nisn']; ?></td>
                            </tr>

                            <tr>
                                <td width="200">Jenis Kelamin </td>
                                <td width="1">:</td>
                                <td><?php echo $user['jenis_kelamin']; ?></td>
                            </tr>

                            <tr>
                                <td width="200">Tempat dan tanggal lahir </td>
                                <td width="1">:</td>
                                <td><?php echo $user['tempat_lahir']; ?>, <?php echo $user['tanggal_lahir']; ?></td>
                            </tr>

                            <tr>
                                <td width="200">Agama </td>
                                <td width="1">:</td>
                                <td><?php echo $user['agama']; ?></td>
                            </tr>

                            <tr>
                                <td width="200">Alamat </td>
                                <td width="1">:</td>
                                <td><?php echo $user['alamat']; ?></td>
                            </tr>

                            <tr>
                                <td width="200">No. Handphone </td>
                                <td width="1">:</td>
                                <td><?php echo $user['no_hp']; ?></td>
                            </tr>

                            <tr>
                                <td width="200">Status Peserta Didik </td>
                                <td width="1">:</td>
                                <td><?php echo $user['status_pd']; ?></td>
                            </tr>

                        </table>


                    </div>
                </div>



            </div>







        </div>
        <!-- Column -->
    </div>
    <!-- Row -->
    <!-- ============================================================== -->
    <!-- End PAge Content -->

    <!-- /.container-fluid -->



</div>


<!-- End of Main Content -->