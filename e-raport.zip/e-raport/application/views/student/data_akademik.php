<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->

    <div class="col-lg-4">
        <?= $this->session->flashdata('message'); ?>

    </div>
    <!-- ============================================================== -->
    <!-- Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->
    <div class="row">
        <div class="col-lg-12 col-md-12">
            <div class="card">
                <div class="card-body">
                    <table width="100%" border="0" cellpadding="7">
                        <tr>
                            <td style="width: 22.0079%; height: 18px;">Nama Sekolah</td>
                            <td style="width: 1.23642%; height: 18px;">:</td>
                            <td style="44.2631%; height: 18px; text-transform: uppercase;"><b><?php echo $sekolah['nama_sekolah']; ?></b></td>
                            <td width="width: 10.9546%; height: 18px;">Kelas</td>
                            <td width="width: 2.20085%; height: 18px;">:</td>
                            <td style="width: 19.3372%; height: 18px; text-transform: uppercase;"><?php echo $tampildata['nama_kelas']; ?></td>
                        </tr>
                        <tr>
                            <td style="width: 22.0079%; height: 18px;">Alamat Sekolah</td>
                            <td style="width: 1.23642%; height: 18px;">:</td>
                            <td style="44.2631%; height: 18px;"><b><?php echo $sekolah['alamat_sekolah']; ?></b></td>
                            <td width="width: 10.9546%; height: 18px;">Tahun Pelajaran</td>
                            <td width="width: 2.20085%; height: 18px;">:</td>
                            <td style="width: 19.3372%; height: 18px;"><?php echo $tampildata['thn_pelajaran']; ?></td>
                        </tr>
                        <tr>
                            <td width="200">Nama Peserta didik</td>
                            <td width="1">:</td>
                            <td style="text-transform: uppercase;"><b><?php echo $tampildata['nama_pesertadidik']; ?></b></td>

                        </tr>

                        <tr>
                            <td width="200">NISN</td>
                            <td width="1">:</td>
                            <td><?php echo $tampildata['nisn']; ?></td>

                        </tr>







                    </table>



                </div>


                <div class="card-body">
                    <div class="table-responsive m-t-10">
                        <table class="table table-bordered table-striped" cellpadding="7">
                            <thead>
                                <tr align="center">
                                    <th scope="col" width="20">#</th>
                                    <th scope="col">Mata Pelajaran</th>
                                    <th scope="col">Nilai Pengetahuan</th>
                                    <th scope="col">Predikat</th>
                                    <th scope="col">Deskripsi</th>
                                    <th scope="col">Nilai Keterampilan</th>
                                    <th scope="col">Predikat</th>
                                    <th scope="col">Deskripsi</th>



                                </tr>
                            </thead>
                            <tbody>
                                <?php $i = 1; ?>
                                <?php foreach ($tampilnilai as $nilai) : ?>
                                    <tr>
                                        <td align="center"><?= $i; ?></td>
                                        <td align="center"><?= $nilai['nama_mapel']; ?></td>
                                        <td align="center"><?= $nilai['nilai_akhir']; ?></td>
                                        <td align="center"><?php

                                                            if (($nilai['nilai_akhir'] >= 93) && ($nilai['nilai_akhir'] <= 100)) {
                                                                echo "A";
                                                            } else if (($nilai['nilai_akhir'] >= 87) && ($nilai['nilai_akhir'] <= 92)) {
                                                                echo "B";
                                                            } else if (($nilai['nilai_akhir'] >= 80) && ($nilai['nilai_akhir'] <= 86)) {
                                                                echo "C";
                                                            } else if (($nilai['nilai_akhir'] >= 72) && ($nilai['nilai_akhir'] <= 79)) {
                                                                echo "D";
                                                            }


                                                            ?></td>




                                        <td align="center"><?= $nilai['deskripsi_np']; ?></td>
                                        <td align="center"><?= $nilai['nilai_keterampilan']; ?></td>
                                        <td align="center"><?php

                                                            if (($nilai['nilai_keterampilan'] >= 93) && ($nilai['nilai_keterampilan'] <= 100)) {
                                                                echo "A";
                                                            } else if (($nilai['nilai_keterampilan'] >= 87) && ($nilai['nilai_keterampilan'] <= 92)) {
                                                                echo "B";
                                                            } else if (($nilai['nilai_keterampilan'] >= 80) && ($nilai['nilai_keterampilan'] <= 86)) {
                                                                echo "C";
                                                            } else if (($nilai['nilai_keterampilan'] >= 72) && ($nilai['nilai_keterampilan'] <= 79)) {
                                                                echo "D";
                                                            }


                                                            ?></td>


                                        <td align="center"><?= $nilai['deskripsi_keterampilan']; ?></td>




                                    </tr>
                                    <?php $i++; ?>
                                <?php endforeach; ?>

                                <tr>

                                    <td colspan="4">Jumlah Nilai Keseluruhan</td>
                                    <td colspan="4"><?= $sum['nilai_akhir']; ?></td>

                                </tr>
                                <tr>

                                    <td colspan="4">Rata-rata Nilai</td>
                                    <td colspan="4"><?= number_format($average['nilai_akhir'], 2); ?></td>

                                </tr>
                                <tr>

                                    <td colspan="4">Peringkat</td>
                                    <td colspan="4"></td>

                                </tr>


                            </tbody>
                        </table>

                    </div>
                </div>



                <div class="card-body">
                    <div class="table-responsive m-t-10">
                        <table class="table table-bordered table-striped" cellpadding="7">
                            <thead>
                                <h4><b> Kegiatan Ekstrakurikuler</b></h4>
                                <tr align="center">
                                    <th scope="col" width="20">#</th>
                                    <th scope="col">Nama Kegiatan Ekstrakurikuler</th>
                                    <th scope="col">Nilai</th>




                                </tr>
                            </thead>
                            <tbody>
                                <?php $i = 1; ?>
                                <?php foreach ($ekskul as $nilai) : ?>
                                    <tr>
                                        <td align="center"><?= $i; ?></td>
                                        <td align="center"><?= $nilai['nama_ekskul']; ?></td>
                                        <td align="center"><?= $nilai['nilai_ekskul']; ?></td>




                                    </tr>
                                    <?php $i++; ?>
                                <?php endforeach; ?>



                            </tbody>
                        </table>

                    </div>
                </div>

                <div class="card-body">
                    <div class="table-responsive m-t-10">
                        <table class="table table-bordered table-striped" cellpadding="7">
                            <thead>
                                <h4><b> Rekapitulasi Ketidakhadiran</b></h4>
                                <tr align="center">
                                    <th scope="col" width="20">#</th>
                                    <th scope="col">Jumlah Alpa</th>
                                    <th scope="col">Jumlah Izin</th>
                                    <th scope="col">Jumlah Sakit</th>




                                </tr>
                            </thead>
                            <tbody>
                                <?php $i = 1; ?>
                                <?php foreach ($absen as $nilai) : ?>
                                    <tr>
                                        <td align="center"><?= $i; ?></td>
                                        <td align="center"><?= $nilai['jumlah_alpa']; ?></td>
                                        <td align="center"><?= $nilai['jumlah_izin']; ?></td>
                                        <td align="center"><?= $nilai['jumlah_sakit']; ?></td>




                                    </tr>
                                    <?php $i++; ?>
                                <?php endforeach; ?>



                            </tbody>
                        </table>

                    </div>
                </div>



                <div class="card-body">

                </div>


            </div>
        </div>
    </div>

    <!-- ============================================================== -->
    <!-- End Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- Start Page Content -->
    <!-- ============================================================== -->
</div>
</div>
</div>