<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->

    <div class="col-lg-4">
        <?= $this->session->flashdata('message'); ?>

    </div>
    <!-- ============================================================== -->
    <!-- Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->
    <div class="row">
        <div class="col-lg-12 col-md-12">
            <div class="card">


                <div class="card-body">

                    <label>Silahkan pilih tahun pelajaran terlebih dahulu</label>
                    <form method="get" action="<?php echo base_url("student/data_akademik") ?>">
                        <div class="form-group m-t-40 row">
                            <label for="example-text-input" class="col-2 col-form-label">Tahun Pelajaran</label>
                            <div class="col-10">
                                <select name="thn_pelajaran" id="thn_pelajaran" class="form-control">

                                    <?php foreach ($tahun as $baris) : ?>
                                        <option value="<?php echo $baris->thn_pelajaran; ?>"><?php echo $baris->thn_pelajaran; ?></option>
                                    <?php endforeach; ?>


                                </select>
                            </div>
                        </div>

                        <div class="form-group m-t-40 row">

                            <div class="col-10">
                                <div class="col-sm-10">
                                    <input type="hidden" class="form-control" id="studentID" name="studentID" value="<?= $user['nisn']; ?>">

                                </div>


                            </div>
                        </div>




                        <div class="card-body text-center">
                            <form action="" method="post">
                                <button type="submit" class="btn btn-info"><i class="icon-search"></i> Tampilkan Data</button>
                            </form>
                        </div>




                    </form>

                </div>


            </div>
        </div>
    </div>

    <!-- ============================================================== -->
    <!-- End Bread crumb and right sidebar toggle -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- Start Page Content -->
    <!-- ============================================================== -->
</div>
</div>
</div>