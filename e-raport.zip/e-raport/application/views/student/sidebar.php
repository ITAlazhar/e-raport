<aside class="left-sidebar">
    <!-- Sidebar scroll-->
    <div class="scroll-sidebar">
        <!-- Sidebar navigation-->
        <nav class="sidebar-nav">
            <ul id="sidebarnav">
                <li class="user-pro"> <a class="has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false"><img src=" <?= base_url('assets/'); ?>img/user.png" alt="user-img" class="img-circle"><span class="hide-menu"><?= $user['name']; ?> </span></a>
                    <ul aria-expanded="false" class="collapse">
                        <li><a href="javascript:void(0)"><i class="ti-user"></i> My Profile</a></li>
                        <li><a href="javascript:void(0)"><i class="ti-settings"></i> Account Setting</a></li>
                        <li> <a href="#" data-toggle="modal" data-target="#logoutModal" class="dropdown-item"><i class="fa fa-power-off"></i> Logout</a></li>
                    </ul>
                </li>

                <li> <a href="<?= base_url('student/dashboard') ?>"> <i class="icon-speedometer"></i><span class="hide-menu">Dashboard </span></a>

                </li>
                <li> <a href="<?= base_url('student/hasil_belajar') ?>"> <i class="ti-blackboard "></i><span class="hide-menu">Lihat Hasil Belajar</span></a>

                </li>




            </ul>
        </nav>
        <!-- End Sidebar navigation -->
    </div>
    <!-- End Sidebar scroll-->
</aside>
<!-- ============================================================== -->
<!-- End Left Sidebar - style you can find in sidebar.scss  -->
<!-- ============================================================== -->
<!-- ============================================================== -->
<!-- Page wrapper  -->
<!-- ============================================================== -->
<div class="page-wrapper">
    <!-- ============================================================== -->
    <!-- Container fluid  -->
    <!-- ============================================================== -->
    <div class="container-fluid">
        <!-- ============================================================== -->
        <!-- Bread crumb and right sidebar toggle -->
        <!-- ============================================================== -->
        <div class="row page-titles">
            <div class="col-md-5 align-self-center">
                <h3 class="text-themecolor"><b><?= $title; ?></b> </h3>
            </div>

        </div>
        <!-- ============================================================== -->
        <!-- End Bread crumb and right sidebar toggle -->