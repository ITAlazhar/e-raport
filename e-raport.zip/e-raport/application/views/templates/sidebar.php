<?php if ($user['role_id'] == 1) { ?>
    <!-- Left Sidebar - style you can find in sidebar.scss  -->
    <!-- ============================================================== -->
    <aside class="left-sidebar">
        <!-- Sidebar scroll-->
        <div class="scroll-sidebar">
            <!-- Sidebar navigation-->
            <nav class="sidebar-nav">
                <ul id="sidebarnav">
                    <li class="user-pro"> <a class="has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false"><img src=" <?= base_url('assets/'); ?>img/user.png" alt="user-img" class="img-circle"><span class="hide-menu"><?= $user['name']; ?> </span></a>
                        <ul aria-expanded="false" class="collapse">
                            <li><a href="javascript:void(0)"><i class="ti-user"></i> My Profile</a></li>
                            <li><a href="javascript:void(0)"><i class="ti-settings"></i> Account Setting</a></li>
                            <li> <a href="#" data-toggle="modal" data-target="#logoutModal" class="dropdown-item"><i class="fa fa-power-off"></i> Logout</a></li>
                        </ul>
                    </li>

                    <li> <a href="<?= base_url('admin') ?>"> <i class="icon-speedometer"></i><span class="hide-menu">Dashboard </span></a>

                    </li>
                    <li> <a class="has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false"><i class="ti-settings"></i><span class="hide-menu">Konfigurasi</span></a>
                        <ul aria-expanded="false" class="collapse">
                            <li><a href="<?= base_url('admin/data_sekolah') ?>"><i class="ti-home"></i> Data Sekolah</a></li>
                            <li><a href="<?= base_url('admin/data_user') ?>"><i class="ti-user"></i> Data Wali Kelas</a></li>
                            <li><a href="<?= base_url('admin/tahun_pelajaran') ?>"><i class="ti-blackboard"></i> Tahun Pelajaran</a></li>


                        </ul>
                    </li>


                    <li> <a class="has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false"><i class="ti-layout-grid2"></i><span class="hide-menu">Master Data</span></a>
                        <ul aria-expanded="false" class="collapse">
                            <li><a href="<?= base_url('masterdata/data_pesertadidik') ?>"><i class="ti-user"></i> Data Peserta Didik</a></li>
                            <li><a href="<?= base_url('masterdata/data_kelas') ?>"><i class="ti-blackboard "></i> Data Kelas</a></li>
<!--                             <li><a href="<?= base_url('masterdata/kelas') ?>"><i class="ti-blackboard "></i> Data Kelas Siswa</a></li> -->
                            <li><a href="<?= base_url('masterdata/data_mapel') ?>"><i class="ti-agenda"></i> Data Mata Pelajaran</a></li>
                            <li><a href="<?= base_url('masterdata/kode_mapel') ?>"><i class="ti-bookmark-alt"></i> Kode Mata Pelajaran</a></li>

                            <li><a href="<?= base_url('masterdata/ekstrakurikuler') ?>"><i class="ti-rocket"></i> Data Ekstrakurikuler</a></li>


                        </ul>
                    </li>
                    <li> <a class="has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false"><i class="ti-layout-accordion-merged"></i><span class="hide-menu">Pengelolaan</span></a>
                        <ul aria-expanded="false" class="collapse">

                            <li> <a class="has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false"><i class="ti-pencil-alt"></i><span class="hide-menu"> Kelola Nilai</span></a>
                                <ul aria-expanded="false" class="collapse">
                                    <li><a href="<?= base_url('pengelolaan') ?>"><i class="ti-cloud-up"></i> Import Nilai</a></li>
                                    <li><a href="<?= base_url('pengelolaan/nilai_pengetahuan') ?>"><i class="ti-pencil-alt"></i> Nilai Pengetahuan</a></li>
                                    <li><a href="<?= base_url('pengelolaan/nilai_keterampilan') ?>"><i class="ti-crown"></i> Nilai Keterampilan</a></li>

                                </ul>
                            </li>

                            <li><a href="<?= base_url('admin/nilai_ekstrakurikuler') ?>"><i class="ti-rocket"></i> Nilai Ekstrakurikuler</a></li>
                            <li><a href="<?= base_url('admin/rekap_absensi') ?>"><i class="ti-check-box"></i> Rekap Absensi</a></li>
                            <li><a href="<?= base_url('admin/nilai_absensi') ?>"><i class="ti-check-box"></i> Nilai Absensi</a></li>
                            <li><a href="<?= base_url('admin/erapor') ?>"><i class="ti-printer"></i> Hasil Pengolahan</a></li>
                            <li><a href="<?= base_url('pengelolaan/format_import') ?>"><i class="ti-download"></i> Format Import</a></li>


                        </ul>
                    </li>


                </ul>
            </nav>
            <!-- End Sidebar navigation -->
        </div>
        <!-- End Sidebar scroll-->
    </aside>
    <!-- ============================================================== -->
    <!-- End Left Sidebar - style you can find in sidebar.scss  -->
    <!-- ============================================================== -->
    <!-- ============================================================== -->
    <!-- Page wrapper  -->
    <!-- ============================================================== -->
    <div class="page-wrapper">
        <!-- ============================================================== -->
        <!-- Container fluid  -->
        <!-- ============================================================== -->
        <div class="container-fluid">
            <!-- ============================================================== -->
            <!-- Bread crumb and right sidebar toggle -->
            <!-- ============================================================== -->
            <div class="row page-titles">
                <div class="col-md-5 align-self-center">
                    <h3 class="text-themecolor"><b><?= $title; ?></b> </h3>
                </div>

            </div>
            <!-- ============================================================== -->
            <!-- End Bread crumb and right sidebar toggle -->


        <?php } else { ?>

            <?php if ($user['role_id'] == 3) { ?>
                <!-- Left Sidebar - style you can find in sidebar.scss  -->
                <!-- ============================================================== -->
                <aside class="left-sidebar">
                    <!-- Sidebar scroll-->
                    <div class="scroll-sidebar">
                        <!-- Sidebar navigation-->
                        <nav class="sidebar-nav">
                            <ul id="sidebarnav">
                                <li class="user-pro"> <a class="has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false"><img src=" <?= base_url('assets/'); ?>img/user.png" alt="user-img" class="img-circle"><span class="hide-menu"><?= $user['name']; ?> </span></a>
                                    <ul aria-expanded="false" class="collapse">
                                        <li><a href="javascript:void(0)"><i class="ti-user"></i> My Profile</a></li>
                                        <li><a href="javascript:void(0)"><i class="ti-settings"></i> Account Setting</a></li>
                                        <li> <a href="#" data-toggle="modal" data-target="#logoutModal" class="dropdown-item"><i class="fa fa-power-off"></i> Logout</a></li>
                                    </ul>
                                </li>

                                <li> <a href="<?= base_url('admin') ?>"> <i class="icon-speedometer"></i><span class="hide-menu">Dashboard </span></a>

                                </li>
                                <li> <a class="has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false"><i class="ti-settings"></i><span class="hide-menu">Konfigurasi</span></a>
                                    <ul aria-expanded="false" class="collapse">
                                        <li><a href="<?= base_url('admin/data_sekolah') ?>"><i class="ti-home"></i> Data Sekolah</a></li>
                                        <li><a href="<?= base_url('admin/data_user') ?>"><i class="ti-user"></i> Data Wali Kelas</a></li>



                                    </ul>
                                </li>



                                <li> <a class="has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false"><i class="ti-layout-accordion-merged"></i><span class="hide-menu">Pengelolaan</span></a>
                                    <ul aria-expanded="false" class="collapse">

                                        <li> <a class="has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false"><i class="ti-pencil-alt"></i><span class="hide-menu"> Lihat Nilai</span></a>
                                            <ul aria-expanded="false" class="collapse">

                                                <li><a href="<?= base_url('pengelolaan/nilai_pengetahuan') ?>"><i class="ti-pencil-alt"></i> Nilai Pengetahuan</a></li>
                                                <li><a href="<?= base_url('pengelolaan/nilai_keterampilan') ?>"><i class="ti-crown"></i> Nilai Keterampilan</a></li>

                                            </ul>
                                        </li>

                                        <li><a href="<?= base_url('admin/nilai_ekstrakurikuler') ?>"><i class="ti-rocket"></i> Nilai Ekstrakurikuler</a></li>
                                        <li><a href="<?= base_url('admin/rekap_absensi') ?>"><i class="ti-check-box"></i> Rekap Absensi</a></li>
                                        <li><a href="<?= base_url('admin/erapor') ?>"><i class="ti-printer"></i> Hasil Pengolahan</a></li>
                                        <li><a href="<?= base_url('pengelolaan/format_import') ?>"><i class="ti-download"></i> Format Import</a></li>


                                    </ul>
                                </li>


                            </ul>
                        </nav>
                        <!-- End Sidebar navigation -->
                    </div>
                    <!-- End Sidebar scroll-->
                </aside>
                <!-- ============================================================== -->
                <!-- End Left Sidebar - style you can find in sidebar.scss  -->
                <!-- ============================================================== -->
                <!-- ============================================================== -->
                <!-- Page wrapper  -->
                <!-- ============================================================== -->
                <div class="page-wrapper">
                    <!-- ============================================================== -->
                    <!-- Container fluid  -->
                    <!-- ============================================================== -->
                    <div class="container-fluid">
                        <!-- ============================================================== -->
                        <!-- Bread crumb and right sidebar toggle -->
                        <!-- ============================================================== -->
                        <div class="row page-titles">
                            <div class="col-md-5 align-self-center">
                                <h3 class="text-themecolor"><b><?= $title; ?></b> </h3>
                            </div>

                        </div>
                        <!-- ============================================================== -->
                        <!-- End Bread crumb and right sidebar toggle -->





                    <?php } else { ?>


                        <!-- Left Sidebar - Wali kelas  -->
                        <!-- ============================================================== -->
                        <aside class="left-sidebar">
                            <!-- Sidebar scroll-->
                            <div class="scroll-sidebar">
                                <!-- Sidebar navigation-->
                                <nav class="sidebar-nav">
                                    <ul id="sidebarnav">
                                        <li class="user-pro"> <a class="has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false"><img src=" <?= base_url('assets/'); ?>img/user.png" alt="user-img" class="img-circle"><span class="hide-menu"><?= $user['name']; ?> </span></a>
                                            <ul aria-expanded="false" class="collapse">
                                                <li><a href="javascript:void(0)"><i class="ti-user"></i> My Profile</a></li>
                                                <li><a href="javascript:void(0)"><i class="ti-settings"></i> Account Setting</a></li>
                                                <li> <a href="#" data-toggle="modal" data-target="#logoutModal" class="dropdown-item"><i class="fa fa-power-off"></i> Logout</a></li>
                                            </ul>
                                        </li>

                                        <li> <a href="<?= base_url('user') ?>"> <i class="icon-speedometer"></i><span class="hide-menu">Dashboard </span></a>

                                        </li>



                                        <li> <a class="has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false"><i class="ti-layout-grid2"></i><span class="hide-menu">Master Data</span></a>
                                            <ul aria-expanded="false" class="collapse">
                                                <li><a href="<?= base_url('masterdata/data_pesertadidik') ?>"><i class="ti-user"></i> Data Peserta Didik</a></li>
                                                <li><a href="<?= base_url('masterdata/data_kelas') ?>"><i class="ti-blackboard "></i> Data Kelas</a></li>
                                                <li><a href="<?= base_url('masterdata/data_mapel') ?>"><i class="ti-agenda"></i> Data Mata Pelajaran</a></li>
                                                <li><a href="<?= base_url('masterdata/kode_mapel') ?>"><i class="ti-bookmark-alt"></i> Kode Mata Pelajaran</a></li>
                                                <li><a href="<?= base_url('masterdata/ekstrakurikuler') ?>"><i class="ti-rocket"></i> Data Ekstrakurikuler</a></li>


                                            </ul>
                                        </li>
                                        <li> <a class="has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false"><i class="ti-layout-accordion-merged"></i><span class="hide-menu">Pengelolaan</span></a>
                                            <ul aria-expanded="false" class="collapse">

                                                <li> <a class="has-arrow waves-effect waves-dark" href="javascript:void(0)" aria-expanded="false"><i class="ti-pencil-alt"></i><span class="hide-menu"> Kelola Nilai</span></a>
                                                    <ul aria-expanded="false" class="collapse">
                                                        <li><a href="<?= base_url('pengelolaan') ?>"><i class="ti-cloud-up"></i> Import Nilai</a></li>
                                                        <li><a href="<?= base_url('pengelolaan/nilai_pengetahuan') ?>"><i class="ti-pencil-alt"></i> Nilai Pengetahuan</a></li>
                                                        <li><a href="<?= base_url('pengelolaan/nilai_keterampilan') ?>"><i class="ti-crown"></i> Nilai Keterampilan</a></li>

                                                    </ul>
                                                </li>

                                                <li><a href="<?= base_url('pengelolaan/nilai_ekstrakurikuler') ?>"><i class="ti-rocket"></i> Nilai Ekstrakurikuler</a></li>
                                                <li><a href="<?= base_url('pengelolaan/rekap_absensi') ?>"><i class="ti-check-box"></i> Rekap Absensi</a></li>
                                                <li><a href="<?= base_url('pengelolaan/nilai_absensi') ?>"><i class="ti-check-box"></i> Nilai Absensi</a></li>
                                                <li><a href="<?= base_url('pengelolaan/erapor') ?>"><i class="ti-printer"></i> Hasil Pengolahan</a></li>
                                                <li><a href="<?= base_url('pengelolaan/format_import') ?>"><i class="ti-download"></i> Format Import</a></li>


                                            </ul>
                                        </li>


                                    </ul>
                                </nav>
                                <!-- End Sidebar navigation -->
                            </div>
                            <!-- End Sidebar scroll-->
                        </aside>
                        <!-- ============================================================== -->
                        <!-- End Left Sidebar - style you can find in sidebar.scss  -->
                        <!-- ============================================================== -->
                        <!-- ============================================================== -->
                        <!-- Page wrapper  -->
                        <!-- ============================================================== -->
                        <div class="page-wrapper">
                            <!-- ============================================================== -->
                            <!-- Container fluid  -->
                            <!-- ============================================================== -->
                            <div class="container-fluid">
                                <!-- ============================================================== -->
                                <!-- Bread crumb and right sidebar toggle -->
                                <!-- ============================================================== -->
                                <div class="row page-titles">
                                    <div class="col-md-5 align-self-center">
                                        <h3 class="text-themecolor"><b><?= $title; ?></b> </h3>
                                    </div>

                                </div>
                                <!-- ============================================================== -->
                                <!-- End Bread crumb and right sidebar toggle -->




                            <?php } ?>
                        <?php } ?>