<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->



    <!-- Dashboard -->
    <!-- Row -->
    <div class="row">
        <!-- Column -->
        <div class="col-lg-4 col-xlg-3 col-md-5">
            <div class="card"> <img class="card-img" src="<?= base_url('assets/'); ?>img/sekolah.jpeg" height="456" alt="Card image">
                <div class="card-img-overlay card-inverse text-white social-profile d-flex justify-content-center">
                    <div class="align-self-center"> <img src="<?= base_url('assets/img/profile/') . $sekolah['logo'] ?>" width="200">

                        <br>
                        <h4 class="card-title mt-5"><?= $sekolah['nama_sekolah']; ?></h4>

                        <p class="text-white"> <?= $sekolah['alamat_sekolah']; ?></p>
                    </div>
                </div>
            </div>
            <div class="card">
                <div class="card-body"> <small class="text-muted">Email address </small>
                    <h6><?= $sekolah['email_sekolah']; ?></h6> <small class="text-muted p-t-30 db">Phone</small>
                    <h6><?= $sekolah['telepon']; ?></h6> <small class="text-muted p-t-30 db">Address</small>
                    <h6><?= $sekolah['alamat_sekolah']; ?>, <?= $sekolah['kecamatan']; ?>, <?= $sekolah['kabupaten']; ?>, <?= $sekolah['provinsi']; ?> <?= $sekolah['kode_pos']; ?></h6>
                    <div class="map-box">
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3984.1760936500527!2d104.78893971475708!3d-3.0474565977807266!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e3b9c5c7a94d91d%3A0x1f25314e1cb6fab4!2sSMA%20Negeri%2019%20Palembang!5e0!3m2!1sid!2sid!4v1626850765697!5m2!1sid!2sid" width="420" height="250" style="border:0;" allowfullscreen="" loading="lazy"></iframe>
                    </div> <small class="text-muted p-t-30 db">Social Profile</small>
                    <br />
                    <button class="btn btn-circle btn-secondary"><i class="fa fa-facebook"></i></button>
                    <button class="btn btn-circle btn-secondary"><i class="fa fa-twitter"></i></button>
                    <button class="btn btn-circle btn-secondary"><i class="fa fa-youtube"></i></button>
                </div>
            </div>
        </div>
        <!-- Column -->
        <!-- Column -->
        <div class="col-lg-8 col-xlg-9 col-md-7">
            <div class="card">


                <div class="card border-info">
                    <div class="card-header bg-info">
                        <h4 class="m-b-0 text-white"> <?= $sekolah['nama_sekolah']; ?></h4>
                    </div>
                    <div class="card-body">
                        <h3 class="card-title"><?= $user['name']; ?>, saat ini anda login sebagai <?php

                                                                                                    if ($user['role_id'] == 2) {

                                                                                                        echo "Wali Kelas";
                                                                                                    } else {

                                                                                                        echo "Admin";
                                                                                                    }


                                                                                                    ?> <?= $user['manage']; ?> </h3>
                        <p class="card-text">Aplikasi ini dikembangkan sebagai sistem monitoring perkembangan hasil belajar dan prestasi <?= $sekolah['nama_sekolah']; ?> </p>

                    </div>
                </div>



            </div>

            <div class="card-group">
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="d-flex no-block align-items-center">
                                    <div>
                                        <h3><i class="icon-user"></i></h3>
                                        <p class="text-muted">Jumlah Users</p>
                                    </div>
                                    <div class="ml-auto">
                                        <h2 class="counter text-primary">
                                            <?= $total = number_format($this->db->get_where('user', array('role_id' => 2))->num_rows(), 0, ",", "."); ?>
                                        </h2>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="progress">
                                    <div class="progress-bar bg-primary" role="progressbar" style="width: 85%; height: 6px;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Column -->
                <!-- Column -->
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="d-flex no-block align-items-center">
                                    <div>
                                        <h3><i class="icon-book-open"></i></h3>
                                        <p class="text-muted">Jumlah Kelas</p>
                                    </div>
                                    <div class="ml-auto">
                                        <h2 class="counter text-cyan">
                                            <?= $kelas = number_format($this->db->get('kelas')->num_rows(), 0, ",", "."); ?>
                                        </h2>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="progress">
                                    <div class="progress-bar bg-cyan" role="progressbar" style="width: 85%; height: 6px;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Column -->
                <!-- Column -->
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col-md-12">
                                <div class="d-flex no-block align-items-center">
                                    <div>
                                        <h3><i class="icon-people"></i></h3>
                                        <p class="text-muted">Jumlah Siswa</p>
                                    </div>
                                    <div class="ml-auto">
                                        <h2 class="counter text-purple">
                                            <?= $siswa = number_format($this->db->get_where('peserta_didik', array('status_pd' => 'aktif'))->num_rows(), 0, ",", "."); ?>
                                        </h2>
                                    </div>
                                </div>
                            </div>
                            <div class="col-12">
                                <div class="progress">
                                    <div class="progress-bar bg-purple" role="progressbar" style="width: 85%; height: 6px;" aria-valuenow="25" aria-valuemin="0" aria-valuemax="100"></div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
                <!-- Column -->

                <!-- ============================================================== -->
                <!-- End Info box -->



            </div>


        </div>
        <!-- Column -->
    </div>
    <!-- Row -->
    <!-- ============================================================== -->
    <!-- End PAge Content -->

    <!-- /.container-fluid -->



</div>


<!-- End of Main Content -->