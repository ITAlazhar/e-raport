-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 23 Agu 2021 pada 09.27
-- Versi server: 10.4.8-MariaDB
-- Versi PHP: 7.2.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `projecterapor`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `ekstrakurikuler`
--

CREATE TABLE `ekstrakurikuler` (
  `id_ekskul` int(11) NOT NULL,
  `nama_ekskul` varchar(256) NOT NULL,
  `keterangan` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `ekstrakurikuler`
--

INSERT INTO `ekstrakurikuler` (`id_ekskul`, `nama_ekskul`, `keterangan`) VALUES
(1, 'Pramuka', 'Ekskul Wajib'),
(2, 'Basket', 'Ekskul Pilihan');

-- --------------------------------------------------------

--
-- Struktur dari tabel `identitas_sekolah`
--

CREATE TABLE `identitas_sekolah` (
  `id` int(11) NOT NULL,
  `nama_sekolah` varchar(256) NOT NULL,
  `npsn` varchar(256) NOT NULL,
  `alamat_sekolah` text NOT NULL,
  `kecamatan` text NOT NULL,
  `kabupaten` text NOT NULL,
  `provinsi` text NOT NULL,
  `kode_pos` int(11) NOT NULL,
  `telepon` varchar(15) NOT NULL,
  `email_sekolah` varchar(256) NOT NULL,
  `logo` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `identitas_sekolah`
--

INSERT INTO `identitas_sekolah` (`id`, `nama_sekolah`, `npsn`, `alamat_sekolah`, `kecamatan`, `kabupaten`, `provinsi`, `kode_pos`, `telepon`, `email_sekolah`, `logo`) VALUES
(1, 'SMA NEGERI 19 PALEMBANG', '10603856', 'Jl. Gubernur H. A. Bastari, Seberang Ulu I, Sungai Kedukan', 'Kec. Rambutan', 'Kota Palembang', 'Sumatera Selatan', 30967, '(0711) 7077785', 'sman19plbg@gmail.com', 'logo_sma191.png');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kelas`
--

CREATE TABLE `kelas` (
  `id` int(11) NOT NULL,
  `nama_kelas` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `kelas`
--

INSERT INTO `kelas` (`id`, `nama_kelas`) VALUES
(1, 'X IPA 1'),
(2, 'X IPA 2'),
(3, 'X IPA 3');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kode_mapel`
--

CREATE TABLE `kode_mapel` (
  `id` int(11) NOT NULL,
  `nama_kelas` varchar(256) NOT NULL,
  `nama_mapel` varchar(256) NOT NULL,
  `kode_mapel` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `kode_mapel`
--

INSERT INTO `kode_mapel` (`id`, `nama_kelas`, `nama_mapel`, `kode_mapel`) VALUES
(1, 'X IPA 1', 'Pendidikan Agama Islam', 'X.IPA.1.PAI'),
(2, 'X IPA 1', 'PKn', 'X.IPA.1.PKN'),
(3, 'X IPA 1', 'Bahasa Indonesia', 'X.IPA.1.BINDO'),
(4, 'X IPA 1', 'Matematika', 'X.IPA.1.MTK'),
(5, 'X IPA 2', 'Pendidikan Agama Islam', 'X.IPA.2.PAI'),
(6, 'X IPA 2', 'PKn', 'X.IPA.2.PKN'),
(7, 'X IPA 2', 'Bahasa Indonesia', 'X.IPA.2.BINDO'),
(8, 'X IPA 1', 'Bahasa Inggris', 'X.IPA.1.ENG'),
(9, 'X IPA 1', 'Seni Budaya', 'X.IPA.1.SENBUD'),
(10, 'X IPA 1', 'Sejarah Indonesia', 'X.IPA.1.SEJARAHINDO'),
(11, 'X IPA 1', 'Prakarya dan Kewirausahaan', 'X.IPA.1.PKWU'),
(12, 'X IPA 1', 'Penjas dan Orkes', 'X.IPA.1.PJOK'),
(13, 'X IPA 1', 'Matematika Peminatan', 'X.IPA.1.MTKPEMINATAN'),
(14, 'X IPA 1', 'Biologi', 'X.IPA.1.BIO'),
(15, 'X IPA 1', 'Fisika', 'X.IPA.1.FIS'),
(16, 'X IPA 1', 'Kimia', 'X.IPA.1.KIM');

-- --------------------------------------------------------

--
-- Struktur dari tabel `leger_ekskul`
--

CREATE TABLE `leger_ekskul` (
  `id` int(11) NOT NULL,
  `nama_kelas` varchar(256) NOT NULL,
  `thn_pelajaran` varchar(256) NOT NULL,
  `nisn` int(20) NOT NULL,
  `nama_pesertadidik` varchar(256) NOT NULL,
  `nama_ekskul` varchar(256) NOT NULL,
  `nilai_ekskul` varchar(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `leger_ekskul`
--

INSERT INTO `leger_ekskul` (`id`, `nama_kelas`, `thn_pelajaran`, `nisn`, `nama_pesertadidik`, `nama_ekskul`, `nilai_ekskul`) VALUES
(1, 'X IPA 1', '2020/2021 Semester 2', 6716, 'ADITIA PRATAMA', 'Futsal', 'A'),
(2, 'X IPA 1', '2020/2021 Semester 2', 6717, 'AGSHA NURRAHMA', 'Futsal', 'A'),
(3, 'X IPA 1', '2020/2021 Semester 2', 6718, 'ALYA DWI HAPSARI', 'Futsal', 'A'),
(4, 'X IPA 1', '2020/2021 Semester 2', 6719, 'ANDI GARA', 'Seni Tari', 'A'),
(5, 'X IPA 1', '2020/2021 Semester 2', 6720, 'ANDI HAIDI FITRA', 'Vokal', 'A'),
(6, 'X IPA 1', '2020/2021 Semester 2', 6721, 'ANDIKA', 'Futsal', 'A'),
(7, 'X IPA 1', '2020/2021 Semester 2', 6722, 'APRIMA DAMAYANTI', 'Public Speaking', 'A'),
(8, 'X IPA 1', '2020/2021 Semester 2', 6723, 'AULIYA HAMIDAH', 'Tari', 'A');

-- --------------------------------------------------------

--
-- Struktur dari tabel `leger_nilai`
--

CREATE TABLE `leger_nilai` (
  `id_legernilai` int(11) NOT NULL,
  `kode_mapel` varchar(256) NOT NULL,
  `thn_pelajaran` varchar(256) NOT NULL,
  `nisn` int(20) NOT NULL,
  `nama_pesertadidik` varchar(256) NOT NULL,
  `nilai_nh` varchar(3) NOT NULL,
  `nilai_pts` varchar(3) NOT NULL,
  `nilai_pas` varchar(3) NOT NULL,
  `nilai_akhir` varchar(3) NOT NULL,
  `deskripsi_np` text NOT NULL,
  `nilai_keterampilan` int(3) NOT NULL,
  `deskripsi_keterampilan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `leger_nilai`
--

INSERT INTO `leger_nilai` (`id_legernilai`, `kode_mapel`, `thn_pelajaran`, `nisn`, `nama_pesertadidik`, `nilai_nh`, `nilai_pts`, `nilai_pas`, `nilai_akhir`, `deskripsi_np`, `nilai_keterampilan`, `deskripsi_keterampilan`) VALUES
(1, 'X.IPA.1.PAI', '2020/2021 Semester 2', 6716, 'ADITIA PRATAMA', '88', '88', '91', '89', 'Sangat baik dalam memahami makna iman kepada hari akhir dan ketentuan-ketentuan Allah tentang hari akhir dan perlu ditingkatkan dalam memahami makna/isi kandungan hadits Rasulullah SAW. tentang : hak seorang muslim, wasiat tetangga, pentingnya bekerja, tanggung jawab dalam pandangan islam, larangan menyakiti orang lain, bahayanya sebuah ucapan, amal yang paling dicintai oleh Allah, 7 golongan yang mendapatkan naungan dari Allah, etika ketika berada di jalanan, dan hadits tentang perlindungan untuk non muslim, tata krama sopan santun dan rasa malu..', 88, 'Memiliki keterampilan dalam menyajikan dalil-dalil tentang iman kepada hari akhir.'),
(2, 'X.IPA.1.PAI', '2020/2021 Semester 2', 6717, 'AGSHA NURRAHMA', '90', '96', '90', '92', 'Sangat baik dalam memahami sejarah Islam di tentang Ghazwh Khaibar, Mu\'tah, Fathul Makkah, Ghazwah Hunain. dan perlu ditingkatkan dalam memahami makna iman kepada hari akhir dan ketentuan-ketentuan Allah tentang hari akhir.', 90, 'Memiliki keterampilan dalam menyajikan dalil-dalil tentang iman kepada hari akhir.'),
(3, 'X.IPA.1.PAI', '2020/2021 Semester 2', 6718, 'ALYA DWI HAPSARI', '92', '97', '94', '94', 'Sangat baik dalam memahami makna iman kepada hari akhir dan ketentuan-ketentuan Allah tentang hari akhir dan perlu ditingkatkan dalam memahami makna/isi kandungan hadits Rasulullah SAW. tentang : hak seorang muslim, wasiat tetangga, pentingnya bekerja, tanggung jawab dalam pandangan islam, larangan menyakiti orang lain, bahayanya sebuah ucapan, amal yang paling dicintai oleh Allah, 7 golongan yang mendapatkan naungan dari Allah, etika ketika berada di jalanan, dan hadits tentang perlindungan untuk non muslim, tata krama sopan santun dan rasa malu..', 92, 'Memiliki keterampilan dalam menyajikan dalil-dalil tentang iman kepada hari akhir.'),
(4, 'X.IPA.1.PAI', '2020/2021 Semester 2', 6719, 'ANDI GARA', '93', '95', '97', '95', 'Sangat baik dalam memahami makna iman kepada hari akhir dan ketentuan-ketentuan Allah tentang hari akhir dan perlu ditingkatkan dalam memahami makna/isi kandungan hadits Rasulullah SAW. tentang : hak seorang muslim, wasiat tetangga, pentingnya bekerja, tanggung jawab dalam pandangan islam, larangan menyakiti orang lain, bahayanya sebuah ucapan, amal yang paling dicintai oleh Allah, 7 golongan yang mendapatkan naungan dari Allah, etika ketika berada di jalanan, dan hadits tentang perlindungan untuk non muslim, tata krama sopan santun dan rasa malu..', 93, 'Memiliki keterampilan dalam menyajikan dalil-dalil tentang iman kepada hari akhir.'),
(5, 'X.IPA.1.PAI', '2020/2021 Semester 2', 6720, 'ANDI HAIDI FITRA', '87', '88', '92', '89', 'Sangat baik dalam memahami makna iman kepada hari akhir dan ketentuan-ketentuan Allah tentang hari akhir dan perlu ditingkatkan dalam memahami makna iman kepada hari akhir dan ketentuan-ketentuan Allah tentang hari akhir.', 87, 'Memiliki keterampilan dalam menyajikan dalil-dalil tentang iman kepada hari akhir.'),
(6, 'X.IPA.1.PAI', '2020/2021 Semester 2', 6721, 'ANDIKA', '90', '90', '93', '91', 'Sangat baik dalam memahami makna iman kepada hari akhir dan ketentuan-ketentuan Allah tentang hari akhir dan perlu ditingkatkan dalam memahami makna iman kepada hari akhir dan ketentuan-ketentuan Allah tentang hari akhir.', 90, 'Memiliki keterampilan dalam menyajikan dalil-dalil tentang iman kepada hari akhir.'),
(7, 'X.IPA.1.PAI', '2020/2021 Semester 2', 6722, 'APRIMA DAMAYANTI', '91', '93', '95', '93', 'Sangat baik dalam memahami isi kandungan Al-Qur’an Surah : Al-baqoroh: 23-24 Al-maidah: 33-34, At-taubah:128-129, An-nur: 30-31,Al-ankabut: 46, Al-hujurat : 11-12, Az-zumar: 53, An-najm: 39-42, Ali imran: 159,Al-hujurat : 13 dan perlu ditingkatkan dalam memahami makna iman kepada hari akhir dan ketentuan-ketentuan Allah tentang hari akhir.', 91, 'Memiliki keterampilan dalam menyajikan dalil-dalil tentang iman kepada hari akhir.'),
(8, 'X.IPA.1.PAI', '2020/2021 Semester 2', 6723, 'AULIYA HAMIDAH', '87', '95', '92', '91', 'Sangat baik dalam memahami makna/isi kandungan hadits Rasulullah SAW. tentang : hak seorang muslim, wasiat tetangga, pentingnya bekerja, tanggung jawab dalam pandangan islam, larangan menyakiti orang lain, bahayanya sebuah ucapan, amal yang paling dicintai oleh Allah, 7 golongan yang mendapatkan naungan dari Allah, etika ketika berada di jalanan, dan hadits tentang perlindungan untuk non muslim, tata krama sopan santun dan rasa malu. dan perlu ditingkatkan dalam memahami makna iman kepada hari akhir dan ketentuan-ketentuan Allah tentang hari akhir.', 87, 'Memiliki keterampilan dalam menyajikan dalil-dalil tentang iman kepada hari akhir.'),
(9, 'X.IPA.1.PKN', '2020/2021 Semester 2', 6716, 'ADITIA PRATAMA', '92', '88', '95', '92', 'Sangat baik dalam menganalisis prinsip persatuan dalam keberagaman suku, ras, agama dan antargolongan (SARA), sosial, budaya, ekonomi dan gender dalam bingkai Bhinneka Tunggal Ika dan perlu ditingkatkan dalam mengkreasikan konsep cinta tanah air/bela negara dalam konteks Negara Kesatuan Republikk Indonesia.', 95, 'Memiliki keterampilan dalam mendemonstrasikan hasil analisis prinsip persatuan dalam keberagaman suku, ras, agama dan antargolongan (SARA) dalam bingkai Bhinneka Tunggal Ika.'),
(10, 'X.IPA.1.PKN', '2020/2021 Semester 2', 6717, 'AGSHA NURRAHMA', '90', '88', '90', '89', 'Sangat baik dalam menganalisis prinsip persatuan dalam keberagaman suku, ras, agama dan antargolongan (SARA), sosial, budaya, ekonomi dan gender dalam bingkai Bhinneka Tunggal Ika dan perlu ditingkatkan dalam mengkreasikan konsep cinta tanah air/bela negara dalam konteks Negara Kesatuan Republikk Indonesia.', 92, 'Memiliki keterampilan dalam mendemonstrasikan hasil analisis prinsip persatuan dalam keberagaman suku, ras, agama dan antargolongan (SARA) dalam bingkai Bhinneka Tunggal Ika.'),
(11, 'X.IPA.1.PKN', '2020/2021 Semester 2', 6718, 'ALYA DWI HAPSARI', '92', '94', '90', '92', 'Sangat baik dalam menganalisis prinsip persatuan dalam keberagaman suku, ras, agama dan antargolongan (SARA), sosial, budaya, ekonomi dan gender dalam bingkai Bhinneka Tunggal Ika dan perlu ditingkatkan dalam menganalisis prinsip persatuan dalam keberagaman suku, ras, agama dan antargolongan (SARA), sosial, budaya, ekonomi dan gender dalam bingkai Bhinneka Tunggal Ika.', 94, 'Memiliki keterampilan dalam mendemonstrasikan hasil analisis prinsip persatuan dalam keberagaman suku, ras, agama dan antargolongan (SARA) dalam bingkai Bhinneka Tunggal Ika.'),
(12, 'X.IPA.1.PKN', '2020/2021 Semester 2', 6719, 'ANDI GARA', '92', '95', '95', '94', 'Sangat baik dalam menganalisis prinsip persatuan dalam keberagaman suku, ras, agama dan antargolongan (SARA), sosial, budaya, ekonomi dan gender dalam bingkai Bhinneka Tunggal Ika dan perlu ditingkatkan dalam menganalisis prinsip persatuan dalam keberagaman suku, ras, agama dan antargolongan (SARA), sosial, budaya, ekonomi dan gender dalam bingkai Bhinneka Tunggal Ika.', 92, 'Memiliki keterampilan dalam mendemonstrasikan hasil analisis prinsip persatuan dalam keberagaman suku, ras, agama dan antargolongan (SARA) dalam bingkai Bhinneka Tunggal Ika.'),
(13, 'X.IPA.1.PKN', '2020/2021 Semester 2', 6720, 'ANDI HAIDI FITRA', '96', '94', '94', '95', 'Sangat baik dalam menganalisis prinsip persatuan dalam keberagaman suku, ras, agama dan antargolongan (SARA), sosial, budaya, ekonomi dan gender dalam bingkai Bhinneka Tunggal Ika dan perlu ditingkatkan dalam mengkreasikan konsep cinta tanah air/bela negara dalam konteks Negara Kesatuan Republikk Indonesia.', 97, 'Memiliki keterampilan dalam mendemonstrasikan hasil analisis prinsip persatuan dalam keberagaman suku, ras, agama dan antargolongan (SARA) dalam bingkai Bhinneka Tunggal Ika.'),
(14, 'X.IPA.1.PKN', '2020/2021 Semester 2', 6721, 'ANDIKA', '80', '85', '82', '82', 'Sangat baik dalam menganalisis prinsip persatuan dalam keberagaman suku, ras, agama dan antargolongan (SARA), sosial, budaya, ekonomi dan gender dalam bingkai Bhinneka Tunggal Ika dan perlu ditingkatkan dalam menganalisis prinsip persatuan dalam keberagaman suku, ras, agama dan antargolongan (SARA), sosial, budaya, ekonomi dan gender dalam bingkai Bhinneka Tunggal Ika.', 84, 'Memiliki keterampilan dalam mendemonstrasikan hasil analisis prinsip persatuan dalam keberagaman suku, ras, agama dan antargolongan (SARA) dalam bingkai Bhinneka Tunggal Ika.'),
(15, 'X.IPA.1.PKN', '2020/2021 Semester 2', 6722, 'APRIMA DAMAYANTI', '87', '84', '83', '85', 'Sangat baik dalam menganalisis prinsip persatuan dalam keberagaman suku, ras, agama dan antargolongan (SARA), sosial, budaya, ekonomi dan gender dalam bingkai Bhinneka Tunggal Ika dan perlu ditingkatkan dalam menganalisis prinsip persatuan dalam keberagaman suku, ras, agama dan antargolongan (SARA), sosial, budaya, ekonomi dan gender dalam bingkai Bhinneka Tunggal Ika.', 85, 'Memiliki keterampilan dalam menyampaikan hasil analisis prinsip harmoni dalam keberagaman suku, agama, ras dan antargolongan (SARA) sosial, budaya, ekonomi dan gender dalam bingkai Bhinneka Tunggal Ika.'),
(16, 'X.IPA.1.PKN', '2020/2021 Semester 2', 6723, 'AULIYA HAMIDAH', '82', '86', '85', '84', 'Sangat baik dalam menganalisis prinsip harmoni dalam keberagaman suku, agama, ras dan antargolongan (SARA) sosial, budaya, ekonomi dan gender dalam bingkai Bhinneka Tunggal Ika. dan perlu ditingkatkan dalam menganalisis prinsip persatuan dalam keberagaman suku, ras, agama dan antargolongan (SARA), sosial, budaya, ekonomi dan gender dalam bingkai Bhinneka Tunggal Ika.', 82, 'Memiliki keterampilan dalam menyampaikan hasil analisis prinsip harmoni dalam keberagaman suku, agama, ras dan antargolongan (SARA) sosial, budaya, ekonomi dan gender dalam bingkai Bhinneka Tunggal Ika.'),
(17, 'X.IPA.1.BINDO', '2020/2021 Semester 2', 6716, 'ADITIA PRATAMA', '86', '92', '85', '88', 'Sangat baik dalam menelaah pendapat, argumen yang mendukung dan yang kontra dalam teks diskusi berkaitan dengan permasalahan  aktual yang dibaca dan dengar dan perlu ditingkatkan dalam mengidentifikasi isi ungkapan simpati, kepeduliaan, empati, atau perasaan pribadi dari teks cerita ispiratif yang dibaca dan di dengar.', 88, 'Memiliki keterampilan dalam mengungkapkan kritik, sanggahan, atau pujian dalam bentuk teks tanggapan secara lisan dan/atau tulis dengan memperhatikan struktur dan kebahasaan.'),
(18, 'X.IPA.1.BINDO', '2020/2021 Semester 2', 6717, 'AGSHA NURRAHMA', '85', '92', '83', '87', 'Sangat baik dalam menelaah pendapat, argumen yang mendukung dan yang kontra dalam teks diskusi berkaitan dengan permasalahan  aktual yang dibaca dan dengar dan perlu ditingkatkan dalam menelaah struktur dan kebahasaan dari teks tanggapan (lingkungan hidup, kondisi sosial, dan/atau keragaman budaya, dll) berupa kritik, sanggahan, atau pujian yang didengar dan/atau dibaca.', 83, 'Memiliki keterampilan dalam mengungkapkan kritik, sanggahan, atau pujian dalam bentuk teks tanggapan secara lisan dan/atau tulis dengan memperhatikan struktur dan kebahasaan.'),
(19, 'X.IPA.1.BINDO', '2020/2021 Semester 2', 6718, 'ALYA DWI HAPSARI', '89', '92', '89', '90', 'Sangat baik dalam menelaah pendapat, argumen yang mendukung dan yang kontra dalam teks diskusi berkaitan dengan permasalahan  aktual yang dibaca dan dengar dan perlu ditingkatkan dalam menelaah struktur dan kebahasaan dari teks tanggapan (lingkungan hidup, kondisi sosial, dan/atau keragaman budaya, dll) berupa kritik, sanggahan, atau pujian yang didengar dan/atau dibaca.', 83, 'Memiliki keterampilan dalam menyimpulkan isi ungkapan simpati, kepedulian, empati atau perasaan pribadi dalam bentuk cerita inspiratif yang dibaca dan di dengar.'),
(20, 'X.IPA.1.BINDO', '2020/2021 Semester 2', 6719, 'ANDI GARA', '88', '95', '89', '91', 'Sangat baik dalam mengidentifikasi informasi dari teks diskusi berupa pendapat pro dan kontra dari permasalahan aktual yang dibaca  dan didengar dan perlu ditingkatkan dalam menelaah struktur  kebahasaan dan isi teks cerita ispiratif.', 88, 'Memiliki keterampilan dalam menyimpulkan isi ungkapan simpati, kepedulian, empati atau perasaan pribadi dalam bentuk cerita inspiratif yang dibaca dan di dengar.'),
(21, 'X.IPA.1.BINDO', '2020/2021 Semester 2', 6720, 'ANDI HAIDI FITRA', '83', '94', '80', '86', 'Sangat baik dalam menelaah pendapat, argumen yang mendukung dan yang kontra dalam teks diskusi berkaitan dengan permasalahan  aktual yang dibaca dan dengar dan perlu ditingkatkan dalam mengidentifikasi isi ungkapan simpati, kepeduliaan, empati, atau perasaan pribadi dari teks cerita ispiratif yang dibaca dan di dengar.', 83, 'Memiliki keterampilan dalam mengungkapkan kritik, sanggahan, atau pujian dalam bentuk teks tanggapan secara lisan dan/atau tulis dengan memperhatikan struktur dan kebahasaan.'),
(22, 'X.IPA.1.BINDO', '2020/2021 Semester 2', 6721, 'ANDIKA', '83', '92', '87', '87', 'Sangat baik dalam menelaah pendapat, argumen yang mendukung dan yang kontra dalam teks diskusi berkaitan dengan permasalahan  aktual yang dibaca dan dengar dan perlu ditingkatkan dalam menelaah struktur dan kebahasaan dari teks tanggapan (lingkungan hidup, kondisi sosial, dan/atau keragaman budaya, dll) berupa kritik, sanggahan, atau pujian yang didengar dan/atau dibaca.', 89, 'Memiliki keterampilan dalam mengungkapkan rasa simpati, empati, kepedulian, dan perasaan dalam bentuk cerita inspiratif yang dibaca dan di dengar.'),
(23, 'X.IPA.1.BINDO', '2020/2021 Semester 2', 6722, 'APRIMA DAMAYANTI', '85', '95', '82', '87', 'Sangat baik dalam menelaah pendapat, argumen yang mendukung dan yang kontra dalam teks diskusi berkaitan dengan permasalahan  aktual yang dibaca dan dengar dan perlu ditingkatkan dalam mengidentifikasi isi ungkapan simpati, kepeduliaan, empati, atau perasaan pribadi dari teks cerita ispiratif yang dibaca dan di dengar.', 84, 'Memiliki keterampilan dalam mengungkapkan rasa simpati, empati, kepedulian, dan perasaan dalam bentuk cerita inspiratif yang dibaca dan di dengar.'),
(24, 'X.IPA.1.BINDO', '2020/2021 Semester 2', 6723, 'AULIYA HAMIDAH', '85', '92', '88', '88', 'Sangat baik dalam menelaah pendapat, argumen yang mendukung dan yang kontra dalam teks diskusi berkaitan dengan permasalahan  aktual yang dibaca dan dengar dan perlu ditingkatkan dalam mengidentifikasi isi ungkapan simpati, kepeduliaan, empati, atau perasaan pribadi dari teks cerita ispiratif yang dibaca dan di dengar.', 86, 'Memiliki keterampilan dalam mengungkapkan kritik, sanggahan, atau pujian dalam bentuk teks tanggapan secara lisan dan/atau tulis dengan memperhatikan struktur dan kebahasaan.'),
(25, 'X.IPA.1.MTK', '2020/2021 Semester 2', 6716, 'ADITIA PRATAMA', '91', '93', '90', '91', 'Sangat baik dalam menjelaskan dan menentukan kesebangunan dan kekongruenan pada bangun datar dan perlu ditingkatkan dalam membuat generalisi  luas permukaan dan volume berbagai bangun ruang sisi lengkung (tabung, kerucut, dan bola).', 87, 'Memiliki keterampilan dalam menyelesaikan  masalah yang berkaitan dengan kesebangunan dan kekongruenan antar bangun\ndatar\n.'),
(26, 'X.IPA.1.MTK', '2020/2021 Semester 2', 6717, 'AGSHA NURRAHMA', '92', '96', '94', '94', 'Sangat baik dalam menjelaskan dan menentukan kesebangunan dan kekongruenan pada bangun datar dan perlu ditingkatkan dalam membuat generalisi  luas permukaan dan volume berbagai bangun ruang sisi lengkung (tabung, kerucut, dan bola).', 88, 'Memiliki keterampilan dalam menyelesaikan  masalah yang berkaitan dengan kesebangunan dan kekongruenan antar bangun\ndatar\n.'),
(27, 'X.IPA.1.MTK', '2020/2021 Semester 2', 6718, 'ALYA DWI HAPSARI', '86', '88', '94', '89', 'Sangat baik dalam membuat generalisi  luas permukaan dan volume berbagai bangun ruang sisi lengkung (tabung, kerucut, dan bola) dan perlu ditingkatkan dalam membuat generalisi  luas permukaan dan volume berbagai bangun ruang sisi lengkung (tabung, kerucut, dan bola).', 87, 'Memiliki keterampilan dalam menyelesaikan  masalah yang berkaitan dengan kesebangunan dan kekongruenan antar bangun\ndatar\n.'),
(28, 'X.IPA.1.MTK', '2020/2021 Semester 2', 6719, 'ANDI GARA', '93', '98', '94', '95', 'Sangat baik dalam membuat generalisi  luas permukaan dan volume berbagai bangun ruang sisi lengkung (tabung, kerucut, dan bola) dan perlu ditingkatkan dalam membuat generalisi  luas permukaan dan volume berbagai bangun ruang sisi lengkung (tabung, kerucut, dan bola).', 83, 'Memiliki keterampilan dalam menyelesaikan  masalah yang berkaitan dengan kesebangunan dan kekongruenan antar bangun\ndatar\n.'),
(29, 'X.IPA.1.MTK', '2020/2021 Semester 2', 6720, 'ANDI HAIDI FITRA', '86', '88', '90', '88', 'Baik dalam menjelaskan dan menentukan kesebangunan dan kekongruenan pada bangun datar dan perlu ditingkatkan dalam membuat generalisi  luas permukaan dan volume berbagai bangun ruang sisi lengkung (tabung, kerucut, dan bola).', 87, 'Memiliki keterampilan dalam menyelesaikan  masalah yang berkaitan dengan kesebangunan dan kekongruenan antar bangun\ndatar\n.'),
(30, 'X.IPA.1.MTK', '2020/2021 Semester 2', 6721, 'ANDIKA', '89', '90', '92', '90', 'Sangat baik dalam menjelaskan dan menentukan kesebangunan dan kekongruenan pada bangun datar dan perlu ditingkatkan dalam membuat generalisi  luas permukaan dan volume berbagai bangun ruang sisi lengkung (tabung, kerucut, dan bola).', 84, 'Memiliki keterampilan dalam menyelesaikan masalah kontekstual yang berkaitan dengan luas permukaan dan volume bangun ruang sisi lengkung (tabung, kerucut, dan bola), serta gabungan beberapa bangun ruang\nsisi lengkung\n.'),
(31, 'X.IPA.1.MTK', '2020/2021 Semester 2', 6722, 'APRIMA DAMAYANTI', '88', '84', '91', '88', 'Sangat baik dalam membuat generalisi  luas permukaan dan volume berbagai bangun ruang sisi lengkung (tabung, kerucut, dan bola) dan perlu ditingkatkan dalam membuat generalisi  luas permukaan dan volume berbagai bangun ruang sisi lengkung (tabung, kerucut, dan bola).', 89, 'Memiliki keterampilan dalam menyelesaikan masalah kontekstual yang berkaitan dengan luas permukaan dan volume bangun ruang sisi lengkung (tabung, kerucut, dan bola), serta gabungan beberapa bangun ruang\nsisi lengkung\n.'),
(32, 'X.IPA.1.MTK', '2020/2021 Semester 2', 6723, 'AULIYA HAMIDAH', '90', '92', '88', '90', 'Sangat baik dalam membuat generalisi  luas permukaan dan volume berbagai bangun ruang sisi lengkung (tabung, kerucut, dan bola) dan perlu ditingkatkan dalam membuat generalisi  luas permukaan dan volume berbagai bangun ruang sisi lengkung (tabung, kerucut, dan bola).', 84, 'Memiliki keterampilan dalam menyelesaikan  masalah yang berkaitan dengan kesebangunan dan kekongruenan antar bangun\ndatar\n.'),
(33, 'X.IPA.1.SEJARAHINDO', '2020/2021 Semester 2', 6716, 'ADITIA PRATAMA', '85', '88', '93', '89', 'Sangat baik dalam Menganalisis ketergantungan antarruang dilihat dari konsep ekonomi (produksi,distribusi,konsumsi,harga dan pasar dan pengaruhnya terhadap migrasi penduduk transportasi, lembaga sosial dan ekonomi, pekerjaan, pendidikan  dan kesejahteraan masyarakat dan perlu ditingkatkan dalam Menganalisis kronologi perubahan dan kesinambungan ruang (geografis,politik, ekonomi, pendidikan, sosial dan budaya) dari awal kemerdekaan sampai awal reformasi.', 86, 'Memiliki keterampilan dalam menganalisis ketergantungan antarruang dilihat dari konsep ekonomi (produksi,distribusi,konsumsi,harga dan pasar dan pengaruhnya terhadap migrasi penduduk transportasi, lembaga sosial dan ekonomi, pekerjaan, pendidikan  dan kesejahteraan masyarakat.'),
(34, 'X.IPA.1.SEJARAHINDO', '2020/2021 Semester 2', 6717, 'AGSHA NURRAHMA', '85', '87', '86', '86', 'Cukup baik dalam Menganalisis kronologi perubahan dan kesinambungan ruang (geografis,politik, ekonomi, pendidikan, sosial dan budaya) dari awal kemerdekaan sampai awal reformasi dan perlu ditingkatkan dalam Menganalisis ketergantungan antarruang dilihat dari konsep ekonomi (produksi,distribusi,konsumsi,harga dan pasar dan pengaruhnya terhadap migrasi penduduk transportasi, lembaga sosial dan ekonomi, pekerjaan, pendidikan  dan kesejahteraan masyarakat.', 87, 'Memiliki keterampilan dalam menganalisis ketergantungan antarruang dilihat dari konsep ekonomi (produksi,distribusi,konsumsi,harga dan pasar dan pengaruhnya terhadap migrasi penduduk transportasi, lembaga sosial dan ekonomi, pekerjaan, pendidikan  dan kesejahteraan masyarakat.'),
(35, 'X.IPA.1.SEJARAHINDO', '2020/2021 Semester 2', 6718, 'ALYA DWI HAPSARI', '89', '83', '86', '86', 'Sangat baik dalam Menganalisis ketergantungan antarruang dilihat dari konsep ekonomi (produksi,distribusi,konsumsi,harga dan pasar dan pengaruhnya terhadap migrasi penduduk transportasi, lembaga sosial dan ekonomi, pekerjaan, pendidikan  dan kesejahteraan masyarakat dan perlu ditingkatkan dalam Menganalisis kronologi perubahan dan kesinambungan ruang (geografis,politik, ekonomi, pendidikan, sosial dan budaya) dari awal kemerdekaan sampai awal reformasi.', 88, 'Memiliki keterampilan dalam menganalisis ketergantungan antarruang dilihat dari konsep ekonomi (produksi,distribusi,konsumsi,harga dan pasar dan pengaruhnya terhadap migrasi penduduk transportasi, lembaga sosial dan ekonomi, pekerjaan, pendidikan  dan kesejahteraan masyarakat.'),
(36, 'X.IPA.1.SEJARAHINDO', '2020/2021 Semester 2', 6719, 'ANDI GARA', '89', '88', '86', '88', 'Sangat baik dalam Menganalisis kronologi perubahan dan kesinambungan ruang (geografis,politik, ekonomi, pendidikan, sosial dan budaya) dari awal kemerdekaan sampai awal reformasi dan perlu ditingkatkan dalam Menganalisis ketergantungan antarruang dilihat dari konsep ekonomi (produksi,distribusi,konsumsi,harga dan pasar dan pengaruhnya terhadap migrasi penduduk transportasi, lembaga sosial dan ekonomi, pekerjaan, pendidikan  dan kesejahteraan masyarakat.', 85, 'Memiliki keterampilan dalam menganalisis ketergantungan antarruang dilihat dari konsep ekonomi (produksi,distribusi,konsumsi,harga dan pasar dan pengaruhnya terhadap migrasi penduduk transportasi, lembaga sosial dan ekonomi, pekerjaan, pendidikan  dan kesejahteraan masyarakat.'),
(37, 'X.IPA.1.SEJARAHINDO', '2020/2021 Semester 2', 6720, 'ANDI HAIDI FITRA', '80', '83', '86', '83', 'Baik dalam Menganalisis kronologi perubahan dan kesinambungan ruang (geografis,politik, ekonomi, pendidikan, sosial dan budaya) dari awal kemerdekaan sampai awal reformasi dan perlu ditingkatkan dalam Menganalisis ketergantungan antarruang dilihat dari konsep ekonomi (produksi,distribusi,konsumsi,harga dan pasar dan pengaruhnya terhadap migrasi penduduk transportasi, lembaga sosial dan ekonomi, pekerjaan, pendidikan  dan kesejahteraan masyarakat.', 88, 'Memiliki keterampilan dalam menganalisis ketergantungan antarruang dilihat dari konsep ekonomi (produksi,distribusi,konsumsi,harga dan pasar dan pengaruhnya terhadap migrasi penduduk transportasi, lembaga sosial dan ekonomi, pekerjaan, pendidikan  dan kesejahteraan masyarakat.'),
(38, 'X.IPA.1.SEJARAHINDO', '2020/2021 Semester 2', 6721, 'ANDIKA', '87', '89', '88', '88', 'Baik dalam Menganalisis kronologi perubahan dan kesinambungan ruang (geografis,politik, ekonomi, pendidikan, sosial dan budaya) dari awal kemerdekaan sampai awal reformasi dan perlu ditingkatkan dalam Menganalisis ketergantungan antarruang dilihat dari konsep ekonomi (produksi,distribusi,konsumsi,harga dan pasar dan pengaruhnya terhadap migrasi penduduk transportasi, lembaga sosial dan ekonomi, pekerjaan, pendidikan  dan kesejahteraan masyarakat.', 88, 'Memiliki keterampilan dalam menganalisis ketergantungan antarruang dilihat dari konsep ekonomi (produksi,distribusi,konsumsi,harga dan pasar dan pengaruhnya terhadap migrasi penduduk transportasi, lembaga sosial dan ekonomi, pekerjaan, pendidikan  dan kesejahteraan masyarakat.'),
(39, 'X.IPA.1.SEJARAHINDO', '2020/2021 Semester 2', 6722, 'APRIMA DAMAYANTI', '82', '84', '85', '84', 'Baik dalam Menganalisis ketergantungan antarruang dilihat dari konsep ekonomi (produksi,distribusi,konsumsi,harga dan pasar dan pengaruhnya terhadap migrasi penduduk transportasi, lembaga sosial dan ekonomi, pekerjaan, pendidikan  dan kesejahteraan masyarakat dan perlu ditingkatkan dalam Menganalisis kronologi perubahan dan kesinambungan ruang (geografis,politik, ekonomi, pendidikan, sosial dan budaya) dari awal kemerdekaan sampai awal reformasi.', 92, 'Memiliki keterampilan dalam menganalisis ketergantungan antarruang dilihat dari konsep ekonomi (produksi,distribusi,konsumsi,harga dan pasar dan pengaruhnya terhadap migrasi penduduk transportasi, lembaga sosial dan ekonomi, pekerjaan, pendidikan  dan kesejahteraan masyarakat.'),
(40, 'X.IPA.1.SEJARAHINDO', '2020/2021 Semester 2', 6723, 'AULIYA HAMIDAH', '88', '86', '84', '86', 'Cukup baik dalam Menganalisis kronologi perubahan dan kesinambungan ruang (geografis,politik, ekonomi, pendidikan, sosial dan budaya) dari awal kemerdekaan sampai awal reformasi dan perlu ditingkatkan dalam Menganalisis ketergantungan antarruang dilihat dari konsep ekonomi (produksi,distribusi,konsumsi,harga dan pasar dan pengaruhnya terhadap migrasi penduduk transportasi, lembaga sosial dan ekonomi, pekerjaan, pendidikan  dan kesejahteraan masyarakat.', 84, 'Memiliki keterampilan dalam menganalisis ketergantungan antarruang dilihat dari konsep ekonomi (produksi,distribusi,konsumsi,harga dan pasar dan pengaruhnya terhadap migrasi penduduk transportasi, lembaga sosial dan ekonomi, pekerjaan, pendidikan  dan kesejahteraan masyarakat.'),
(49, 'X.IPA.1.ENG', '2020/2021 Semester 2', 6716, 'ADITIA PRATAMA', '85', '88', '93', '89', 'Excellent in comparing  the social function, text structure, and language feature of some oral and written narrative text by asking and giving the information related to short and simple fairy tales with its function and need improving in comparing social functions, text structure, and linguistic element in some oral and written report texts by giving and request information related to other subjects at Class IX,  short and simple, according to context of its use.', 87, 'Have skill in capturing contextual meanings related to social functions, text structure and linguistic elements of report text, very short and simple, related to topics covered in other subjects in class IX.'),
(50, 'X.IPA.1.ENG', '2020/2021 Semester 2', 6717, 'AGSHA NURRAHMA', '83', '83', '98', '88', 'Excellent in comparing  the social function, text structure, and language feature of some oral and written narrative text by asking and giving the information related to short and simple fairy tales with its function and need improving in comparing social functions, text structure, and linguistic element in some oral and written report texts by giving and request information related to other subjects at Class IX,  short and simple, according to context of its use.', 88, 'Have skill in capturing contextual meanings related to social functions, text structure and linguistic elements of report text, very short and simple, related to topics covered in other subjects in class IX.'),
(51, 'X.IPA.1.ENG', '2020/2021 Semester 2', 6718, 'ALYA DWI HAPSARI', '89', '83', '98', '90', 'Excellent in comparing  the social function, text structure, and language feature of some oral and written narrative text by asking and giving the information related to short and simple fairy tales with its function and need improving in comparing social functions, text structure, and linguistic element in some oral and written report texts by giving and request information related to other subjects at Class IX,  short and simple, according to context of its use.', 94, 'Have skill in capturing contextual meanings related to social functions, text structure and linguistic elements of report text, very short and simple, related to topics covered in other subjects in class IX.'),
(52, 'X.IPA.1.ENG', '2020/2021 Semester 2', 6719, 'ANDI GARA', '89', '88', '99', '92', 'Excellent in comparing  the social function, text structure, and language feature of some oral and written narrative text by asking and giving the information related to short and simple fairy tales with its function and need improving in comparing social functions, text structure, and linguistic element in some oral and written report texts by giving and request information related to other subjects at Class IX,  short and simple, according to context of its use.', 83, 'Have skill in capturing the meaning contextually related to social function, text structure, and language feature of some oral and written narrative text by asking and giving the information related to short and simple fairy tales with its function.'),
(53, 'X.IPA.1.ENG', '2020/2021 Semester 2', 6720, 'ANDI HAIDI FITRA', '80', '83', '99', '87', 'Excellent in comparing social functions, text structure, and linguistic element in some oral and written report texts by giving and request information related to other subjects at Class IX,  short and simple, according to context of its use and need improving in comparing  the social function, text structure, and language feature of some oral and written narrative text by asking and giving the information related to short and simple fairy tales with its function.', 87, 'Have skill in capturing the meaning contextually related to social function, text structure, and language feature of some oral and written narrative text by asking and giving the information related to short and simple fairy tales with its function.'),
(54, 'X.IPA.1.ENG', '2020/2021 Semester 2', 6721, 'ANDIKA', '87', '89', '93', '90', 'Excellent in comparing social functions, text structure, and linguistic element in some oral and written report texts by giving and request information related to other subjects at Class IX,  short and simple, according to context of its use and need improving in comparing  the social function, text structure, and language feature of some oral and written narrative text by asking and giving the information related to short and simple fairy tales with its function.', 88, 'Have skill in capturing contextual meanings related to social functions, text structure and linguistic elements of report text, very short and simple, related to topics covered in other subjects in class IX.'),
(55, 'X.IPA.1.ENG', '2020/2021 Semester 2', 6722, 'APRIMA DAMAYANTI', '82', '84', '94', '87', 'Excellent in comparing  the social function, text structure, and language feature of some oral and written narrative text by asking and giving the information related to short and simple fairy tales with its function and need improving in comparing social functions, text structure, and linguistic element in some oral and written report texts by giving and request information related to other subjects at Class IX,  short and simple, according to context of its use.', 96, 'Have skill in capturing the meaning contextually related to social function, text structure, and language feature of some oral and written narrative text by asking and giving the information related to short and simple fairy tales with its function.'),
(56, 'X.IPA.1.ENG', '2020/2021 Semester 2', 6723, 'AULIYA HAMIDAH', '88', '86', '97', '90', 'Excellent in comparing social functions, text structure, and linguistic element in some oral and written report texts by giving and request information related to other subjects at Class IX,  short and simple, according to context of its use and need improving in comparing  the social function, text structure, and language feature of some oral and written narrative text by asking and giving the information related to short and simple fairy tales with its function.', 84, 'Have skill in capturing the meaning contextually related to social function, text structure, and language feature of some oral and written narrative text by asking and giving the information related to short and simple fairy tales with its function.'),
(57, 'X.IPA.1.SENBUD', '2020/2021 Semester 2', 6716, 'ADITIA PRATAMA', '85', '88', '93', '89', 'Memiliki keterampilan dalam mengembangkan ornamentasi ritmis maupun melodis lagu dalam bentuk vokal solo.', 86, 'Memiliki keterampilan dalam mengembangkan ornamentasi ritmis maupun melodis lagu dalam bentuk vokal solo.'),
(58, 'X.IPA.1.SENBUD', '2020/2021 Semester 2', 6717, 'AGSHA NURRAHMA', '85', '87', '86', '86', 'Memiliki keterampilan dalam mengembangkan ornamentasi ritmis maupun melodis lagu dalam bentuk vokal solo.', 87, 'Memiliki keterampilan dalam mengembangkan ornamentasi ritmis maupun melodis lagu dalam bentuk vokal solo.'),
(59, 'X.IPA.1.SENBUD', '2020/2021 Semester 2', 6718, 'ALYA DWI HAPSARI', '89', '83', '86', '86', 'Memiliki keterampilan dalam mengembangkan ornamentasi ritmis maupun melodis lagu dalam bentuk vokal solo.', 88, 'Memiliki keterampilan dalam mengembangkan ornamentasi ritmis maupun melodis lagu dalam bentuk vokal solo.'),
(60, 'X.IPA.1.SENBUD', '2020/2021 Semester 2', 6719, 'ANDI GARA', '89', '88', '86', '88', 'Memiliki keterampilan dalam mengembangkan ornamentasi ritmis maupun melodis lagu dalam bentuk vokal solo.', 85, 'Memiliki keterampilan dalam mengembangkan ornamentasi ritmis maupun melodis lagu dalam bentuk vokal solo.'),
(61, 'X.IPA.1.SENBUD', '2020/2021 Semester 2', 6720, 'ANDI HAIDI FITRA', '80', '83', '86', '83', 'Memiliki keterampilan dalam mengembangkan ornamentasi ritmis maupun melodis lagu dalam bentuk vokal solo.', 88, 'Memiliki keterampilan dalam mengembangkan ornamentasi ritmis maupun melodis lagu dalam bentuk vokal solo.'),
(62, 'X.IPA.1.SENBUD', '2020/2021 Semester 2', 6721, 'ANDIKA', '87', '89', '88', '88', 'Memiliki keterampilan dalam mengembangkan ornamentasi ritmis maupun melodis lagu dalam bentuk vokal solo.', 88, 'Memiliki keterampilan dalam mengembangkan ornamentasi ritmis maupun melodis lagu dalam bentuk vokal solo.'),
(63, 'X.IPA.1.SENBUD', '2020/2021 Semester 2', 6722, 'APRIMA DAMAYANTI', '82', '84', '85', '84', 'Memiliki keterampilan dalam mengembangkan ornamentasi ritmis maupun melodis lagu dalam bentuk vokal solo.', 92, 'Memiliki keterampilan dalam mengembangkan ornamentasi ritmis maupun melodis lagu dalam bentuk vokal solo.'),
(64, 'X.IPA.1.SENBUD', '2020/2021 Semester 2', 6723, 'AULIYA HAMIDAH', '88', '86', '84', '86', 'Memiliki keterampilan dalam mengembangkan ornamentasi ritmis maupun melodis lagu dalam bentuk vokal solo.', 84, 'Memiliki keterampilan dalam mengembangkan ornamentasi ritmis maupun melodis lagu dalam bentuk vokal solo.'),
(65, 'X.IPA.1.PKWU', '2020/2021 Semester 2', 6716, 'ADITIA PRATAMA', '85', '88', '93', '85', 'Sangat baik dalam mengidentifikasi proses pembuatan kerajinan menjahit dan perlu ditingkatkan dalam memahami proses rekayasa.', 86, 'Memiliki keterampilan dalam membuat olahan makanan\n.'),
(66, 'X.IPA.1.PKWU', '2020/2021 Semester 2', 6717, 'AGSHA NURRAHMA', '85', '87', '86', '85', 'Sangat baik dalam mengidentifikasi proses pembuatan kerajinan menjahit dan perlu ditingkatkan dalam menampilkan proses pemeliharaan satwa harapan.', 87, 'Memiliki keterampilan dalam membuat kerajinan fungsi pakai.'),
(67, 'X.IPA.1.PKWU', '2020/2021 Semester 2', 6718, 'ALYA DWI HAPSARI', '89', '83', '86', '88', 'Sangat baik dalam mengidentifikasi proses pembuatan kerajinan menjahit dan perlu ditingkatkan dalam menampilkan proses pemeliharaan satwa harapan.', 88, 'Memiliki keterampilan dalam membuat kerajinan fungsi pakai.'),
(68, 'X.IPA.1.PKWU', '2020/2021 Semester 2', 6719, 'ANDI GARA', '89', '88', '86', '88', 'Sangat baik dalam mengidentifikasi proses pembuatan kerajinan menjahit dan perlu ditingkatkan dalam menampilkan proses pemeliharaan satwa harapan.', 85, 'Memiliki keterampilan dalam membuat kerajinan fungsi pakai.'),
(69, 'X.IPA.1.PKWU', '2020/2021 Semester 2', 6720, 'ANDI HAIDI FITRA', '80', '83', '86', '83', 'Sangat baik dalam mengidentifikasi proses pembuatan kerajinan menjahit dan perlu ditingkatkan dalam menampilkan proses pemeliharaan satwa harapan.', 88, 'Memiliki keterampilan dalam membuat olahan makanan\n.'),
(70, 'X.IPA.1.PKWU', '2020/2021 Semester 2', 6721, 'ANDIKA', '87', '89', '88', '88', 'Sangat baik dalam mengidentifikasi proses pembuatan kerajinan menjahit dan perlu ditingkatkan dalam menampilkan proses pemeliharaan satwa harapan.', 88, 'Memiliki keterampilan dalam mengidentifikasi budidaya satwa harapan.'),
(71, 'X.IPA.1.PKWU', '2020/2021 Semester 2', 6722, 'APRIMA DAMAYANTI', '82', '84', '85', '90', 'Sangat baik dalam mengidentifikasi proses pembuatan kerajinan menjahit dan perlu ditingkatkan dalam menampilkan proses pemeliharaan satwa harapan.', 92, 'Memiliki keterampilan dalam membuat olahan makanan\n.'),
(72, 'X.IPA.1.PKWU', '2020/2021 Semester 2', 6723, 'AULIYA HAMIDAH', '88', '86', '84', '86', 'Baik dalam mengidentifikasi proses pembuatan kerajinan menjahit dan perlu ditingkatkan dalam memahami proses rekayasa.', 84, 'Memiliki keterampilan dalam membuat olahan makanan\n.'),
(73, 'X.IPA.1.PJOK', '2020/2021 Semester 2', 6716, 'ADITIA PRATAMA', '85', '88', '93', '88', 'Sangat baik dalam memahami variasi dan kombinasi gerak senam pembentukan dalam aktivitas senam lantai  dan perlu ditingkatkan dalam memahami tindakan P3K pada kejadian darurat, baik pada diri sendiri maupun orang lain.', 86, 'Memiliki keterampilan dalam Mempraktikkan variasi dan kombinasi gerak berbentuk rangkaian langkah dan ayunan lengan mengikuti irama (ketukan)_x000D_\ntanpa/dengan musik sebagai pembentuk gerak pemanasan, inti latihan, dan pendinginan dalam aktivitas gerak berirama.'),
(74, 'X.IPA.1.PJOK', '2020/2021 Semester 2', 6717, 'AGSHA NURRAHMA', '85', '87', '86', '84', 'Sangat baik dalam memahami variasi dan kombinasi gerak senam pembentukan dalam aktivitas senam lantai  dan perlu ditingkatkan dalam memahami variasi dan kombinasi gerak berbentuk rangkaian langkah dan ayunan lengan mengikuti irama (ketukan) tanpa/dengan musik sebagai pembentuk gerak pemanasan, inti latihan, dan pendinginan dalam aktivitas gerak berirama.', 87, 'Memiliki keterampilan dalam Mempraktikkan variasi dan kombinasi gerak senam pembentukan dalam aktivitas senam lantai.'),
(75, 'X.IPA.1.PJOK', '2020/2021 Semester 2', 6718, 'ALYA DWI HAPSARI', '89', '83', '86', '85', 'Sangat baik dalam memahami variasi dan kombinasi gerak senam pembentukan dalam aktivitas senam lantai  dan perlu ditingkatkan dalam memahami peran aktivitas fisik terhadap pencegahan penyakit.', 88, 'Memiliki keterampilan dalam Mempraktikkan variasi dan kombinasi gerak senam pembentukan dalam aktivitas senam lantai.'),
(76, 'X.IPA.1.PJOK', '2020/2021 Semester 2', 6719, 'ANDI GARA', '89', '88', '86', '88', 'Sangat baik dalam memahami variasi dan kombinasi gerak senam pembentukan dalam aktivitas senam lantai  dan perlu ditingkatkan dalam memahami variasi dan kombinasi gerak senam pembentukan dalam aktivitas senam lantai .', 85, 'Memiliki keterampilan dalam Mempraktikkan variasi dan kombinasi gerak senam pembentukan dalam aktivitas senam lantai.'),
(77, 'X.IPA.1.PJOK', '2020/2021 Semester 2', 6720, 'ANDI HAIDI FITRA', '80', '83', '86', '88', 'Sangat baik dalam memahami peran aktivitas fisik terhadap pencegahan penyakit dan perlu ditingkatkan dalam memahami variasi dan kombinasi gerak senam pembentukan dalam aktivitas senam lantai .', 88, 'Memiliki keterampilan dalam Mempraktikkan variasi dan kombinasi gerak berbentuk rangkaian langkah dan ayunan lengan mengikuti irama (ketukan)_x000D_\ntanpa/dengan musik sebagai pembentuk gerak pemanasan, inti latihan, dan pendinginan dalam aktivitas gerak berirama.'),
(78, 'X.IPA.1.PJOK', '2020/2021 Semester 2', 6721, 'ANDIKA', '87', '89', '88', '88', 'Sangat baik dalam memahami variasi dan kombinasi gerak senam pembentukan dalam aktivitas senam lantai  dan perlu ditingkatkan dalam memahami peran aktivitas fisik terhadap pencegahan penyakit.', 88, 'Memiliki keterampilan dalam Mempraktikkan variasi dan kombinasi gerak senam pembentukan dalam aktivitas senam lantai.'),
(79, 'X.IPA.1.PJOK', '2020/2021 Semester 2', 6722, 'APRIMA DAMAYANTI', '82', '84', '85', '85', 'Sangat baik dalam memahami variasi dan kombinasi gerak senam pembentukan dalam aktivitas senam lantai  dan perlu ditingkatkan dalam memahami variasi dan kombinasi gerak senam pembentukan dalam aktivitas senam lantai .', 84, 'Memiliki keterampilan dalam Mempraktikkan variasi dan kombinasi gerak berbentuk rangkaian langkah dan ayunan lengan mengikuti irama (ketukan)_x000D_\ntanpa/dengan musik sebagai pembentuk gerak pemanasan, inti latihan, dan pendinginan dalam aktivitas gerak berirama.'),
(80, 'X.IPA.1.PJOK', '2020/2021 Semester 2', 6723, 'AULIYA HAMIDAH', '88', '86', '84', '86', 'Sangat baik dalam memahami variasi dan kombinasi gerak berbentuk rangkaian langkah dan ayunan lengan mengikuti irama (ketukan) tanpa/dengan musik sebagai pembentuk gerak pemanasan, inti latihan, dan pendinginan dalam aktivitas gerak berirama dan perlu ditingkatkan dalam memahami variasi dan kombinasi gerak senam pembentukan dalam aktivitas senam lantai .', 84, 'Memiliki keterampilan dalam Mempraktikkan variasi dan kombinasi gerak senam pembentukan dalam aktivitas senam lantai.'),
(81, 'X.IPA.1.MTKPEMINATAN', '2020/2021 Semester 2', 6716, 'ADITIA PRATAMA', '91', '93', '90', '88', 'Sangat baik dalam menjelaskan dan menentukan kesebangunan dan kekongruenan pada bangun datar dan perlu ditingkatkan dalam membuat generalisi  luas permukaan dan volume berbagai bangun ruang sisi lengkung (tabung, kerucut, dan bola).', 87, 'Memiliki keterampilan dalam menyelesaikan  masalah yang berkaitan dengan kesebangunan dan kekongruenan antar bangun\ndatar\n.'),
(82, 'X.IPA.1.MTKPEMINATAN', '2020/2021 Semester 2', 6717, 'AGSHA NURRAHMA', '92', '96', '94', '89', 'Sangat baik dalam menjelaskan dan menentukan kesebangunan dan kekongruenan pada bangun datar dan perlu ditingkatkan dalam membuat generalisi  luas permukaan dan volume berbagai bangun ruang sisi lengkung (tabung, kerucut, dan bola).', 88, 'Memiliki keterampilan dalam menyelesaikan  masalah yang berkaitan dengan kesebangunan dan kekongruenan antar bangun\ndatar\n.'),
(83, 'X.IPA.1.MTKPEMINATAN', '2020/2021 Semester 2', 6718, 'ALYA DWI HAPSARI', '86', '88', '94', '90', 'Sangat baik dalam membuat generalisi  luas permukaan dan volume berbagai bangun ruang sisi lengkung (tabung, kerucut, dan bola) dan perlu ditingkatkan dalam membuat generalisi  luas permukaan dan volume berbagai bangun ruang sisi lengkung (tabung, kerucut, dan bola).', 87, 'Memiliki keterampilan dalam menyelesaikan  masalah yang berkaitan dengan kesebangunan dan kekongruenan antar bangun\ndatar\n.'),
(84, 'X.IPA.1.MTKPEMINATAN', '2020/2021 Semester 2', 6719, 'ANDI GARA', '93', '98', '94', '92', 'Sangat baik dalam membuat generalisi  luas permukaan dan volume berbagai bangun ruang sisi lengkung (tabung, kerucut, dan bola) dan perlu ditingkatkan dalam membuat generalisi  luas permukaan dan volume berbagai bangun ruang sisi lengkung (tabung, kerucut, dan bola).', 85, 'Memiliki keterampilan dalam menyelesaikan  masalah yang berkaitan dengan kesebangunan dan kekongruenan antar bangun\ndatar\n.'),
(85, 'X.IPA.1.MTKPEMINATAN', '2020/2021 Semester 2', 6720, 'ANDI HAIDI FITRA', '86', '88', '90', '88', 'Baik dalam menjelaskan dan menentukan kesebangunan dan kekongruenan pada bangun datar dan perlu ditingkatkan dalam membuat generalisi  luas permukaan dan volume berbagai bangun ruang sisi lengkung (tabung, kerucut, dan bola).', 87, 'Memiliki keterampilan dalam menyelesaikan  masalah yang berkaitan dengan kesebangunan dan kekongruenan antar bangun\ndatar\n.'),
(86, 'X.IPA.1.MTKPEMINATAN', '2020/2021 Semester 2', 6721, 'ANDIKA', '89', '90', '92', '92', 'Sangat baik dalam menjelaskan dan menentukan kesebangunan dan kekongruenan pada bangun datar dan perlu ditingkatkan dalam membuat generalisi  luas permukaan dan volume berbagai bangun ruang sisi lengkung (tabung, kerucut, dan bola).', 88, 'Memiliki keterampilan dalam menyelesaikan masalah kontekstual yang berkaitan dengan luas permukaan dan volume bangun ruang sisi lengkung (tabung, kerucut, dan bola), serta gabungan beberapa bangun ruang\nsisi lengkung\n.'),
(87, 'X.IPA.1.MTKPEMINATAN', '2020/2021 Semester 2', 6722, 'APRIMA DAMAYANTI', '88', '84', '91', '94', 'Sangat baik dalam membuat generalisi  luas permukaan dan volume berbagai bangun ruang sisi lengkung (tabung, kerucut, dan bola) dan perlu ditingkatkan dalam membuat generalisi  luas permukaan dan volume berbagai bangun ruang sisi lengkung (tabung, kerucut, dan bola).', 90, 'Memiliki keterampilan dalam menyelesaikan masalah kontekstual yang berkaitan dengan luas permukaan dan volume bangun ruang sisi lengkung (tabung, kerucut, dan bola), serta gabungan beberapa bangun ruang\nsisi lengkung\n.'),
(88, 'X.IPA.1.MTKPEMINATAN', '2020/2021 Semester 2', 6723, 'AULIYA HAMIDAH', '90', '92', '88', '90', 'Sangat baik dalam membuat generalisi  luas permukaan dan volume berbagai bangun ruang sisi lengkung (tabung, kerucut, dan bola) dan perlu ditingkatkan dalam membuat generalisi  luas permukaan dan volume berbagai bangun ruang sisi lengkung (tabung, kerucut, dan bola).', 84, 'Memiliki keterampilan dalam menyelesaikan  masalah yang berkaitan dengan kesebangunan dan kekongruenan antar bangun\ndatar\n.'),
(89, 'X.IPA.1.BIO', '2020/2021 Semester 2', 6716, 'ADITIA PRATAMA', '91', '93', '90', '88', 'Sangat baik dalam menerapkan konsep bioteknologi dan perananannya dalam kehidupan manusia dan perlu ditingkatkan dalam menghubungkan sifat fisika dan kimia tanah, organisme yang hidup dalam tanah dan pentingnya tanah untuk keberlanjutan hidup.', 87, 'Memiliki keterampilan dalam menyajikan karya tentang proses dan produk teknologi sederhana yang ramah lingkungan.'),
(90, 'X.IPA.1.BIO', '2020/2021 Semester 2', 6717, 'AGSHA NURRAHMA', '92', '96', '94', '89', 'Sangat baik dalam menghubungkan konsep partikel materi (atom, ion, molekul), struktur zat sederhana dengan sifat bahan yang digunakan dalam kehidupan sehari-hari serta dampak penggunaan bahan terhadap kesehatan manusia dan perlu ditingkatkan dalam menerapkan konsep kemagnetan, induksi elektromagnetik, pemanfaatan medan magnet, termasuk dalam kehidupan sehari-hari termasuk pergerakan/navigasi hewan untuk mencari makanan dan migrasi.', 88, 'Memiliki keterampilan dalam menyajikan karya tentang proses dan produk teknologi sederhana yang ramah lingkungan.'),
(91, 'X.IPA.1.BIO', '2020/2021 Semester 2', 6718, 'ALYA DWI HAPSARI', '86', '88', '94', '86', 'Sangat baik dalam menerapkan konsep kemagnetan, induksi elektromagnetik, pemanfaatan medan magnet, termasuk dalam kehidupan sehari-hari termasuk pergerakan/navigasi hewan untuk mencari makanan dan migrasi dan perlu ditingkatkan dalam menghubungkan konsep partikel materi (atom, ion, molekul), struktur zat sederhana dengan sifat bahan yang digunakan dalam kehidupan sehari-hari serta dampak penggunaan bahan terhadap kesehatan manusia.', 87, 'Memiliki keterampilan dalam membuat salah satu produk bioteknologi konvensional yang ada di lingkungan sekitar.'),
(92, 'X.IPA.1.BIO', '2020/2021 Semester 2', 6719, 'ANDI GARA', '93', '98', '94', '88', 'Sangat baik dalam menerapkan konsep kemagnetan, induksi elektromagnetik, pemanfaatan medan magnet, termasuk dalam kehidupan sehari-hari termasuk pergerakan/navigasi hewan untuk mencari makanan dan migrasi dan perlu ditingkatkan dalam menerapkan konsep bioteknologi dan perananannya dalam kehidupan manusia.', 85, 'Memiliki keterampilan dalam membuat karya sederhana yang memanfaatkan prinsip elektromagnetik dan/atau induksi elektromagnetik.'),
(93, 'X.IPA.1.BIO', '2020/2021 Semester 2', 6720, 'ANDI HAIDI FITRA', '86', '88', '90', '88', 'Sangat baik dalam menerapkan konsep bioteknologi dan perananannya dalam kehidupan manusia dan perlu ditingkatkan dalam menerapkan konsep kemagnetan, induksi elektromagnetik, pemanfaatan medan magnet, termasuk dalam kehidupan sehari-hari termasuk pergerakan/navigasi hewan untuk mencari makanan dan migrasi.', 84, 'Memiliki keterampilan dalam menyajikan karya tentang proses dan produk teknologi sederhana yang ramah lingkungan.'),
(94, 'X.IPA.1.BIO', '2020/2021 Semester 2', 6721, 'ANDIKA', '89', '90', '92', '92', 'Sangat baik dalam menerapkan konsep bioteknologi dan perananannya dalam kehidupan manusia dan perlu ditingkatkan dalam menghubungkan konsep partikel materi (atom, ion, molekul), struktur zat sederhana dengan sifat bahan yang digunakan dalam kehidupan sehari-hari serta dampak penggunaan bahan terhadap kesehatan manusia.', 88, 'Memiliki keterampilan dalam membuat salah satu produk bioteknologi konvensional yang ada di lingkungan sekitar.'),
(95, 'X.IPA.1.BIO', '2020/2021 Semester 2', 6722, 'APRIMA DAMAYANTI', '88', '84', '91', '90', 'Sangat baik dalam menghubungkan konsep partikel materi (atom, ion, molekul), struktur zat sederhana dengan sifat bahan yang digunakan dalam kehidupan sehari-hari serta dampak penggunaan bahan terhadap kesehatan manusia dan perlu ditingkatkan dalam menerapkan konsep kemagnetan, induksi elektromagnetik, pemanfaatan medan magnet, termasuk dalam kehidupan sehari-hari termasuk pergerakan/navigasi hewan untuk mencari makanan dan migrasi.', 92, 'Memiliki keterampilan dalam menyajikan karya tentang proses dan produk teknologi sederhana yang ramah lingkungan.'),
(96, 'X.IPA.1.BIO', '2020/2021 Semester 2', 6723, 'AULIYA HAMIDAH', '90', '92', '88', '90', 'Sangat baik dalam menerapkan konsep bioteknologi dan perananannya dalam kehidupan manusia dan perlu ditingkatkan dalam menghubungkan sifat fisika dan kimia tanah, organisme yang hidup dalam tanah dan pentingnya tanah untuk keberlanjutan hidup.', 84, 'Memiliki keterampilan dalam menyajikan karya tentang proses dan produk teknologi sederhana yang ramah lingkungan.'),
(97, 'X.IPA.1.FIS', '2020/2021 Semester 2', 6716, 'ADITIA PRATAMA', '84', '82', '88', '85', 'Sangat baik dalam menerapkan konsep bioteknologi dan perananannya dalam kehidupan manusia dan perlu ditingkatkan dalam menghubungkan sifat fisika dan kimia tanah, organisme yang hidup dalam tanah dan pentingnya tanah untuk keberlanjutan hidup.', 86, 'Memiliki keterampilan dalam menyajikan karya tentang proses dan produk teknologi sederhana yang ramah lingkungan.');
INSERT INTO `leger_nilai` (`id_legernilai`, `kode_mapel`, `thn_pelajaran`, `nisn`, `nama_pesertadidik`, `nilai_nh`, `nilai_pts`, `nilai_pas`, `nilai_akhir`, `deskripsi_np`, `nilai_keterampilan`, `deskripsi_keterampilan`) VALUES
(98, 'X.IPA.1.FIS', '2020/2021 Semester 2', 6717, 'AGSHA NURRAHMA', '92', '96', '86', '91', 'Sangat baik dalam menghubungkan konsep partikel materi (atom, ion, molekul), struktur zat sederhana dengan sifat bahan yang digunakan dalam kehidupan sehari-hari serta dampak penggunaan bahan terhadap kesehatan manusia dan perlu ditingkatkan dalam menerapkan konsep kemagnetan, induksi elektromagnetik, pemanfaatan medan magnet, termasuk dalam kehidupan sehari-hari termasuk pergerakan/navigasi hewan untuk mencari makanan dan migrasi.', 88, 'Memiliki keterampilan dalam menyajikan karya tentang proses dan produk teknologi sederhana yang ramah lingkungan.'),
(99, 'X.IPA.1.FIS', '2020/2021 Semester 2', 6718, 'ALYA DWI HAPSARI', '86', '88', '87', '87', 'Sangat baik dalam menerapkan konsep kemagnetan, induksi elektromagnetik, pemanfaatan medan magnet, termasuk dalam kehidupan sehari-hari termasuk pergerakan/navigasi hewan untuk mencari makanan dan migrasi dan perlu ditingkatkan dalam menghubungkan konsep partikel materi (atom, ion, molekul), struktur zat sederhana dengan sifat bahan yang digunakan dalam kehidupan sehari-hari serta dampak penggunaan bahan terhadap kesehatan manusia.', 86, 'Memiliki keterampilan dalam membuat salah satu produk bioteknologi konvensional yang ada di lingkungan sekitar.'),
(100, 'X.IPA.1.FIS', '2020/2021 Semester 2', 6719, 'ANDI GARA', '93', '98', '88', '93', 'Sangat baik dalam menerapkan konsep kemagnetan, induksi elektromagnetik, pemanfaatan medan magnet, termasuk dalam kehidupan sehari-hari termasuk pergerakan/navigasi hewan untuk mencari makanan dan migrasi dan perlu ditingkatkan dalam menerapkan konsep bioteknologi dan perananannya dalam kehidupan manusia.', 86, 'Memiliki keterampilan dalam membuat karya sederhana yang memanfaatkan prinsip elektromagnetik dan/atau induksi elektromagnetik.'),
(101, 'X.IPA.1.FIS', '2020/2021 Semester 2', 6720, 'ANDI HAIDI FITRA', '86', '88', '83', '86', 'Sangat baik dalam menerapkan konsep bioteknologi dan perananannya dalam kehidupan manusia dan perlu ditingkatkan dalam menerapkan konsep kemagnetan, induksi elektromagnetik, pemanfaatan medan magnet, termasuk dalam kehidupan sehari-hari termasuk pergerakan/navigasi hewan untuk mencari makanan dan migrasi.', 84, 'Memiliki keterampilan dalam menyajikan karya tentang proses dan produk teknologi sederhana yang ramah lingkungan.'),
(102, 'X.IPA.1.FIS', '2020/2021 Semester 2', 6721, 'ANDIKA', '89', '90', '84', '88', 'Sangat baik dalam menerapkan konsep bioteknologi dan perananannya dalam kehidupan manusia dan perlu ditingkatkan dalam menghubungkan konsep partikel materi (atom, ion, molekul), struktur zat sederhana dengan sifat bahan yang digunakan dalam kehidupan sehari-hari serta dampak penggunaan bahan terhadap kesehatan manusia.', 88, 'Memiliki keterampilan dalam membuat salah satu produk bioteknologi konvensional yang ada di lingkungan sekitar.'),
(103, 'X.IPA.1.FIS', '2020/2021 Semester 2', 6722, 'APRIMA DAMAYANTI', '88', '84', '91', '88', 'Sangat baik dalam menghubungkan konsep partikel materi (atom, ion, molekul), struktur zat sederhana dengan sifat bahan yang digunakan dalam kehidupan sehari-hari serta dampak penggunaan bahan terhadap kesehatan manusia dan perlu ditingkatkan dalam menerapkan konsep kemagnetan, induksi elektromagnetik, pemanfaatan medan magnet, termasuk dalam kehidupan sehari-hari termasuk pergerakan/navigasi hewan untuk mencari makanan dan migrasi.', 86, 'Memiliki keterampilan dalam menyajikan karya tentang proses dan produk teknologi sederhana yang ramah lingkungan.'),
(104, 'X.IPA.1.FIS', '2020/2021 Semester 2', 6723, 'AULIYA HAMIDAH', '90', '92', '88', '90', 'Sangat baik dalam menerapkan konsep bioteknologi dan perananannya dalam kehidupan manusia dan perlu ditingkatkan dalam menghubungkan sifat fisika dan kimia tanah, organisme yang hidup dalam tanah dan pentingnya tanah untuk keberlanjutan hidup.', 88, 'Memiliki keterampilan dalam menyajikan karya tentang proses dan produk teknologi sederhana yang ramah lingkungan.'),
(105, 'X.IPA.1.KIM', '2020/2021 Semester 2', 6716, 'ADITIA PRATAMA', '84', '82', '88', '85', 'Sangat baik dalam menerapkan konsep bioteknologi dan perananannya dalam kehidupan manusia dan perlu ditingkatkan dalam menghubungkan sifat fisika dan kimia tanah, organisme yang hidup dalam tanah dan pentingnya tanah untuk keberlanjutan hidup.', 86, 'Memiliki keterampilan dalam menyajikan karya tentang proses dan produk teknologi sederhana yang ramah lingkungan.'),
(106, 'X.IPA.1.KIM', '2020/2021 Semester 2', 6717, 'AGSHA NURRAHMA', '92', '96', '86', '91', 'Sangat baik dalam menghubungkan konsep partikel materi (atom, ion, molekul), struktur zat sederhana dengan sifat bahan yang digunakan dalam kehidupan sehari-hari serta dampak penggunaan bahan terhadap kesehatan manusia dan perlu ditingkatkan dalam menerapkan konsep kemagnetan, induksi elektromagnetik, pemanfaatan medan magnet, termasuk dalam kehidupan sehari-hari termasuk pergerakan/navigasi hewan untuk mencari makanan dan migrasi.', 88, 'Memiliki keterampilan dalam menyajikan karya tentang proses dan produk teknologi sederhana yang ramah lingkungan.'),
(107, 'X.IPA.1.KIM', '2020/2021 Semester 2', 6718, 'ALYA DWI HAPSARI', '86', '88', '87', '87', 'Sangat baik dalam menerapkan konsep kemagnetan, induksi elektromagnetik, pemanfaatan medan magnet, termasuk dalam kehidupan sehari-hari termasuk pergerakan/navigasi hewan untuk mencari makanan dan migrasi dan perlu ditingkatkan dalam menghubungkan konsep partikel materi (atom, ion, molekul), struktur zat sederhana dengan sifat bahan yang digunakan dalam kehidupan sehari-hari serta dampak penggunaan bahan terhadap kesehatan manusia.', 86, 'Memiliki keterampilan dalam membuat salah satu produk bioteknologi konvensional yang ada di lingkungan sekitar.'),
(108, 'X.IPA.1.KIM', '2020/2021 Semester 2', 6719, 'ANDI GARA', '93', '98', '88', '93', 'Sangat baik dalam menerapkan konsep kemagnetan, induksi elektromagnetik, pemanfaatan medan magnet, termasuk dalam kehidupan sehari-hari termasuk pergerakan/navigasi hewan untuk mencari makanan dan migrasi dan perlu ditingkatkan dalam menerapkan konsep bioteknologi dan perananannya dalam kehidupan manusia.', 86, 'Memiliki keterampilan dalam membuat karya sederhana yang memanfaatkan prinsip elektromagnetik dan/atau induksi elektromagnetik.'),
(109, 'X.IPA.1.KIM', '2020/2021 Semester 2', 6720, 'ANDI HAIDI FITRA', '86', '88', '83', '86', 'Sangat baik dalam menerapkan konsep bioteknologi dan perananannya dalam kehidupan manusia dan perlu ditingkatkan dalam menerapkan konsep kemagnetan, induksi elektromagnetik, pemanfaatan medan magnet, termasuk dalam kehidupan sehari-hari termasuk pergerakan/navigasi hewan untuk mencari makanan dan migrasi.', 84, 'Memiliki keterampilan dalam menyajikan karya tentang proses dan produk teknologi sederhana yang ramah lingkungan.'),
(110, 'X.IPA.1.KIM', '2020/2021 Semester 2', 6721, 'ANDIKA', '89', '90', '84', '88', 'Sangat baik dalam menerapkan konsep bioteknologi dan perananannya dalam kehidupan manusia dan perlu ditingkatkan dalam menghubungkan konsep partikel materi (atom, ion, molekul), struktur zat sederhana dengan sifat bahan yang digunakan dalam kehidupan sehari-hari serta dampak penggunaan bahan terhadap kesehatan manusia.', 88, 'Memiliki keterampilan dalam membuat salah satu produk bioteknologi konvensional yang ada di lingkungan sekitar.'),
(111, 'X.IPA.1.KIM', '2020/2021 Semester 2', 6722, 'APRIMA DAMAYANTI', '88', '84', '91', '88', 'Sangat baik dalam menghubungkan konsep partikel materi (atom, ion, molekul), struktur zat sederhana dengan sifat bahan yang digunakan dalam kehidupan sehari-hari serta dampak penggunaan bahan terhadap kesehatan manusia dan perlu ditingkatkan dalam menerapkan konsep kemagnetan, induksi elektromagnetik, pemanfaatan medan magnet, termasuk dalam kehidupan sehari-hari termasuk pergerakan/navigasi hewan untuk mencari makanan dan migrasi.', 86, 'Memiliki keterampilan dalam menyajikan karya tentang proses dan produk teknologi sederhana yang ramah lingkungan.'),
(112, 'X.IPA.1.KIM', '2020/2021 Semester 2', 6723, 'AULIYA HAMIDAH', '90', '92', '88', '90', 'Sangat baik dalam menerapkan konsep bioteknologi dan perananannya dalam kehidupan manusia dan perlu ditingkatkan dalam menghubungkan sifat fisika dan kimia tanah, organisme yang hidup dalam tanah dan pentingnya tanah untuk keberlanjutan hidup.', 88, 'Memiliki keterampilan dalam menyajikan karya tentang proses dan produk teknologi sederhana yang ramah lingkungan.');

-- --------------------------------------------------------

--
-- Struktur dari tabel `mata_pelajaran`
--

CREATE TABLE `mata_pelajaran` (
  `id` int(11) NOT NULL,
  `nama_mapel` varchar(256) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `mata_pelajaran`
--

INSERT INTO `mata_pelajaran` (`id`, `nama_mapel`) VALUES
(1, 'Pendidikan Agama Islam'),
(2, 'PKn'),
(3, 'Bahasa Indonesia'),
(4, 'Matematika'),
(5, 'Sejarah Indonesia'),
(6, 'Bahasa Inggris'),
(7, 'Seni Budaya'),
(8, 'Prakarya dan Kewirausahaan'),
(9, 'Penjas dan Orkes'),
(10, 'Matematika Peminatan'),
(11, 'Biologi'),
(12, 'Fisika'),
(13, 'Kimia'),
(14, 'Sejarah Peminatan'),
(15, 'Geografi'),
(16, 'Sosiologi'),
(17, 'Ekonomi'),
(18, 'Bahasa dan Sastra Inggris'),
(19, 'Biologi (LM)'),
(20, 'Ekonomi (LM)');

-- --------------------------------------------------------

--
-- Struktur dari tabel `peserta_didik`
--

CREATE TABLE `peserta_didik` (
  `id_pd` int(11) NOT NULL,
  `nisn` int(20) NOT NULL,
  `password` varchar(256) NOT NULL,
  `nama_lengkap` text NOT NULL,
  `jenis_kelamin` enum('Laki-laki','Perempuan') NOT NULL,
  `tempat_lahir` varchar(256) NOT NULL,
  `tanggal_lahir` date NOT NULL,
  `agama` varchar(256) NOT NULL,
  `alamat` text NOT NULL,
  `no_hp` varchar(15) NOT NULL,
  `status_pd` varchar(256) NOT NULL,
  `date_created` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `peserta_didik`
--

INSERT INTO `peserta_didik` (`id_pd`, `nisn`, `password`, `nama_lengkap`, `jenis_kelamin`, `tempat_lahir`, `tanggal_lahir`, `agama`, `alamat`, `no_hp`, `status_pd`, `date_created`) VALUES
(1, 6716, '$2y$10$E4zFaBue2BuHuM6/awPA2uZuz09ZXzy7qeN5OD2tOCH.Sd9rlzZQW', 'ADITIA PRATAMA', 'Laki-laki', 'Palembang', '0000-00-00', 'Islam', 'Palembang', '082182896290', 'Aktif', 1627457902),
(2, 6717, '$2y$10$b9b1zq0LDqgETKANCsi7p.GlQoRvDk2Sl36OPU.aIZm782WeAWARq', 'AGSHA NURRAHMA', 'Perempuan', 'Palembang', '0000-00-00', 'Islam', 'Palembang', '082182896290', 'Aktif', 1627457902),
(3, 6718, '$2y$10$wySYPU8cyEQdchKlcEyn9ugV8lOc4sTYKx5q/GjfLsy.GvgwNqXbC', 'ALYA DWI HAPSARI', 'Laki-laki', 'Palembang', '0000-00-00', 'Islam', 'Palembang', '082182896290', 'Aktif', 1627457902),
(4, 6719, '$2y$10$cYDJ4HnvO.ilGXfTsheuLeYre5GPFabcy1gsv3q1HmkraS38WdgfW', 'ANDI GARA', 'Laki-laki', 'Palembang', '0000-00-00', 'Islam', 'Palembang', '082182896290', 'Aktif', 1627457902),
(5, 6720, '$2y$10$OIQsAESEwlEOtPQHtsRWD.zgk4nh6U2yfODD3x4Mto7m6ie6Av8qq', 'ANDI HAIDI FITRA', 'Laki-laki', 'Palembang', '0000-00-00', 'Islam', 'Palembang', '082182896290', 'Aktif', 1627457902),
(6, 6721, '$2y$10$Z./4UFIg3ImVq8TLn0ADDeXIhKppUTV2qU9dWQfealOi/H074GqEi', 'ANDIKA', 'Laki-laki', 'Palembang', '0000-00-00', 'Islam', 'Palembang', '082182896290', 'Aktif', 1627457902),
(7, 6722, '$2y$10$8RuOB0Ccknx1KWNElC8mgetkd.YHPTP6M5fvVtlPzExs0kZql5NaG', 'APRIMA DAMAYANTI', 'Perempuan', 'Palembang', '0000-00-00', 'Islam', 'Palembang', '082182896290', 'Aktif', 1627457902),
(8, 6723, '$2y$10$KJvwGxdpGVbZ9ihePf9QGuqT9DTS0uPQbjP5AmuEUM.BuB9PE8F76', 'AULIYA HAMIDAH', 'Perempuan', 'Palembang', '0000-00-00', 'Islam', 'Palembang', '082182896290', 'Aktif', 1627457902);

-- --------------------------------------------------------

--
-- Struktur dari tabel `rekap_absensi`
--

CREATE TABLE `rekap_absensi` (
  `id_rekapabsen` int(11) NOT NULL,
  `nama_kelas` varchar(256) NOT NULL,
  `thn_pelajaran` varchar(256) NOT NULL,
  `nisn` int(20) NOT NULL,
  `nama_pesertadidik` varchar(256) NOT NULL,
  `jumlah_alpa` int(3) NOT NULL,
  `jumlah_izin` int(3) NOT NULL,
  `jumlah_sakit` int(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `rekap_absensi`
--

INSERT INTO `rekap_absensi` (`id_rekapabsen`, `nama_kelas`, `thn_pelajaran`, `nisn`, `nama_pesertadidik`, `jumlah_alpa`, `jumlah_izin`, `jumlah_sakit`) VALUES
(1, 'X IPA 1', '2020/2021 Semester 2', 6716, 'ADITIA PRATAMA', 0, 1, 2),
(2, 'X IPA 1', '2020/2021 Semester 2', 6717, 'AGSHA NURRAHMA', 1, 1, 1),
(3, 'X IPA 1', '2020/2021 Semester 2', 6718, 'ALYA DWI HAPSARI', 2, 0, 1),
(4, 'X IPA 1', '2020/2021 Semester 2', 6719, 'ANDI GARA', 5, 1, 2),
(5, 'X IPA 1', '2020/2021 Semester 2', 6720, 'ANDI HAIDI FITRA', 0, 0, 0),
(6, 'X IPA 1', '2020/2021 Semester 2', 6721, 'ANDIKA', 0, 0, 0),
(7, 'X IPA 1', '2020/2021 Semester 2', 6722, 'APRIMA DAMAYANTI', 0, 0, 0),
(8, 'X IPA 1', '2020/2021 Semester 2', 6723, 'AULIYA HAMIDAH', 0, 0, 0);

-- --------------------------------------------------------

--
-- Struktur dari tabel `status_pengumuman`
--

CREATE TABLE `status_pengumuman` (
  `id` int(11) NOT NULL,
  `status` varchar(128) NOT NULL,
  `tgl_diubah` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `status_pengumuman`
--

INSERT INTO `status_pengumuman` (`id`, `status`, `tgl_diubah`) VALUES
(1, 'ditutup', 1624891930);

-- --------------------------------------------------------

--
-- Struktur dari tabel `thn_pelajaran`
--

CREATE TABLE `thn_pelajaran` (
  `id` int(11) NOT NULL,
  `thn_pelajaran` varchar(256) NOT NULL,
  `date_created` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `thn_pelajaran`
--

INSERT INTO `thn_pelajaran` (`id`, `thn_pelajaran`, `date_created`) VALUES
(1, '2020/2021 Semester 1', 1627047040),
(2, '2020/2021 Semester 2', 1627047049);

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `id` int(11) NOT NULL,
  `name` varchar(128) NOT NULL,
  `username` varchar(128) NOT NULL,
  `password` varchar(256) NOT NULL,
  `role_id` varchar(256) NOT NULL,
  `is_active` int(11) NOT NULL,
  `manage` varchar(256) NOT NULL,
  `date_created` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id`, `name`, `username`, `password`, `role_id`, `is_active`, `manage`, `date_created`) VALUES
(1, 'Andri Kurniawan', '12345678', '$2y$10$rhHpLhyp1rFPaGS/JFSUBeQVVvCD5JZ6eAHC6Q8GgWSwZXEA8t1fK', '1', 1, '', 1589576852),
(660, 'Kania Nahda Sashikirana', 'kania', '$2y$10$g1M9cz6JzUJ2TS5OOKZR/upJ/TAKcinAe/EGxGNeSeOTfC67HT4GS', '2', 1, 'X IPA 1', 1626859054),
(661, 'Administrator', 'admin', '$2y$10$04ePYSaobeJMlvhyMSE/zOYxuXogNr.NF8dqghXQnIw.e.G116pGS', '1', 1, '', 1626878609),
(662, 'kalila', 'kalila', '$2y$10$xT.gqId87wIFVA1/uu41vOooU7h1/BBBjyru0Ta5/9N5M0lFyWuD2', '2', 1, 'X IPA 2', 1627340689),
(665, 'H. Mukidi', 'mukidi', '$2y$10$O/RfH54csRg6xQRxVXym.uj.oPdvcH73khHnAjFq8wE8Sdqk6eS5y', '3', 1, 'Kepala Sekolah', 1627378525);

-- --------------------------------------------------------

--
-- Struktur dari tabel `user_access_menu`
--

CREATE TABLE `user_access_menu` (
  `id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user_access_menu`
--

INSERT INTO `user_access_menu` (`id`, `role_id`, `menu_id`) VALUES
(1, 1, 1),
(2, 2, 2),
(3, 1, 2),
(4, 1, 3),
(5, 2, 3),
(6, 1, 4),
(7, 2, 4),
(8, 3, 1),
(9, 3, 2),
(10, 3, 3),
(11, 3, 4);

-- --------------------------------------------------------

--
-- Struktur dari tabel `user_menu`
--

CREATE TABLE `user_menu` (
  `id` int(11) NOT NULL,
  `menu` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user_menu`
--

INSERT INTO `user_menu` (`id`, `menu`) VALUES
(1, 'Admin'),
(2, 'User'),
(3, 'Masterdata'),
(4, 'Pengelolaan');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user_role`
--

CREATE TABLE `user_role` (
  `id` int(11) NOT NULL,
  `role` varchar(128) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user_role`
--

INSERT INTO `user_role` (`id`, `role`) VALUES
(1, 'Administrator'),
(2, 'Member'),
(3, 'Kepala Sekolah');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user_sub_menu`
--

CREATE TABLE `user_sub_menu` (
  `id` int(11) NOT NULL,
  `menu_id` int(11) NOT NULL,
  `title` varchar(128) NOT NULL,
  `url` varchar(128) NOT NULL,
  `icon` varchar(128) NOT NULL,
  `is_active` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user_sub_menu`
--

INSERT INTO `user_sub_menu` (`id`, `menu_id`, `title`, `url`, `icon`, `is_active`) VALUES
(1, 1, 'Dashboard', 'admin', 'icon-grid', 1),
(2, 2, 'My profile', 'user', 'icon-user', 1),
(3, 1, 'Data Siswa', 'admin/data_siswa', 'icon-chart', 1),
(4, 2, 'Hasil Belajar', 'user/hasil_belajar', 'icon-graduation', 1);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `ekstrakurikuler`
--
ALTER TABLE `ekstrakurikuler`
  ADD PRIMARY KEY (`id_ekskul`);

--
-- Indeks untuk tabel `identitas_sekolah`
--
ALTER TABLE `identitas_sekolah`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `kelas`
--
ALTER TABLE `kelas`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `kode_mapel`
--
ALTER TABLE `kode_mapel`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `leger_ekskul`
--
ALTER TABLE `leger_ekskul`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `leger_nilai`
--
ALTER TABLE `leger_nilai`
  ADD PRIMARY KEY (`id_legernilai`);

--
-- Indeks untuk tabel `mata_pelajaran`
--
ALTER TABLE `mata_pelajaran`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `peserta_didik`
--
ALTER TABLE `peserta_didik`
  ADD PRIMARY KEY (`id_pd`);

--
-- Indeks untuk tabel `rekap_absensi`
--
ALTER TABLE `rekap_absensi`
  ADD PRIMARY KEY (`id_rekapabsen`);

--
-- Indeks untuk tabel `status_pengumuman`
--
ALTER TABLE `status_pengumuman`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `thn_pelajaran`
--
ALTER TABLE `thn_pelajaran`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `user_access_menu`
--
ALTER TABLE `user_access_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `user_menu`
--
ALTER TABLE `user_menu`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `user_role`
--
ALTER TABLE `user_role`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `user_sub_menu`
--
ALTER TABLE `user_sub_menu`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `ekstrakurikuler`
--
ALTER TABLE `ekstrakurikuler`
  MODIFY `id_ekskul` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `identitas_sekolah`
--
ALTER TABLE `identitas_sekolah`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `kelas`
--
ALTER TABLE `kelas`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `kode_mapel`
--
ALTER TABLE `kode_mapel`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT untuk tabel `leger_ekskul`
--
ALTER TABLE `leger_ekskul`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT untuk tabel `leger_nilai`
--
ALTER TABLE `leger_nilai`
  MODIFY `id_legernilai` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=113;

--
-- AUTO_INCREMENT untuk tabel `mata_pelajaran`
--
ALTER TABLE `mata_pelajaran`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;

--
-- AUTO_INCREMENT untuk tabel `peserta_didik`
--
ALTER TABLE `peserta_didik`
  MODIFY `id_pd` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT untuk tabel `rekap_absensi`
--
ALTER TABLE `rekap_absensi`
  MODIFY `id_rekapabsen` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT untuk tabel `status_pengumuman`
--
ALTER TABLE `status_pengumuman`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT untuk tabel `thn_pelajaran`
--
ALTER TABLE `thn_pelajaran`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=666;

--
-- AUTO_INCREMENT untuk tabel `user_access_menu`
--
ALTER TABLE `user_access_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT untuk tabel `user_menu`
--
ALTER TABLE `user_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT untuk tabel `user_role`
--
ALTER TABLE `user_role`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `user_sub_menu`
--
ALTER TABLE `user_sub_menu`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
